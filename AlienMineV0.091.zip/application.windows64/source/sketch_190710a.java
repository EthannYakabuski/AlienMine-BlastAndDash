import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.sound.*; 
import ddf.minim.*; 
import java.util.Arrays; 
import java.util.Random; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class sketch_190710a extends PApplet {







Player playerone = new Player();
GameBoard board = new GameBoard();

PImage[] images = new PImage[100];

int width = 1400;
int height = 900;


int playersHighScore = 0;

Minim minim;

int frameRule; 

boolean restartAvailable = false;

boolean potionSickness = false;
int potionTimer = 0;

boolean superSickness = false; 
int superTimer = 0;

//boolean shotGunSickness = false;
int shotGunTimer = 0;

boolean titleScreen = true;



//Audio files//
AudioSnippet mainMenu;
AudioSnippet upgradeWeapon;


boolean showingScores = false;

public void setup() {
  
  //Audio file setup//
  minim = new Minim(this);
  mainMenu = minim.loadSnippet("mainScreen.wav");
  
  upgradeWeapon = minim.loadSnippet("upgradeWeapon.mp3");
  
  mainMenu.play();
  
  
  //setting the framerate
  frameRate(30);
  
  frameRule = -1;
  
 
  
  
  //tiles
  images[0] = loadImage("tree100.PNG");
  images[1] = loadImage("tree75.PNG");
  images[2] = loadImage("tree50.PNG");
  images[3] = loadImage("tree25.PNG");
  
  images[4] = loadImage("iron100.PNG");
  images[5] = loadImage("iron75.PNG");
  images[6] = loadImage("iron50.PNG");
  images[7] = loadImage("iron25.PNG");
  
  images[8] = loadImage("gold100.PNG");
  images[9] = loadImage("gold75.PNG");
  images[10] = loadImage("gold50.PNG");
  images[11] = loadImage("gold25.PNG");
  
  images[12] = loadImage("lava100.PNG");
  images[13] = loadImage("grass100.PNG");
  images[14] = loadImage("dirt100.PNG");
  
  
  //characters
  //players
  images[15] = loadImage("lenny100.PNG");
  
  //enemies
  //ants
  images[16] = loadImage("ant100.PNG");
  images[17] = loadImage("ant75.PNG"); 
  images[18] = loadImage("ant50.PNG");
  
  //flowers
  images[19] = loadImage("flower100.PNG"); 
  images[20] = loadImage("flower75.PNG");
  images[21] = loadImage("flower50.PNG");
  
  //robots
  images[22] = loadImage("robot100.PNG"); 
  images[23] = loadImage("robot75.PNG");
  images[24] = loadImage("robot50.PNG");
  
  
  //images for the hud
  images[25] = loadImage("potion.JPG");
  images[26] = loadImage("pickaxe.JPG");
  images[27] = loadImage("woodTommy.JPG");
  images[28] = loadImage("ironTommy.JPG");
  images[29] = loadImage("goldTommy.JPG");
  images[30] = loadImage("woodShotty.JPG");
  images[31] = loadImage("ironShotty.JPG");
  images[32] = loadImage("goldShotty.JPG");
  
  
  
  //images for phalax
  images[33] = loadImage("phalax.png");
  
  
  
  //images for the steel biome
  images[34] = loadImage("steel.JPG"); 
  images[35] = loadImage("steelPotionUpgrade.JPG"); 
  images[36] = loadImage("steelSuperPower.JPG"); 
  
  //images for the base enemies unique to the steel biome
  images[37] = loadImage("electroMan.png"); 
  images[38] = loadImage("electroDuo.png"); 
  images[39] = loadImage("electroQuad.png");
  
  
  //more images for the hud
  images[40] = loadImage("superPower.JPG");
  
  
  
  images[43] = loadImage("tropical.JPG");
  
  images[44] = loadImage("water.JPG");
  images[46] = loadImage("sand.JPG");
  
  
  //enemies for the tropical biome
  images[47] = loadImage("monkey.png");
  images[48] = loadImage("gorilla.png");
  
  images[47].resize(20,20);
  images[48].resize(40,40);
  
  
  images[0].resize(20,20);
  images[1].resize(20,20);
  images[2].resize(20,20);
  images[3].resize(20,20);
  images[4].resize(20,20);
  images[5].resize(20,20);
  images[6].resize(20,20);
  images[7].resize(20,20);
  images[8].resize(20,20);
  images[9].resize(20,20);
  images[10].resize(20,20);
  images[11].resize(20,20);
  images[12].resize(20,20);
  images[13].resize(20,20);
  images[14].resize(20,20);
  images[15].resize(40,40);
  images[16].resize(20,20);
  images[17].resize(20,20);
  images[18].resize(20,20);
  images[19].resize(20,20);
  images[20].resize(20,20);
  images[21].resize(20,20);
  images[22].resize(20,20);
  images[23].resize(20,20);
  images[24].resize(20,20);
  
  
  images[25].resize(68,68);
  images[26].resize(68,68);
  images[27].resize(75,35);
  images[28].resize(75,35);
  images[29].resize(75,35);
  
  images[30].resize(75,35);
  images[31].resize(75,35);
  images[32].resize(75,35);
  
  
  images[33].resize(100,100);
  
  
  //images for the steel biome
  images[34].resize(20,20); 
  images[35].resize(20,20); 
  images[36].resize(20,20);
  
  images[37].resize(20,20);
  images[38].resize(40,40); 
  images[39].resize(40,40);
  
  images[40].resize(68,68);
  
  
  images[43].resize(20,20);
  images[44].resize(20,20);
  images[46].resize(20,20);
  
  
  images[45] = loadImage("pirateShip.png");
  images[45].resize(250,100);
  
  
  //bullets
  images[41] = loadImage("flowerBullet.png");
  images[41].resize(20,20);
  
  images[42] = loadImage("hiveBullet.png");
  images[42].resize(40,40);
  
  
  images[49] = loadImage("cannonBall.png");
  images[49].resize(40,40);
  
  
  
  
  board.imageList = images;
  board.addPlayer(playerone);
  board.createMap();
  
  
  
  

}


public void draw() {
  
  
  //main menu options for the game
  
  
  if(showingScores) {
    
    //show the scores
    String[] lines = loadStrings("highScores.txt");
    
    for(int i = 0; i < lines.length; i++) {
      
      fill(155); 
      textSize(30);
      text(lines[i], 100, 100*(i+1));
      textSize(11);
    }
    
  }
  
  
  
  //basic layout
  background(255);
  
  
  if(titleScreen) { noLoop(); }
  
  gridDisplay();
  
  
  //variable keeping track of the current frame
  frameRule = frameRule +1; 
  
  //System.out.println("frameRule: " + frameRule); 
  
  
  //shows game graphics and other
  //important information for the player concerning the game state
  board.hud(playerone);
  board.display();
  board.spawnInitialEnemies();
  board.checkAnimations();
  
  //updates enemies
  board.checkEnemies();
  
  board.checkBiomeSwitch();
  
  //before you move the enemies apply swarm intelligence
  board.updateSwarmIntelligence(); 
  
  
  board.checkPirateSickness();
  //move all the enemies
  board.moveEnemies(frameRule%30);
  board.spawnAnEnemy(frameRule%30);
  board.showEnemies();
  
  
  //updates player bullets
  board.grantShottyAmmo(frameRule%150);
  //board.checkBulletRedundancy();
  board.drawBullets();
  board.checkCollisions();
  
  //updating damage to the player
  //environmental damage
  board.checkLavaDamage();
  
  //enemy damage
  board.checkEnemyAntsEating();
  board.checkEnemiesWhoShoot();
  
  board.drawFlowerBullets();
  board.checkFlowerBulletCollisions();
  
  board.drawRobotBullets();
  board.checkRobotBulletCollisions();
  
  
  board.drawHiveBullets();
  board.checkHiveBulletCollisions();
  
  
  board.drawCannonBullets();
  board.checkCannonBulletCollisions();
  
  //clearing of bullets in backing array that are now off screen and no longer active
  board.checkBulletRedundancy();
  
  board.checkSuperPowerAmount();
  
  //board.drawPhalaxBullets();
  //board.checkPhalaxBulletCollisions();
  
 
  //ANIMATIONS
  
  //handles potion cooldown animation
  if(potionSickness) {
     potionTimer = potionTimer + 1; 
     
     //animate the potion box
     board.addPotionAnimateTick(potionTimer);
       
     //can only drink a potion every 8 seconds
     if(potionTimer == 240) {
       
       potionTimer = 0; 
       potionSickness = false;
     } 
  }
  
  
  //handles super power cooldown animation
  if(superSickness) {
     superTimer = superTimer + 1; 
     
     //animate the super power box
     board.addSuperPowerAnimateTick(superTimer);
       
     //can only use super power every 24 seconds
     if(superTimer == 720) {
       
       superTimer = 0; 
       superSickness = false;
     } 
  }
  

  //handles if the game has ended
  boolean playerDead = board.endGame();
  //if the player has died end the game
  if(playerDead) {
    noLoop();
    showRestartButton();
  }
  
  
  
  if(titleScreen) { makeIntroScreen(); }
  
}

public void makeIntroScreen() {
  //noLoop();
  
  color(255);
  fill(000);
  rect(0,0,2800,1800);
  
  
  makePlayButton();
  
  makeLeaderBoardButton();
  
  showScores();
  
  makeCharacterCustomizationButton();
  
  
  
}

public void makePlayButton() {
  
  fill(255); 
  
  rect(700,300,250,100);
  fill(000);
  textSize(20);
  text("PLAY : NORMAL MODE", 590, 300);
  textSize(11);
  
}

public void makeCharacterCustomizationButton() {
  
  
}


public void makeLeaderBoardButton() {
  
  fill(255);
  
  rect(700,450,250,100);
  fill(000);
  textSize(20);
  text("LEADERBOARD", 620, 450);
  textSize(11);
  
}

public void showRestartButton() {
  restartAvailable = true;
  
  fill(0); 
  rect(0,0,400,400);
  fill(255);
  text("RESTART",80,100);
  
}

public void gridDisplay() {
  
  //vertical lines
  int i = 0;
  while (i < 1400) {
    line(i,0,i,800);
    i = i + 20;
  }
  //horizontal lines
  int j = 0;
  while (j < 801) {
    line(0,j,1400,j);
    j = j + 20;
  }
}

public void keyPressed() {
       
  //handles WASD movement and hotkey bar START
  if (key == 119) {
    playerone.keyHandler("w");
    
  } else if (key == 97) {
    playerone.keyHandler("a");
    
  } else if (key == 115) {
    playerone.keyHandler("s");
    
  } else if (key == 100) {
    playerone.keyHandler("d");
    
  } else if (key == 49) {
    playerone.keyHandler("1"); 
    
  } else if (key == 50) {
    playerone.keyHandler("2"); 
  } 
  else if (key == 51) {
    playerone.keyHandler("3"); 
  }
  else if (key == 52) {
    
    
    if(!superSickness) {
      superSickness = true;
      playerone.keyHandler("4");
      board.superPowerApplied();
      
    }
    
  }
  else if (key == 53) {
    
    if(!potionSickness) {
      
      potionSickness = true;
      playerone.keyHandler("5");
      
    }
    
  } else if (key == 101) {
    playerone.keyHandler("e"); 
  } else if (key == 114) {
    playerone.keyHandler("r"); 
  } else if (key == 116) {
    playerone.keyHandler("t"); 
  } else if (key == 102) {
    playerone.keyHandler("f"); 
  } else if (key == 103) {
    playerone.keyHandler("g"); 
  } else if (key == 104) {
    playerone.keyHandler("h"); 
  } else if (key == 99) {
    playerone.keyHandler("c"); 
  } else if (key == 118) {
    playerone.keyHandler("v"); 
  } else if (key == 98) {
    playerone.keyHandler("b"); 
  }
  //handles WASD movement and hotkey bar END
  
}

public void showScores() {
  System.out.println("Showing scores");
  
  showingScores = true;
  
  
  String[] lines = loadStrings("highScores.txt");
  
  for(int i = 0; i < lines.length; i++) {
     System.out.println(lines[i]);
  }
  
  //show the scores
    //String[] lines = loadStrings("highScores.txt");
    fill(155);
    textSize(30);
    text("Last 10 games score", 100,50);
    
    textSize(11);
    
    for(int i = 0; i < lines.length; i++) {
      
      fill(155); 
      textSize(30);
      text(lines[i], 100, 75+(75*(i+1)));
      textSize(11);
    }
    
 // loop();


}

public void mouseDragged() {
  
 // println(mouseX);
 // println(mouseY);
  
  int x = (mouseX/20);
  int y = (mouseY/20);
  
  
  //if the game is in a game over state
  if(restartAvailable) {
    
    if( (mouseX >= 0) & (mouseX <= 400) ) {
      
      if( (mouseY >=0) & (mouseY <= 400) ) {
        
        
       //save the players score
        String[] lines = loadStrings("highScores.txt");
        
        System.out.println("lines.length"+lines.length);
        
        String[] newData;
        
        
        if(lines.length>=10) {
          newData = new String[10];
          newData[0] = String.valueOf(playerone.score);
        } else {
          newData = new String[lines.length+1];
          newData[0] = String.valueOf(playerone.score);
        }
        
        for(int i = 0; i < lines.length; i++) {
          
          newData[i+1] = lines[i];
          
        }
       
        
       
        
        saveStrings("data/highScores.txt",newData);
        
        
        
        restartAvailable = false;
        board.resetBoardVariables();
        board.pseudoConstructor();
        
        
        restartAvailable = false;

        potionSickness = false;
        potionTimer = 0;

        superSickness = false; 
        superTimer = 0; 

        //boolean shotGunSickness = false;
        shotGunTimer = 0;

        titleScreen = true;
        
        setup();
        loop();
      }
      
    }
    
  }
  
  
  
  //if the game is on the title screen
  if(titleScreen) {
    
    
    if(  (mouseX >= 575) & (mouseX <= 825) ) {
      
      if(  (mouseY >= 250) & (mouseY <= 350) ) {
        
        //the player is clicking the story mode button
        titleScreen = false;
        mainMenu.rewind();
        mainMenu.close();
        loop();
        
        
      }
      
      
      
    }
    
    
    
    if(  (mouseX >= 575) & (mouseX <= 825) ) {
      
      if(  (mouseY >= 400) & (mouseY <= 500) ) {
        
        //the player is clicking the leaderboard mode button
        titleScreen = true;
        showingScores = true;
       // loop();
        showScores();
       // loop();
        
      }
      
      
      
    }
    
    
    
  }
  
  
  
  //proves the clicking is on the correct square
  /*
  if(x < 70 && y < 40) {
    board.tiles[y][x].showYourself();
    println("I: " + y);
    println("J: " + x);
  }
  */
  //SHOOTING
  //if the player is clicking in the board and the tommy gun is active
  if( (x < 70) & (y < 40) & (playerone.active == 1)) {
    //println(playerone.getXC());
   // println(playerone.getYC());
   // println("bullet");
    if(!board.tommyGunSickness) {
      board.introduceBullet(x,y, playerone.getYC(), playerone.getXC(), playerone.getTommy(), false, false);  
    }
  }
  
  //if the player is click in the board and the shotgun is active
  if( (x < 70) & (y < 40) & (playerone.active == 2)) {
    
    if(!board.shotGunSickness) {
      board.introduceBullet(x,y, playerone.getYC(), playerone.getXC(), playerone.getShotty(), true, false);
    } 
    
  }
  
  
  
  //if the player is clicking in the board and the pickaxe is active
  if(x < 70 && y < 40 && playerone.active == 3) {
    board.tiles[y][x].clicked(playerone);
  }

 
  
  
}



public void mousePressed() {
  
 // println(mouseX);
  //println(mouseY);
  
  int x = (mouseX/20);
  int y = (mouseY/20);
  
  
  //if the game is in a game over state
  if(restartAvailable) {
    
    if( (mouseX >= 0) & (mouseX <= 400) ) {
      
      if( (mouseY >=0) & (mouseY <= 400) ) {
        
        
        
        //save the players score
        String[] lines = loadStrings("highScores.txt");
        
        System.out.println("lines.length"+lines.length);
        
        String[] newData;
        
        
        if(lines.length==10) {
          newData = new String[10];
          newData[0] = String.valueOf(playerone.score);
        } else {
          newData = new String[lines.length+1];
          newData[0] = String.valueOf(playerone.score);
        }
        
        
        for(int i = 0; i <= lines.length-1; i++) {
          if(i==9) {
            newData[9] = lines[9];
          } else {
            newData[i+1] = lines[i];
          }
          
        }
        
        
        
        saveStrings("data/highScores.txt",newData);
        
        
        
        restartAvailable = false;
        board.resetBoardVariables();
        board.pseudoConstructor();
        
        
        restartAvailable = false;

        potionSickness = false;
        potionTimer = 0;

        superSickness = false; 
        superTimer = 0; 

        //boolean shotGunSickness = false;
        shotGunTimer = 0;

        titleScreen = true;
        
        //GameBoard tempBoard = new GameBoard();
       // board = tempBoard;
        setup();
        loop();
      }
      
    }
    
  }
  
  
  
  //if the game is on the title screen
  if(titleScreen) {
    
    
    if(  (mouseX >= 575) & (mouseX <= 825) ) {
      
      if(  (mouseY >= 250) & (mouseY <= 350) ) {
        
        //the player is clicking the story mode button
        titleScreen = false;
        mainMenu.rewind();
        mainMenu.close();
        loop();
        
        
      }
      
      
      
    }
    
    if(  (mouseX >= 575) & (mouseX <= 825) ) {
      
      if(  (mouseY >= 400) & (mouseY <= 500) ) {
        
        //the player is clicking the leaderboard mode button
        titleScreen = true;
        showingScores = true;
        //loop();
        showScores();
        //loop();
        
      }
      
      
      
    }
    
    
    
  }
  
  //proves the clicking is on the correct square
  /*
  if(x < 70 && y < 40) {
    board.tiles[y][x].showYourself();
    println("I: " + y);
    println("J: " + x);
  }
  */
  //SHOOTING
  //if the player is clicking in the board and the tommy gun is active
  if(x < 70 && y < 40 && playerone.active == 1) {
    //println(playerone.getXC());
    //println(playerone.getYC());
    //println("bullet");
    if(!board.tommyGunSickness) {
      board.introduceBullet(x,y, playerone.getYC(), playerone.getXC(), playerone.getTommy(), false, false); 
    }
  }
  
  //if the player is click in the board and the shotgun is active
  if(x < 70 && y < 40 && playerone.active == 2) {
    
    if(!board.shotGunSickness) {
      board.introduceBullet(x,y, playerone.getYC(), playerone.getXC(), playerone.getShotty(), true, false);
    } 
    
  }
  
  
  
  //if the player is clicking in the board and the pickaxe is active
  if(x < 70 && y < 40 && playerone.active == 3) {
    board.tiles[y][x].clicked(playerone);
  }

  //this section holds the code to handle the user clicks in the HUD area
  if(mouseY > 800) {
    System.out.println("The user has clicked the HUD area"); 
    
    
    //handles armor upgrade choices
    if(mouseY >= 810 && mouseY <= 830) {
      System.out.println("Armor upgrade chosen"); 
      
      //handles which tier of armor upgrade was chosen
      if(mouseX >= 1135 && mouseX <= 1185) {
        System.out.println("Wood armor"); 
        playerone.applyArmor(1); 
      } else if (mouseX >= 1195 && mouseX <= 1245) {
        System.out.println("Iron armor"); 
        playerone.applyArmor(2); 
      } else if (mouseX >= 1255 && mouseX <= 1305) {
        System.out.println("Gold armor");  
        playerone.applyArmor(3);
      }
      
    //handles tommy gun upgrades  
    } else if (mouseY >= 840 && mouseY <=860) {
      System.out.println("Tommy Gun upgrade chosen"); 
      upgradeWeapon.play();
      
      //handles which tier of tommy upgrade was chosen
      if(mouseX >= 1135 && mouseX <= 1185) {
        System.out.println("Wood Tommy"); 
      } else if (mouseX >= 1195 && mouseX <= 1245) {
        System.out.println("Iron Tommy"); 
        board.giveWeapon("Iron Tommy"); 
      } else if (mouseX >= 1255 && mouseX <= 1305) {
        System.out.println("Gold Tommy");  
        board.giveWeapon("Gold Tommy");
      }
      
      
      
      
    //handles shotgun upgrades
    } else if (mouseY >= 870 && mouseY <= 890) {
      System.out.println("Shotgun upgrade chosen"); 
      upgradeWeapon.play();
      
      //handles which tier of shotgun upgrade was chosen
      if(mouseX >= 1135 && mouseX <= 1185) {
        System.out.println("Wood Shotgun"); 
      } else if (mouseX >= 1195 && mouseX <= 1245) {
        System.out.println("Iron Shotgun");
        board.giveWeapon("Iron Shotgun");
      } else if (mouseX >= 1255 && mouseX <= 1305) {
        System.out.println("Gold Shotgun");  
        board.giveWeapon("Gold Shotgun");
      }
    }
    
  }
  
}
class Ant extends Enemy {
  
  PImage[] images = new PImage[3];
  
  //100 health
  //20 attack
  
  
  //for testing spawns an ant (0,0)
  Ant() {
    super(100, 1, 0, 0, 0, 0, "Ant", 10);
    images[0] = loadImage("ant100.PNG");
    images[1] = loadImage("ant75.PNG"); 
    images[2] = loadImage("ant50.PNG");
  
    images[0].resize(20,20);
    images[1].resize(20,20);
    images[2].resize(20,20);
  }
  
  
  //for when the location is specified
  Ant(float x, float y) {
    super(100, 1, x, y, x/20, y/20, "Ant", 10);
    images[0] = loadImage("ant100.PNG");
    images[1] = loadImage("ant75.PNG"); 
    images[2] = loadImage("ant50.PNG");
  
    images[0].resize(20,20);
    images[1].resize(20,20);
    images[2].resize(20,20);
  }
  
  
  public void show() {
    
      if(this.health > 75) {
        image(images[0], this.xC, this.yC);
      } else if ( (this.health <= 75) & (this.health > 50)) {
        image(images[1], this.xC, this.yC);  
      } else if(this.health <= 50 & (this.health > 0)) {
        image(images[2], this.xC, this.yC);
      } else if(this.health <= 0) {
        this.die();
      }
    
    
  }
  
  public void move(int targetX, int targetY) {
    
    //make targetX and targetY into the graphics coordinate not index
      targetX = targetX*20; 
      targetY = targetY*20;
    
      //accidentaly switched them somewhere along the line
      int temp = targetY; 
      targetY = targetX; 
      targetX = temp;
      
      
      int myLocX = (int)this.xC; 
        int myLocY = (int)this.yC;
      
        //System.out.println("MyLocX: " + myLocX); 
        //System.out.println("MyLocY: " + myLocY); 
        //System.out.println("TargetX: " + targetX); 
        //System.out.println("TargetY: " + targetY); 
      
      
        if( (targetX > myLocX)&(targetY > myLocY) ) {
        
          //System.out.println("TOOK A STEP FOR REAL 1"); 
        
          this.xC = this.xC+20; 
          this.yC = this.yC+20;
        
          this.indexI = this.indexI+1; 
          this.indexJ = this.indexJ+1; 
        
        } else if ( (targetX > myLocX)&(targetY<myLocY) ) {
        
          //System.out.println("TOOK A STEP FOR REAL 2"); 
        
          this.xC = this.xC+20; 
          this.yC = this.yC-20;
        
          this.indexI = this.indexI+1; 
          this.indexJ = this.indexJ-1; 
        
        } else if ( (targetX < myLocX)&(targetY < myLocY) ) {
        
          //System.out.println("TOOK A STEP FOR REAL 3"); 
        
          this.xC = this.xC-20; 
          this.yC = this.yC-20;
        
          this.indexI = this.indexI-1; 
          this.indexJ = this.indexJ-1; 
        
      } else if ( (targetX < myLocX)&(targetY > myLocY) ) {
        
        //System.out.println("TOOK A STEP FOR REAL 4"); 
        
        this.xC = this.xC-20; 
        this.yC = this.yC+20;
        
        this.indexI = this.indexI-1; 
        this.indexJ = this.indexJ+1; 
        
      } else if ( (targetX == myLocX)&(targetY > myLocY) ) {
        
        //System.out.println("TOOK A STEP FOR REAL 5");
        
        this.yC = this.yC+20; 
        
        this.indexJ = this.indexJ+1; 
        
      } else if ( (targetX == myLocX)&(targetY < myLocY) ) {
        
        //System.out.println("TOOK A STEP FOR REAL 6");
        
        this.yC = this.yC-20; 
        
        this.indexJ = this.indexJ-1; 
        
      } else if ( (targetX > myLocX)&(targetY == myLocY) ) {
        
        //System.out.println("TOOK A STEP FOR REAL 7"); 
        
        this.xC = this.xC+20;
        
        this.indexI = this.indexI+1; 
        
      } else if ( (targetX < myLocX)&(targetY == myLocY) ) {
        
        //System.out.println("TOOK A STEP FOR REAL 8"); 
        
        this.xC = this.xC-20; 
        
        this.indexI = this.indexI-1; 
        
      }
    
  }
  
  
}
class Armor {
  
  String tier = "null"; 
  String name = "null";
  boolean buildable; 
  int cost; 
  int armorValue = 0;
  int colour; 
  
  Armor() {
    
  }
  
  Armor(String t, String n, boolean build, int c, int aV, int col) {
  tier = t; 
  name = n; 
  buildable = build; 
  cost = c; 
  armorValue = aV;
  colour = col;
 }
 
 //getters 
  public void setTier(String t) {
    tier = t; 
  }
 
  public void setName(String n) {
    name = n;
  }
 
  public void setBuildable(boolean b) {
    buildable = b; 
  }
  
  //setters
  public int getCost() {
    return cost; 
  }
  
  public boolean getBuildable() {
    return buildable; 
  }
 
  
}
class Bullet {
  
  float speedX; 
  float speedY;
  
  int speedXMultiple; 
  int speedYMultiple; 
  int size; 
  int timesAnimated; 
  
  float xCoor; 
  float yCoor; 
  
  int damage; 
  String shotFrom; 
  
  boolean status = true;
  
  Bullet() {
    speedX = 0; 
    speedY = 0;
    speedXMultiple = 5;
    speedYMultiple = 5;
  }
  
  Bullet(float speedXIN, float speedYIN, int shotFromX, int shotFromY, boolean alive, int dmg, String sf) {
    speedX = speedXIN; 
    speedY = speedYIN; 
    xCoor = shotFromX;
    yCoor = shotFromY; 
    status = alive; 
    damage = dmg; 
    //System.out.println(damage); 
    shotFrom = sf; 
    
  }
  
  public void setSpeedX(float sx) {
    speedX = sx*speedXMultiple; 
  }
  
  public void setSpeedY(float sy) {
    speedY = sy*speedYMultiple; 
  }
  
  public void setLocX(float lx) {
    xCoor = lx; 
  }
  
  public void setLocY(float ly) {
    yCoor = ly; 
  }
  
  public void setDamage(int d) {
    damage = d;
  }
  
  public void setShotFrom(String s) {
    shotFrom = s; 
  }
  
  
  public int getDamage() { 
    return damage; 
  }
  
  public String getShotFrom() {
    return shotFrom; 
  }
  
  public boolean getStatus() { 
    return status; 
  }
  
  //determines if the bullet is on the screen or not
  public void checkStatus() {
    
    if (xCoor < 0) {
      this.status = false; 
    }
    
    if (yCoor < 0) {
      this.status = false; 
    }
    
    if (xCoor > 1400) {
      this.status = false; 
    }
    
    if (yCoor > 800) {
      this.status = false; 
    }
    
    
  }
  
  Bullet(float spX, float spY, int sze, int x, int y) {
    speedX = spX;
    speedY = spY; 
    size = sze; 
    xCoor = x; 
    yCoor = y; 
    
  }
  
}
class CannonBullet {
  
  float speedX; 
  float speedY;
  
  int speedXMultiple; 
  int speedYMultiple; 
  int size; 
  
  float xCoor; 
  float yCoor; 
  
  int damage; 
  
  boolean status = true;
  
  CannonBullet() {
    speedX = 0; 
    speedY = 0;
    speedXMultiple = 5;
    speedYMultiple = 5;
  }
  
  public void setSpeedX(float sx) {
    speedX = sx*speedXMultiple; 
  }
  
  public void setSpeedY(float sy) {
    speedY = sy*speedYMultiple; 
  }
  
  public void setLocX(float lx) {
    xCoor = lx; 
  }
  
  public void setLocY(float ly) {
    yCoor = ly; 
  }
  
  public void setDamage(int d) {
    damage = d;
  }
  
  public void setXC(int xc) {
    xCoor = xc; 
  }
  
  public void setYC(int yc) {
    yCoor = yc; 
  }
  
  public int getDamage() { 
    return damage; 
  }
  
  public int getSpeedX() {
    return (int)speedX;  
  }
  
  public int getSpeedY() {
    return (int)speedY; 
  }
  
  public int getXC() {
    return (int)xCoor; 
  }
  
  public int getYC() {
    return (int)yCoor; 
  }
  
  public int getSize() {
    return size; 
  }
  
  public boolean getStatus() {
    return status; 
  }
 
  //determines if the bullet is on the screen or not
  public void checkStatus() {
    
    if (xCoor < 0) {
      this.status = false; 
    }
    
    if (yCoor < 0) {
      this.status = false; 
    }
    
    if (xCoor > 1400) {
      this.status = false; 
    }
    
    if (yCoor > 800) {
      this.status = false; 
    }
    
    
  }
  
  CannonBullet(float spX, float spY, int sze, int x, int y, int d) {
    speedX = spX;
    speedY = spY; 
    size = sze; 
    xCoor = x; 
    yCoor = y; 
    damage = d;
  }
  
}
class ElectroDuo extends Enemy {
  
  
  //100 health
  //20 attack
  
  PImage[] images = new PImage[3];
  
 
  ElectroDuo() {
    super(500, 5, 0, 0, 0, 0, "ElectroDuo", 25);
    
    images[0] = loadImage("electroDuo.png");
    images[1] = loadImage("electroDuo75.png"); 
    images[2] = loadImage("electroDuo50.png");
  
    images[0].resize(40,40);
    images[1].resize(40,40);
    images[2].resize(40,40);
  }
  
  
  //for when the location is specified
  ElectroDuo(float x, float y) {
    super(500, 10, x, y, x/20, y/20, "ElectroDuo", 25);
    
    images[0] = loadImage("electroDuo.png");
    images[1] = loadImage("electroDuo75.png"); 
    images[2] = loadImage("electroDuo50.png");
  
    images[0].resize(40,40);
    images[1].resize(40,40);
    images[2].resize(40,40);
  }
  
  
   public void show() {
    
      if(this.health > 350) {
        image(images[0], this.xC, this.yC);
      } else if ( (this.health <= 350) & (this.health > 200)) {
        image(images[1], this.xC, this.yC);  
      } else if(this.health <= 200 & (this.health > 0)) {
        image(images[2], this.xC, this.yC);
      } else if(this.health <= 0) {
        this.die();
      }
    
    
  }
  
  public void move(int targetX, int targetY) {
    this.flowerFlop = this.flowerFlop + 1; 
    
    //make targetX and targetY into the graphics coordinate not index
    targetX = targetX*20; 
    targetY = targetY*20;
    
    //accidentaly switched them somewhere along the line
    int temp = targetY; 
    targetY = targetX; 
    targetX = temp;
      
      
    int myLocX = (int)this.xC; 
    int myLocY = (int)this.yC;
    
    
    if(0 == (flowerFlop%2)) {
      
      /* 1
        xxxxxxxxxxx
        xxxMxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxTxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
        if( (targetX > myLocX)&(targetY > myLocY) ) {
        
          //System.out.println("TOOK A STEP FOR REAL 1"); 
        
          this.xC = this.xC+20; 
          this.yC = this.yC+20;
        
          this.indexI = this.indexI+1; 
          this.indexJ = this.indexJ+1; 
        
        
        
        /* 2
        xxxxxxxxxxx
        xxxxxxxxxTx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxMxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
        } else if ( (targetX > myLocX)&(targetY<myLocY) ) {
        
          //System.out.println("TOOK A STEP FOR REAL 2"); 
        
          this.xC = this.xC+20; 
          this.yC = this.yC-20;
        
          this.indexI = this.indexI+1; 
          this.indexJ = this.indexJ-1; 
        
        
        /* 3
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxTxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxMxx
        xxxxxxxxxxx
        */
        } else if ( (targetX < myLocX)&(targetY < myLocY) ) {
        
          //System.out.println("TOOK A STEP FOR REAL 3"); 
        
          this.xC = this.xC-20; 
          this.yC = this.yC-20;
        
          this.indexI = this.indexI-1; 
          this.indexJ = this.indexJ-1; 
        
        
        /* 4
        xxxxxxxxxxx
        xxxxxxxxMxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxTxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX < myLocX)&(targetY > myLocY) ) {
        
        //System.out.println("TOOK A STEP FOR REAL 4"); 
        
        this.xC = this.xC-20; 
        this.yC = this.yC+20;
        
        this.indexI = this.indexI-1; 
        this.indexJ = this.indexJ+1; 
        
        
        /* 5
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxMxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxTxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX == myLocX)&(targetY > myLocY) ) {
        
        //flower shoots down the lane
        System.out.println("Flower shooting");
        
        this.needToShoot = true;
        
        /* 6
        xxxxxxxxxxx
        xxxxTxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxMxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX == myLocX)&(targetY < myLocY) ) {
        
        //flower shoots up the lane
        System.out.println("Flower shooting");
        
        this.needToShoot = true;
        
        /* 7
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxMxxxxxTxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX > myLocX)&(targetY == myLocY) ) {
        
        //flower shoots the the right horizontally
        System.out.println("Flower shooting");
        
        this.needToShoot = true;
        
        /* 8
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxTxxxxxMxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX < myLocX)&(targetY == myLocY) ) {
        
        //flower shoot to the left horizontally
        System.out.println("Flower shooting");
        
        this.needToShoot = true;
      }
     
      
    }
    
    
  }
  
}
class ElectroMan extends Enemy {
  
   PImage[] images = new PImage[3];

  ElectroMan() {
    super(250, 2, 0, 0, 0, 0, "ElectroMan", 15);
    
    images[0] = loadImage("electroMan.png");
    images[1] = loadImage("electroMan75.png"); 
    images[2] = loadImage("electroMan50.png");
  
    images[0].resize(20,20);
    images[1].resize(20,20);
    images[2].resize(20,20);
  }
  
  
  //for when the location is specified
  ElectroMan(float x, float y) {
    super(250, 2, x, y, x/20, y/20, "ElectroMan", 15);
    
    images[0] = loadImage("electroMan.png");
    images[1] = loadImage("electroMan75.png"); 
    images[2] = loadImage("electroMan50.png");
  
    images[0].resize(20,20);
    images[1].resize(20,20);
    images[2].resize(20,20);
  }
  
  
   public void show() {
    
      if(this.health > 175) {
        image(images[0], this.xC, this.yC);
      } else if ( (this.health <= 175) & (this.health > 100)) {
        image(images[1], this.xC, this.yC);  
      } else if(this.health <= 100 & (this.health > 0)) {
        image(images[2], this.xC, this.yC);
      } else if(this.health <= 0) {
        this.die();
      }
    
    
  }
  
  
   public void move(int targetX, int targetY) {
    
    //make targetX and targetY into the graphics coordinate not index
      targetX = targetX*20; 
      targetY = targetY*20;
    
      //accidentaly switched them somewhere along the line
      int temp = targetY; 
      targetY = targetX; 
      targetX = temp;
      
      
      int myLocX = (int)this.xC; 
        int myLocY = (int)this.yC;
      
        //System.out.println("MyLocX: " + myLocX); 
        //System.out.println("MyLocY: " + myLocY); 
        //System.out.println("TargetX: " + targetX); 
        //System.out.println("TargetY: " + targetY); 
      
      
        if( (targetX > myLocX)&(targetY > myLocY) ) {
        
          //System.out.println("TOOK A STEP FOR REAL 1"); 
        
          this.xC = this.xC+20; 
          this.yC = this.yC+20;
        
          this.indexI = this.indexI+1; 
          this.indexJ = this.indexJ+1; 
        
        } else if ( (targetX > myLocX)&(targetY<myLocY) ) {
        
          //System.out.println("TOOK A STEP FOR REAL 2"); 
        
          this.xC = this.xC+20; 
          this.yC = this.yC-20;
        
          this.indexI = this.indexI+1; 
          this.indexJ = this.indexJ-1; 
        
        } else if ( (targetX < myLocX)&(targetY < myLocY) ) {
        
          //System.out.println("TOOK A STEP FOR REAL 3"); 
        
          this.xC = this.xC-20; 
          this.yC = this.yC-20;
        
          this.indexI = this.indexI-1; 
          this.indexJ = this.indexJ-1; 
        
      } else if ( (targetX < myLocX)&(targetY > myLocY) ) {
        
        //System.out.println("TOOK A STEP FOR REAL 4"); 
        
        this.xC = this.xC-20; 
        this.yC = this.yC+20;
        
        this.indexI = this.indexI-1; 
        this.indexJ = this.indexJ+1; 
        
      } else if ( (targetX == myLocX)&(targetY > myLocY) ) {
        
        //System.out.println("TOOK A STEP FOR REAL 5");
        
        this.yC = this.yC+20; 
        
        this.indexJ = this.indexJ+1; 
        
      } else if ( (targetX == myLocX)&(targetY < myLocY) ) {
        
        //System.out.println("TOOK A STEP FOR REAL 6");
        
        this.yC = this.yC-20; 
        
        this.indexJ = this.indexJ-1; 
        
      } else if ( (targetX > myLocX)&(targetY == myLocY) ) {
        
        //System.out.println("TOOK A STEP FOR REAL 7"); 
        
        this.xC = this.xC+20;
        
        this.indexI = this.indexI+1; 
        
      } else if ( (targetX < myLocX)&(targetY == myLocY) ) {
        
        //System.out.println("TOOK A STEP FOR REAL 8"); 
        
        this.xC = this.xC-20; 
        
        this.indexI = this.indexI-1; 
        
      }
    
  }
  
  
}
class ElectroQuad extends Enemy {
  
  
  //100 health
  //20 attack
  
   PImage[] images = new PImage[3];
  
  
  //for testing spawns an ant (0,0)
  ElectroQuad() {
    super(1000, 3, 0, 0, 0, 0, "ElectroQuad", 50);
    
    
    images[0] = loadImage("electroQuad.png");
    images[1] = loadImage("electroQuad75.png"); 
    images[2] = loadImage("electroQuad50.png");
  
    images[0].resize(40,40);
    images[1].resize(40,40);
    images[2].resize(40,40);
  }
  
  
  //for when the location is specified
  ElectroQuad(float x, float y) {
    super(1000, 10, x, y, x/20, y/20, "ElectroQuad", 50);
    
    
    images[0] = loadImage("electroQuad.png");
    images[1] = loadImage("electroQuad75.png"); 
    images[2] = loadImage("electroQuad50.png");
  
    images[0].resize(40,40);
    images[1].resize(40,40);
    images[2].resize(40,40);
  }
  
  
   public void show() {
    
     if(this.health > 600) {
        image(images[0], this.xC, this.yC);
      } else if ( (this.health <= 600) & (this.health > 300)) {
        image(images[1], this.xC, this.yC);  
      } else if(this.health <= 300 & (this.health > 0)) {
        image(images[2], this.xC, this.yC);
      } else if(this.health <= 0) {
        this.die();
      }
    
  }
  
  public void move(int targetX, int targetY) {
    
  //  System.out.println("Robot MOVING");
    
     //make targetX and targetY into the graphics coordinate not index
    targetX = targetX*20; 
    targetY = targetY*20;
    
    //accidentaly switched them somewhere along the line
    int temp = targetY; 
    targetY = targetX; 
    targetX = temp;
      
      
      int myLocX = (int)this.xC; 
        int myLocY = (int)this.yC;
        
        //System.out.println("MyLocX: " + myLocX); 
        //System.out.println("MyLocY: " + myLocY); 
        //System.out.println("TargetX: " + targetX); 
        //System.out.println("TargetY: " + targetY);
        
        /* 1
        xxxxxxxxxxx
        xxxMxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxTxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
        if( (targetX > myLocX)&(targetY > myLocY) ) {
        
          //System.out.println("TOOK A STEP FOR REAL 1"); 
          
          int xDifference = (int)(targetX - myLocX)/20;
          int yDifference = (int)(targetY - myLocY)/20;
          
          if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
          int totalDifference = xDifference + yDifference; 
          
          //if the target is somewhat far away, move towards them
          if(totalDifference >=  25) {
          
             this.xC = this.xC+20; 
             this.yC = this.yC+20;
        
             this.indexI = this.indexI+1; 
             this.indexJ = this.indexJ+1;
            
          //if the target is close, take shots   
          } else {
            
            this.needToShoot = true;
            
            
          }
          
     
        /* 2
        xxxxxxxxxxx
        xxxxxxxxxTx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxMxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
        } else if ( (targetX > myLocX)&(targetY<myLocY) ) {
        
          //System.out.println("TOOK A STEP FOR REAL 2"); 
          int xDifference = (int)(targetX - myLocX)/20;
          int yDifference = (int)(targetY - myLocY)/20;
          
          if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
          int totalDifference = xDifference + yDifference; 
          
          //if the target is somewhat far away, move towards them
          if(totalDifference >=  25) {
          
            this.xC = this.xC+20; 
            this.yC = this.yC-20;
        
            this.indexI = this.indexI+1; 
            this.indexJ = this.indexJ-1; 
            
          //if the target is close, take shots   
          } else {
            
            this.needToShoot = true;
            
            
          }
          
        
        /* 3
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxTxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxMxx
        xxxxxxxxxxx
        */
        } else if ( (targetX < myLocX)&(targetY < myLocY) ) {
        
          //System.out.println("TOOK A STEP FOR REAL 3"); 
          
          
          int xDifference = (int)(targetX - myLocX)/20;
          int yDifference = (int)(targetY - myLocY)/20;
          
          if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
          int totalDifference = xDifference + yDifference; 
          
          //if the target is somewhat far away, move towards them
          if(totalDifference >=  25) {
          
            this.xC = this.xC-20; 
            this.yC = this.yC-20;
        
            this.indexI = this.indexI-1; 
            this.indexJ = this.indexJ-1; 
         
            
          //if the target is close, take shots   
          } else {
            
            this.needToShoot = true;
            
            
          }
        
        
        /* 4
        xxxxxxxxxxx
        xxxxxxxxMxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxTxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX < myLocX)&(targetY > myLocY) ) {
        
        //System.out.println("TOOK A STEP FOR REAL 4"); 
        
         int xDifference = (int)(targetX - myLocX)/20;
         int yDifference = (int)(targetY - myLocY)/20;
         
         if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
         int totalDifference = xDifference + yDifference; 
          
        
        //if the target is somewhat far away, move towards them
          if(totalDifference >=  25) {
          
             this.xC = this.xC-20; 
             this.yC = this.yC+20;
        
             this.indexI = this.indexI-1; 
             this.indexJ = this.indexJ+1; 
        
         
            
          //if the target is close, take shots   
          } else {
            
            this.needToShoot = true;
            
            
          }
        

        /* 5
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxMxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxTxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX == myLocX)&(targetY > myLocY) ) {
        
         int xDifference = (int)(targetX - myLocX)/20;
         int yDifference = (int)(targetY - myLocY)/20;
         
         if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
         int totalDifference = xDifference + yDifference; 
          
        
        //if the target is somewhat far away, move towards them
          if(totalDifference >=  25) {
          
              
             this.yC = this.yC+20;
             this.indexJ = this.indexJ+1; 
        
         
            
          //if the target is close, take shots   
          } else {
            
            this.needToShoot = true;
            
            
          }
        
        
       
        
        /* 6
        xxxxxxxxxxx
        xxxTxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxMxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX == myLocX)&(targetY < myLocY) ) {
        
        int xDifference = (int)(targetX - myLocX)/20;
         int yDifference = (int)(targetY - myLocY)/20;
         
         if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
         int totalDifference = xDifference + yDifference; 
          
        
        //if the target is somewhat far away, move towards them
          if(totalDifference >=  25) {
          
              
             this.yC = this.yC-20;
             this.indexJ = this.indexJ-1; 
        
         
            
          //if the target is close, take shots   
          } else {
            
            this.needToShoot = true;
            
            
          }
      
       
        
        /* 7
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxMxxxxxTxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX > myLocX)&(targetY == myLocY) ) {
        
        int xDifference = (int)(targetX - myLocX)/20;
         int yDifference = (int)(targetY - myLocY)/20;
         
         if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
         int totalDifference = xDifference + yDifference; 
          
        
        //if the target is somewhat far away, move towards them
          if(totalDifference >=  25) {
          
              
             this.xC = this.xC+20;
             this.indexI = this.indexI+1; 
        
         
            
          //if the target is close, take shots   
          } else {
            
            this.needToShoot = true;
            
            
          }
        
        
       
        
        /* 8
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxTxxxxxMxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX < myLocX)&(targetY == myLocY) ) {
        
         int xDifference = (int)(targetX - myLocX)/20;
         int yDifference = (int)(targetY - myLocY)/20;
         
         if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
         int totalDifference = xDifference + yDifference; 
          
        
        //if the target is somewhat far away, move towards them
          if(totalDifference >=  25) {
          
              
             this.xC = this.xC - 20;
             this.indexI = this.indexI-1; 
        
         
            
          //if the target is close, take shots   
          } else {
            
            this.needToShoot = true;
            
            
          }
        
        
        
      }
    
  }
  
  
}
abstract class Enemy {
  
  int health; 
  int attack; 
  
  float xC;
  float yC;
  
  float indexI;
  float indexJ;
  
  int score; 
  
  String enemyType; 
  
  int id; 
  
  int flowerFlop = 0;
  
  boolean shotSickness = false;
  
  boolean status = true; 
  boolean needToShoot = false;
  
  //enemy will move differently when playing in a swarm
  boolean intelligenceApplied = false; 
  
  
  Enemy() {
    
    
  }
  
  Enemy(int h, int a, float coorX, float coorY, float iI, float iJ, String eT, int sc) {
    health = h; 
    attack = a; 
    xC = coorX; 
    yC = coorY; 
    indexI = iI; 
    indexJ = iJ; 
    enemyType = eT;
    status = true;
    score = sc;
  }
  
  public String getEnemyType() {
    return enemyType;  
  }
  
  public boolean getShotExpulsion() {
    return needToShoot; 
  }
  
  public boolean getIntelligence() {
    return intelligenceApplied; 
  }
  
  public int getScore() {
    return score; 
  }
  
  public float getXC() {
    return xC; 
  }
  
  public float getYC() {
    return yC; 
  }
  
  public int getAttack() {
    return attack; 
    
  }
  
  public void setIntelligence(boolean i) {
    intelligenceApplied = i;
    
  }
  
  public void setNeedToShoot(boolean b) {
    this.needToShoot = b; 
  }
  
  public boolean receiveDamage(int damage) {
    
     //System.out.println("Enemies current health: " + this.health);
    
    //take the damage off the the enemies health
    this.health = this.health - damage; 
    
    //System.out.println("Enemies current health after damage: " + this.health);
    
    //if this enemy has died
    if(this.health <= 0) {
      //trigger the death function
      this.status = false;
      
      return true;
    }
    
    return false;
    
  }
  
  public boolean dealDamage(Player p) {
    if(status) {
      boolean death = p.takeDamage(attack);
      return death;
    }
    return false;
  }
  
  //issue: incoming targetX, targetY is in index, not graphics amount
  public void move(int targetX, int targetY) { }
  
  public void show() {}
  
  
 
  public void die() {
    System.out.println("Dying"); 
    status = false; 
    
    if(this.enemyType == "Phalax") {
      //trigger a biome switch due to grassland mini boss defeat
      System.out.println("A Phalax mini boss has been defeated");
    }
    
    
    
  }
  
  
}
class Flower extends Enemy {
  
   PImage[] images = new PImage[3];
  
  //100 health
  //20 attack
  
  int flowerFlop = 0; 
  
  //for testing spawns a flower (0,0)
  Flower() {
    super(100, 2, 0, 0, 0, 0, "Flower", 25);
    images[0] = loadImage("flower100.PNG"); 
    images[1] = loadImage("flower75.PNG");
    images[2] = loadImage("flower50.PNG");
    
    images[0].resize(20,20);
    images[1].resize(20,20);
    images[2].resize(20,20);
  }
  
  
  //for when the location is specified
  Flower(float x, float y) {
    super(100, 2, x, y, x/20, y/20, "Flower", 25);
    images[0] = loadImage("flower100.PNG"); 
    images[1] = loadImage("flower75.PNG");
    images[2] = loadImage("flower50.PNG");
    
    images[0].resize(20,20);
    images[1].resize(20,20);
    images[2].resize(20,20);
  }
  
  public void show() {
    
      if(this.health > 75) {
        image(images[0], this.xC, this.yC);
      } else if ( (this.health <= 75) & (this.health > 50)) {
        image(images[1], this.xC, this.yC);  
      } else if(this.health <= 50 & (this.health > 0)) {
        image(images[2], this.xC, this.yC);
      } else if(this.health <= 0) {
        this.die();
      }
    
    
  }
  
  
  public void move(int targetX, int targetY) {
    this.flowerFlop = this.flowerFlop + 1; 
    
    //make targetX and targetY into the graphics coordinate not index
    targetX = targetX*20; 
    targetY = targetY*20;
    
    //accidentaly switched them somewhere along the line
    int temp = targetY; 
    targetY = targetX; 
    targetX = temp;
      
      
    int myLocX = (int)this.xC; 
    int myLocY = (int)this.yC;
    
    
    if(0 == (flowerFlop%2)) {
      
      /* 1
        xxxxxxxxxxx
        xxxMxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxTxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
        if( (targetX > myLocX)&(targetY > myLocY) ) {
        
          //System.out.println("TOOK A STEP FOR REAL 1"); 
        
          this.xC = this.xC+20; 
          this.yC = this.yC+20;
        
          this.indexI = this.indexI+1; 
          this.indexJ = this.indexJ+1; 
        
        
        
        /* 2
        xxxxxxxxxxx
        xxxxxxxxxTx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxMxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
        } else if ( (targetX > myLocX)&(targetY<myLocY) ) {
        
          //System.out.println("TOOK A STEP FOR REAL 2"); 
        
          this.xC = this.xC+20; 
          this.yC = this.yC-20;
        
          this.indexI = this.indexI+1; 
          this.indexJ = this.indexJ-1; 
        
        
        /* 3
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxTxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxMxx
        xxxxxxxxxxx
        */
        } else if ( (targetX < myLocX)&(targetY < myLocY) ) {
        
          //System.out.println("TOOK A STEP FOR REAL 3"); 
        
          this.xC = this.xC-20; 
          this.yC = this.yC-20;
        
          this.indexI = this.indexI-1; 
          this.indexJ = this.indexJ-1; 
        
        
        /* 4
        xxxxxxxxxxx
        xxxxxxxxMxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxTxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX < myLocX)&(targetY > myLocY) ) {
        
        //System.out.println("TOOK A STEP FOR REAL 4"); 
        
        this.xC = this.xC-20; 
        this.yC = this.yC+20;
        
        this.indexI = this.indexI-1; 
        this.indexJ = this.indexJ+1; 
        
        
        /* 5
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxMxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxTxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX == myLocX)&(targetY > myLocY) ) {
        
        //flower shoots down the lane
        System.out.println("Flower shooting");
        
        this.needToShoot = true;
        
        /* 6
        xxxxxxxxxxx
        xxxxTxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxMxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX == myLocX)&(targetY < myLocY) ) {
        
        //flower shoots up the lane
        System.out.println("Flower shooting");
        
        this.needToShoot = true;
        
        /* 7
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxMxxxxxTxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX > myLocX)&(targetY == myLocY) ) {
        
        //flower shoots the the right horizontally
        System.out.println("Flower shooting");
        
        this.needToShoot = true;
        
        /* 8
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxTxxxxxMxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX < myLocX)&(targetY == myLocY) ) {
        
        //flower shoot to the left horizontally
        System.out.println("Flower shooting");
        
        this.needToShoot = true;
      }
     
      
    }
    
    
  }
  
}
class FlowerBullet {
  
  float speedX; 
  float speedY;
  
  int speedXMultiple; 
  int speedYMultiple; 
  int size; 
  
  float xCoor; 
  float yCoor; 
  
  int damage; 
  
  boolean status = true;
  
  PImage images[] = new PImage[4]; 
  
  FlowerBullet() {
    
    images[0] = loadImage("flowerBullet.png");
    images[1] = loadImage("flowerBulletDownTest.png"); 
    images[2] = loadImage("flowerBulletLeft.png"); 
    images[3] = loadImage("flowerBulletUpTest.png");
    images[0].resize(20,20);
    images[1].resize(20,20);
    images[2].resize(20,20);
    images[3].resize(20,20);
   
    speedX = 0; 
    speedY = 0;
    speedXMultiple = 5;
    speedYMultiple = 5;
  }
  
  
  public void show() {
    
   if(speedX == 0) {
     
     if(speedY < 0) {
       image(images[3],this.xCoor,this.yCoor);
       
     } else {
       image(images[1],this.xCoor,this.yCoor);
       
     }
     
   } else {
     
     if(speedX < 0) {
       image(images[2],this.xCoor,this.yCoor);
       
     } else {
        image(images[0],this.xCoor,this.yCoor);
       
     }
     
     
     
   }
    
    
  }
  
  public void setSpeedX(float sx) {
    speedX = sx*speedXMultiple; 
  }
  
  public void setSpeedY(float sy) {
    speedY = sy*speedYMultiple; 
  }
  
  public void setLocX(float lx) {
    xCoor = lx; 
  }
  
  public void setLocY(float ly) {
    yCoor = ly; 
  }
  
  public void setDamage(int d) {
    damage = d;
  }
  
  public void setXC(int xc) {
    xCoor = xc; 
  }
  
  public void setYC(int yc) {
    yCoor = yc; 
  }
  
  public int getDamage() { 
    return damage; 
  }
  
  public int getSpeedX() {
    return (int)speedX;  
  }
  
  public int getSpeedY() {
    return (int)speedY; 
  }
  
  public int getXC() {
    return (int)xCoor; 
  }
  
  public int getYC() {
    return (int)yCoor; 
  }
  
  public int getSize() {
    return size; 
  }
  
  public boolean getStatus() {
    return status; 
  }
 
  //determines if the bullet is on the screen or not
  public void checkStatus() {
    
    if (xCoor < 0) {
      this.status = false; 
    }
    
    if (yCoor < 0) {
      this.status = false; 
    }
    
    if (xCoor > 1400) {
      this.status = false; 
    }
    
    if (yCoor > 800) {
      this.status = false; 
    }
    
    
  }
  
  FlowerBullet(float spX, float spY, int sze, int x, int y, int d) {
    
    images[0] = loadImage("flowerBullet.png");
    images[1] = loadImage("flowerBulletDownTest.png"); 
    images[2] = loadImage("flowerBulletLeft.png"); 
    images[3] = loadImage("flowerBulletUpTest.png");
    images[0].resize(20,20);
    images[1].resize(20,20);
    images[2].resize(20,20);
    images[3].resize(20,20);
    
    
    speedX = spX;
    speedY = spY; 
    size = sze; 
    xCoor = x; 
    yCoor = y; 
    damage = d;
  }
  
}

PFont f;

boolean plantedTrees = false;
boolean plantedTreesInSteel = false; 
boolean plantedTreesInTropical = false;

boolean collision = false;


class GameBoard {
  
  //2D 40x70 array of tile objects to represent the game board
  Tile[][] tiles = new Tile[40][70];
  Player[] players = new Player[10];
  PImage[] imageList; 
  
  int bulletSize = 10; 
  int score = 0; 
  
  String currentBiome = "grassland"; 
  
  boolean phalaxDeath = false; 
  boolean hiveMasterDeath = false; 
  
  boolean shotGunSickness = false;
  int shotGunAnimationTick = 0;
  
  boolean tommyGunSickness = false; 
  int tommyGunAnimationTick = 0; 
  
  int pirateSicknessCounter = 0;
  boolean pirateSickness = false;
  
  int waterLoc = -1;
  
  //arrays to store items available for build
  //allocated with the max possible amount of available build options because they are very small in size
  Armor[] armorAvailable = new Armor[3];     //wood, iron, gold 
  Weapon[] weaponAvailable = new Weapon[7]; //wood, iron, gold versions of shotgun and tommy gun respectively
  
  //maximum number of bullets at once is 200,000 if there are any more then this
  
  //-> functionality needed: dump all bullets not on screen and restart bullet numbering
  
  //contains all of the bullets currently flying through the air
  Bullet[] bullets = new Bullet[20000];
  int bulletsInAction = 0; 
  
  ArrayList<Bullet> playerBullets = new ArrayList<Bullet>();
  
  
  //contains all of the flower bullets currently flying through the air
  ArrayList<FlowerBullet> flowerBullets = new ArrayList<FlowerBullet>();
  
  
  //contains all of the robot bullets currently flying through the air
  ArrayList<RobotBullet> robotBullets = new ArrayList<RobotBullet>();
  
  
  ArrayList<HiveBullet> hiveBullets = new ArrayList<HiveBullet>();
  
  //contains all of the phalax bullets currently flying through the air
  ArrayList<PhalaxBullet> phalaxBullets = new ArrayList<PhalaxBullet>();
  
  
  ArrayList<CannonBullet> cannonBullets = new ArrayList<CannonBullet>();
  //difficulty tracker
  
  //testing
  //int difficulty = 17500; 
  int difficulty = 0; 
  int difficultyStepper = 6; 
  int difficultyStepperFlower = 6;
  int difficultyStepperRobot = 6;
  int difficultyStepperEQuad = 6;
  int difficultyStepperMonkey = 2; 
  int difficultyStepperGorilla = 4; 
  
  //contations all of the enemies currently on the screen
  
  //TESTING ENEMIES
  //Enemy[] enemies = new Enemy[1000];
  int enemiesInAction = 1; 
  
  ArrayList<Enemy> enemies = new ArrayList<Enemy>(); 
  
  
  //TESTING ENEMIES
  boolean initialEnemies = false; 
  
  boolean spawningFlowers = false;
  boolean spawningRobots = false;
  boolean spawningElectroQuads = false;
  boolean spawningMonkeys = false; 
  boolean spawningGorillas = false;
  
  Random r;
  
  int spawner = 0; 
  
  int flowerSpawner = 0;
  
  int robotSpawner = 0; 
  
  int electroQuadSpawner = 0; 
  
  int monkeySpawner = 0; 

  int gorillaSpawner = 0; 
     
    
  GameBoard() {
    
    
    //initialize all of the tiles in the array used to represent our gameboard
    for(int i = 0; i < 40; i++) {
      
      for(int j = 0; j < 70; j++) {
        tiles[i][j] = new Tile();
      }
      
    }
    
    //initialize the player array
    for(int i = 0; i < 10; i++) {
      players[i] = new Player();
    }
    
    //initialize the bullet array
    //for(int i = 0; i < 20000; i++) {
     // bullets[i] = new Bullet(); 
    //}
    
    
    //TESTING ENEMIES
    
    //TESTING ENEMIES
    
    //intialize the armor and weapon arrays
    
    //so far there are three types of armor upgrade
    armorAvailable[0] = new Armor("Wood", "Wood Armor", false, 100, 50, 0xff836835); 
    armorAvailable[1] = new Armor("Iron", "Iron Armor", false, 100, 100, 0xffB2A89C); 
    armorAvailable[2] = new Armor("Gold", "Gold Armor", false, 100, 200, 0xffE6ED35); 
    
    //there are three tiers of each weapon, there are only two types of weapons as per design
    weaponAvailable[0] = new Weapon("Wood", "Wood Tommy", 5, 5, false, 100, 9, 40, 40, 0xff836835, "Tommy"); 
    weaponAvailable[1] = new Weapon("Iron", "Iron Tommy", 7, 7, false, 100, 9, 50, 50, 0xffB2A89C, "Tommy");
    weaponAvailable[2] = new Weapon("Gold", "Gold Tommy", 10, 10, false, 100, 10, 60, 60, 0xffE6ED35, "Tommy");
    
    weaponAvailable[3] = new Weapon("Wood", "Wood Shotgun", 200, 25, false, 100, 3, 10, 2, 0xff836835, "Shotgun");
    weaponAvailable[3].ammo = 20;
    weaponAvailable[4] = new Weapon("Iron", "Iron Shotgun", 300, 50, false, 100, 3, 10, 2, 0xffB2A89C, "Shotgun");
    weaponAvailable[4].ammo = 20;
    weaponAvailable[5] = new Weapon("Gold", "Gold Shotgun", 500, 75, false, 100, 3, 12, 2, 0xffE6ED35, "Shotgun");
    weaponAvailable[5].ammo = 20;
    weaponAvailable[6] = new Weapon("Gold", "Super Power", 100, 100, false, 100, 9, 1000, 1000, 0xff836835, "Superpower");
    weaponAvailable[6].ammo = 10000;
  }
  
  public void spawnInitialEnemies() {
    
    if(!initialEnemies) {
      initialEnemies = true;
      
      for(int i = 0; i < 1; i++) {
       //enemies.add(new Ant(0,0)); 
       //enemies.add(new Flower(200,200));
       //enemies[1] = new Ant(60,40); 
       //enemies[2] = new Ant(40,80);  
      
       
       //grassland enemies
       //enemies.add(new Robot(100,100));
       //enemies.add(new Ant(0,0)); 
       //enemies.add(new Flower(200,200));
       //enemies.add(new Phalax(600,400));
       
       //steel enemies
       //enemies.add(new ElectroMan(400,400));
       //enemies.add(new ElectroDuo(500,400));
       //enemies.add(new ElectroQuad(300,300));
       //enemies.add(new HiveMaster(1000,300));
       
     
      //tropical enemies
         //enemies.add(new Monkey(300,320));
      //  enemies.add(new Gorilla(300,320));
        
      //enemies.add(new PirateShip(0,0));
       
       
       //steel
       //generateBiome();
       
       //tropical
       //generateTropical();
       
   
    }
      
    }
    
  }
  
  public void checkBiomeSwitch() {
    //System.out.println("Hello"); 
    
    if(phalaxDeath) { this.generateBiome(); }
    
    if(hiveMasterDeath) {this.generateTropical(); }
    
  }
  
  //this function will spawn a new enemy somewhere on the map
  public void spawnAnEnemy(int frame) {
    
    //System.out.println("Frame: " + frame); 
    
    //we are at the start of a biome
    if(difficulty == 0) {
      System.out.println("Biome start");
      if(currentBiome.equals("steel")) {
        spawningFlowers = false; 
        spawningRobots = false;
        spawningElectroQuads = false;
        difficultyStepper = 6;
      } else if (currentBiome.equals("tropical")) {
        spawningFlowers = false; 
        spawningRobots = false; 
        spawningElectroQuads = false; 
        difficultyStepper = 6;
        
        
        
      }
      
    }
    
    difficulty = difficulty + 1; 
    
    //after one minute, adjust the spawn rate of ants
    if( (difficulty == 1800)&(currentBiome.equals("grassland"))) {
      //speed up the ant spawn
      difficultyStepper = 4; 
    } else if ( (difficulty == 1800)&(currentBiome.equals("steel"))) {
      
      
      //after one minute in new biome start spawning electro quads and speed up ants a bit
      System.out.println("Leveling up correctly in new biome"); 
      difficultyStepper = 4;
      spawningRobots = false;
      //difficultyStepperRobot = 4;
      spawningElectroQuads = true;
      
    } else if ( (difficulty == 1800)&(currentBiome.equals("tropical"))) {
      
      //after one minute in tropical start spawning monkeys
      //difficultyStepper = 4; 
      spawningMonkeys = true;
      
      
    }
    
    //after two minutes, adjust the spawn rate of ants
    if( (difficulty == 3600) &(currentBiome.equals("grassland"))) {
      //speed up the ant spawn
      difficultyStepper = 2; 
    } else if ( (difficulty == 3600)&(currentBiome.equals("steel"))) {
      
      
      //after two minutes in the new biome, start spawning robots again at middle speed, and speed up ants to max
      System.out.println("Leveling up correctly in new biome"); 
      difficultyStepper = 2;
      spawningRobots = true;
      difficultyStepperRobot = 4;
      
    } else if ( (difficulty == 3600)&(currentBiome.equals("tropical"))) {
      
      //after two minutes in tropical start spawning flowers
      //difficultyStepper = 4; 
      spawningMonkeys = true;
      //spawningGorillas = true;
      spawningFlowers = true; 
      difficultyStepperFlower = 4; 
      
    }
    
    //after 3 minutes, start spawning flower enemies
    if((difficulty == 5400) &(currentBiome.equals("grassland"))) {
      //slow down the ants a bit for now
      difficultyStepper = 2;
      difficultyStepperFlower = 6; 
      spawningFlowers = true;
    } else if ( (difficulty == 5400)&(currentBiome.equals("steel"))) {
      
      
      //after three minutes in the new biome, start spawning flowers, ants and robots at max speed
      System.out.println("Leveling up correctly in new biome"); 
      difficultyStepper = 2;
      spawningRobots = true;
      spawningFlowers = true;
      difficultyStepperFlower = 2;
      difficultyStepperRobot = 2;
      
    } else if ( (difficulty == 5400)&(currentBiome.equals("tropical"))) {
      
      //after three minutes in tropical start spawning gorillas and robots
      //difficultyStepper = 4; 
      spawningMonkeys = true;
      spawningGorillas = true;
      spawningRobots = true; 
      difficultyStepperRobot = 4; 
      
    }
    
    //after 4 minutes, adjust the spawn rate of flowers to be quicker
    if((difficulty == 7200) &(currentBiome.equals("grassland"))) {
      //speed up the ant spawn
      difficultyStepper = 2;
      difficultyStepperFlower = 4; 
      spawningFlowers = true;
    } else if ( (difficulty == 7200)&(currentBiome.equals("steel"))) {
     
      
      //after 4 minutes in the new biome slow down flowers, robots and ants a bit
      System.out.println("Leveling up correctly in new biome"); 
      difficultyStepper = 4;
      spawningRobots = true;
      spawningFlowers = true;
      difficultyStepperFlower = 4;
      difficultyStepperRobot = 4;
      
    } else if ( (difficulty == 7200)&(currentBiome.equals("tropical"))) {
      
      //after four start spawning max flowers and robots
      //difficultyStepper = 4; 
      spawningMonkeys = true;
      spawningGorillas = true;
      spawningFlowers = true;
      spawningRobots = true;
      difficultyStepperFlower = 2;
      difficultyStepperRobot = 2;
      
    }
    
    //after 5 minutes, adjust the spawn rate of flowers to be max
    if ((difficulty == 9000) &(currentBiome.equals("grassland"))) {
      difficultyStepperFlower = 2;
      difficultyStepper = 2;
      spawningFlowers = true;
      
    } else if ( (difficulty == 9000)&(currentBiome.equals("steel"))) {
      
      //after 5 minutes in the new biome stop spawning flowers and robots, slow down ants a bit
      System.out.println("Leveling up correctly in new biome"); 
      difficultyStepper = 6;
      spawningRobots = false;
      spawningFlowers = false;
      difficultyStepperFlower = 2;
      difficultyStepperRobot = 2;
     
    } else if ( (difficulty == 9000)&(currentBiome.equals("tropical"))) {
      
      //after five minutes stop spawning monkeys
      //difficultyStepper = 4; 
      spawningMonkeys = false;
      spawningGorillas = true;
      
    }
    
    //after 6 minutes, stop spawning enemies except for ants, let player empty the screen and grab some more resources
    if ((difficulty == 10800) &(currentBiome.equals("grassland"))) {
      //difficultyStepper = 100;\
      difficultyStepper = 2; 
      //difficultyStepperFlower = 100; 
      spawningFlowers = false; 
      spawningRobots = false; 
    } else if ( (difficulty == 10800)&(currentBiome.equals("steel"))) {
      
      //after 6 minutes in the new biome, stop spawning electro quads
      System.out.println("Leveling up correctly in new biome"); 
      difficultyStepper = 6;
      spawningElectroQuads = false;
     
    } else if ( (difficulty == 10800)&(currentBiome.equals("tropical"))) {
      
      //after six minutes stop spawning gorillas, stop spawning robots and flowers
      //difficultyStepper = 4; 
      spawningMonkeys = false;
      spawningGorillas = false;
      spawningRobots = false; 
      spawningFlowers = false;
      
    }
    
    
    //after 7 minutes, start spawning robots
    if((difficulty == 12600) &(currentBiome.equals("grassland"))) {
      spawningRobots = true;
      difficultyStepperRobot = 4; 
      
    } else if ( (difficulty == 12600)&(currentBiome.equals("steel"))) {
      
      //after 7 minutes in the new biome, spawn a HIVE MASTER
      System.out.println("Leveling up correctly in new biome"); 
      difficultyStepper = 6;
      
      
      int streamSize = 10; 
      int start = 0; 
      int bound = 9; 
      int xBound = 60;
      int yBound = 24;
      int xMin = 10; 
      int yMin = 10;
    
      Random r = new Random(); 
    
      r.ints(streamSize, start, bound);
      int spawnX = r.nextInt(xBound+1-xMin) + xMin;
      int spawnY = r.nextInt(yBound+1-yMin) + yMin;
    
      spawnX = spawnX*20; 
      spawnY = spawnY*20; 
      
     
      HiveMaster tempHiveMaster = new HiveMaster(spawnX, spawnY);
      enemies.add(tempHiveMaster);

     
    } else if ( (difficulty == 12600)&(currentBiome.equals("tropical"))) {
      
      //after seven minutes have the pirate ship come into the water
      introducePirateShip();
      

      //start spawning monkeys again
      //difficultyStepper = 4; 
      spawningMonkeys = true;
      spawningGorillas = false;
      
    }
    
    
    //after 8 minutes, start spawning flowers again, speed up robots to max
    if ((difficulty == 14400) &(currentBiome.equals("grassland"))) {
       difficultyStepper = 2; 
       difficultyStepperFlower = 4;
       difficultyStepperRobot = 2;
       spawningFlowers = true; 
       spawningRobots = true;
    }
    
    //after 9 minutes, flowers to max spawn rate
    if ((difficulty == 16200)  &(currentBiome.equals("grassland"))) {
      difficultyStepper = 2; 
      difficultyStepperFlower = 2; 
      difficultyStepperRobot = 2;
      spawningFlowers = true; 
      spawningRobots = true;
    }
    
    //10 minutes
    //stop spawning flowers and robots, ants at max spawn rate
    //spawn a phalax
    if ((difficulty == 18000) &(currentBiome.equals("grassland"))) {
      spawningFlowers = false; 
      spawningRobots = false; 
      difficultyStepper = 2; 
      
       int streamSize = 10; 
      int start = 0; 
      int bound = 9; 
      int xBound = 69;
      int yBound = 30;
      int xMin = 0; 
      int yMin = 0;
    
      Random r = new Random(); 
    
      r.ints(streamSize, start, bound);
      int spawnX = r.nextInt(xBound+1-xMin) + xMin;
      int spawnY = r.nextInt(yBound+1-yMin) + yMin;
    
      spawnX = spawnX*20; 
      spawnY = spawnY*20; 
      
     
      Phalax tempPhalax = new Phalax(spawnX, spawnY);
      enemies.add(tempPhalax);
      
    }
    
  
    
    int streamSize = 5; 
    int start = 0; 
    int bound = 9; 
    int xBound = 69;
    int yBound = 30;
    int xMin = 0; 
    int yMin = 0;
    
    Random r = new Random(); 
    
    r.ints(streamSize, start, bound);
    
    int spawnX = r.nextInt(xBound+1-xMin) + xMin;
    int spawnY = r.nextInt(yBound+1-yMin) + yMin;
    
    spawnX = spawnX*20; 
    spawnY = spawnY*20; 
    
    
    
    
    //spawn an enemy ant every 7-8 seconds, then 5-6 seconds, then 3-4 seconds
    if(frame==0) {
      spawner = spawner + 1; 
      
      if(spawner == difficultyStepper) {
        System.out.println("Spawning a new enemy ANT at: (" + spawnX + "," + spawnY + ")"); 
        //determine where the enemy is going to spawn
        Ant tempAnt = new Ant(spawnX, spawnY);
        
        enemies.add(tempAnt); 
        //increment the amount of enemies in action
        //enemiesInAction = enemiesInAction + 1; 
        
        
        //reset the ant spawner
        spawner = 0; 
      }
      
    }
    
    //spawn an enemy flower every 7-8 seconds
    if( (frame==0) & spawningFlowers) {
      flowerSpawner = flowerSpawner + 1;
      
      if( (flowerSpawner%difficultyStepperFlower) == 0) {
        System.out.println("Spawning a new enemy FLOWER at: (" + spawnX + "," + spawnY + ")");
        
        //spawn a flower here
        Flower tempFlower = new Flower(spawnX, spawnY);
        
        //add it to the enemies list
        enemies.add(tempFlower);
        
      }
      
    }
    
    
    //spawn an enemy robot every 7-8 seconds
    //spawn an enemy flower every 7-8 seconds
    if( (frame==0) & spawningRobots) {
      robotSpawner = robotSpawner + 1;
      
      int spawnRobotX = r.nextInt(xBound+1-xMin) + xMin;
      int spawnRobotY = r.nextInt(yBound+1-yMin) + yMin;
      
      spawnRobotX = spawnRobotX*20; 
      spawnRobotY = spawnRobotY*20; 
      
      if( (robotSpawner%difficultyStepperRobot) == 0) {
        System.out.println("Spawning a new enemy ROBOT at: (" + spawnRobotX + "," + spawnRobotY + ")");
        
        //spawn a robot here
        Robot tempRobot = new Robot(spawnRobotX, spawnRobotY);
        
        //add it to the enemies list
        enemies.add(tempRobot);
        
      }
      
    }
    
    
    if( (frame==0) & spawningElectroQuads) {
      electroQuadSpawner = electroQuadSpawner + 1;
      
      int spawnEQuadX = r.nextInt(xBound+1-xMin) + xMin;
      int spawnEQuadY = r.nextInt(yBound+1-yMin) + yMin;
      
      spawnEQuadX = spawnEQuadX*20; 
      spawnEQuadY = spawnEQuadY*20; 
      
      if( (electroQuadSpawner%difficultyStepperEQuad) == 0) {
        System.out.println("Spawning a new enemy ROBOT at: (" + spawnEQuadX + "," + spawnEQuadY + ")");
        
        //spawn a robot here
        ElectroQuad tempElectroQuad = new ElectroQuad(spawnEQuadX, spawnEQuadY);
        
        //add it to the enemies list
        enemies.add(tempElectroQuad);
        
      }
      
    }
    
    
    
    if( (frame==0) & spawningMonkeys) {
      monkeySpawner = monkeySpawner + 1;
      
      int spawnMonkeyX = r.nextInt(xBound+1-xMin) + xMin;
      int spawnMonkeyY = r.nextInt(yBound+1-yMin) + yMin;
      
      spawnMonkeyX = spawnMonkeyX*20; 
      spawnMonkeyY = spawnMonkeyY*20; 
      
     
        System.out.println("Spawning a new enemy MONKEY at: (" + spawnMonkeyX + "," + spawnMonkeyY + ")");
        
        //spawn a robot here
        Monkey tempMonkey = new Monkey(spawnMonkeyX, spawnMonkeyY);
        
        //add it to the enemies list
        enemies.add(tempMonkey);
        
      
      
    }
    
    
    if( (frame==0) & spawningGorillas) {
      gorillaSpawner = gorillaSpawner + 1;
      
      int spawnGorillaX = r.nextInt(xBound+1-xMin) + xMin;
      int spawnGorillaY = r.nextInt(yBound+1-yMin) + yMin;
      
      spawnGorillaX = spawnGorillaX*20; 
      spawnGorillaY = spawnGorillaY*20; 
      
     if( (gorillaSpawner%difficultyStepperGorilla) == 0) {
        System.out.println("Spawning a new enemy GORILLA at: (" + spawnGorillaX + "," + spawnGorillaY + ")");
        
        //spawn a robot here
        Gorilla tempGorilla = new Gorilla(spawnGorillaX, spawnGorillaY);
        
        //add it to the enemies list
        enemies.add(tempGorilla);
        
     }
      
      
    }
    
    
  }
  
  
  public void introducePirateShip() {
    
    enemies.add(new PirateShip(0,0));
    
    
  }
  
  
  //this function will call all of the current enemies movement function in order to update their attributes
  public void moveEnemies(int frame) {
    
    //System.out.println("Frame: "+ frame);
    
    //make a decision to move 4 times a second
    if(frame==0 || frame==5 || frame==10 || frame==15 || frame==20 || frame==25 || frame==30) {
    
      //move the ants
      //System.out.println("Enemies taking a step");
      for(int i = 0; i < enemies.size(); i++) {
        //System.out.println("In the loop");
        enemies.get(i).move(players[0].getXC(), players[0].getYC());
      }
    }
    
  }
  
  //this function checks the health of all enemies 
  public void checkEnemies() {
    for(int i = 0; i < enemies.size(); i++) {
       if(enemies.get(i).health <= 0) { 
       
        if(enemies.get(i).getEnemyType().equals("Phalax")) {
          System.out.println("BIOME SWITCH");
          
          
          phalaxDeath = true; 
          
         
        }
        
        
        if(enemies.get(i).getEnemyType().equals("HiveMaster")) {
          System.out.println("BIOME SWITCH");
          
          
          hiveMasterDeath = true; 
          
        }
        
        enemies.get(i).status = false; 
        enemies.remove(enemies.get(i)); 
     }
    }
    
  }
  
  
  
  //this function will draw all of the current enemies using the new updated attributes
  public void showEnemies() {
    
   // System.out.println("Enemies.size(): " + enemies.size()); 
    
    
    for(int i = 0; i < enemies.size(); i++) {
      
      enemies.get(i).show();
      
    }
      
    
    
  }
  
  //turns status to false of all bullets that are off the screen
  public void checkBulletRedundancy() {
    for(int i = 0; i < playerBullets.size(); i++) {
       playerBullets.get(i).checkStatus(); 
       
       if(playerBullets.get(i).getStatus() == false) {
         playerBullets.remove(playerBullets.get(i));
       }
    }
    
    for(int i = 0; i < flowerBullets.size(); i++) {
       flowerBullets.get(i).checkStatus();
       
       
       if(flowerBullets.get(i).getStatus() == false) {
         flowerBullets.remove(flowerBullets.get(i));
       }
       
    }
    
    for(int i = 0; i < robotBullets.size(); i++) {
       robotBullets.get(i).checkStatus();
       
       if(robotBullets.get(i).getStatus() == false) {
         robotBullets.remove(robotBullets.get(i));
       }
    }
    
     for(int i = 0; i < phalaxBullets.size(); i++) {
       phalaxBullets.get(i).checkStatus();
    }
    
    for(int i = 0; i < hiveBullets.size(); i++) {
       hiveBullets.get(i).checkStatus();
    }
      
    for(int i = 0; i < cannonBullets.size(); i++) {
       cannonBullets.get(i).checkStatus();
    }
    
  }
  
  //checks each row and each column, if there are 5 or more enemies present on one given line, apply swarm intelligence
  public void updateSwarmIntelligence() {
    
  }
  
  public void checkEnemyAntsEating() {
    
    //for each enemy
    for (int i = 0; i < enemies.size(); i++) {
      
      int enemyXC = (int) enemies.get(i).getXC();
      int enemyYC = (int) enemies.get(i).getYC();
      
      //switched them by accident somewhere along the line
      int playerXC = players[0].getYC()*20;
      int playerYC = players[0].getXC()*20;
      
      //System.out.println("Player at: " + playerXC+ "," + playerYC);
      //System.out.println("Enemy at: " + enemyXC + "," + enemyYC);
      
      
      
      if((enemyXC == playerXC)&(enemyYC == playerYC)) {
       // System.out.println("COLLISION");
        
        //this enemy deals damage to that player if they are on the same square as them
        if(enemies.get(i).enemyType == "Ant" || enemies.get(i).enemyType == "ElectroMan" || enemies.get(i).enemyType == "Monkey" || enemies.get(i).enemyType == "Gorilla") {
        boolean playerDied = enemies.get(i).dealDamage(players[0]);
        
        //if the playerDied
        if(playerDied) {
          
          System.out.println("Mission Failed, score: " + score); 
          
        }
        }
      }
      
      if((enemyXC == playerXC+20)&(enemyYC == playerYC)) {
       // System.out.println("COLLISION");
        
        //this enemy deals damage to that player if they are on the same square as them
        if(enemies.get(i).enemyType == "Ant" || enemies.get(i).enemyType == "ElectroMan" || enemies.get(i).enemyType == "Monkey" || enemies.get(i).enemyType == "Gorilla") {
        boolean playerDied = enemies.get(i).dealDamage(players[0]);
        
        //if the playerDied
        if(playerDied) {
          
          System.out.println("Mission Failed, score: " + score); 
          
        }
        }
      }
      
      if((enemyXC == playerXC+20)&(enemyYC == playerYC+20)) {
       // System.out.println("COLLISION");
        
        //this enemy deals damage to that player if they are on the same square as them
        if(enemies.get(i).enemyType == "Ant" || enemies.get(i).enemyType == "ElectroMan" || enemies.get(i).enemyType == "Monkey" || enemies.get(i).enemyType == "Gorilla") {
        boolean playerDied = enemies.get(i).dealDamage(players[0]);
        
        //if the playerDied
        if(playerDied) {
          
          System.out.println("Mission Failed, score: " + score); 
          
        }
        }
      }
      
      if((enemyXC == playerXC)&(enemyYC == playerYC+20)) {
       // System.out.println("COLLISION");
        
        //this enemy deals damage to that player if they are on the same square as them
        if(enemies.get(i).enemyType == "Ant" || enemies.get(i).enemyType == "ElectroMan" || enemies.get(i).enemyType == "Monkey" || enemies.get(i).enemyType == "Gorilla") {
        boolean playerDied = enemies.get(i).dealDamage(players[0]);
        
        //if the playerDied
        if(playerDied) {
          
          System.out.println("Mission Failed, score: " + score); 
          
        }
        }
      }
    }  
  }
  
  
  
  //for each enemy in the arraylist that needs to shoot, expel their shot
  public void checkEnemiesWhoShoot() {
    
    for(int i = 0; i < enemies.size(); i++) {
      
      //if the enemy needs to shoot
      if(enemies.get(i).getShotExpulsion()) {
        
        //System.out.println("Generating enemy bullet");
        //create the bullet for the flower enemy type
        if(enemies.get(i).getEnemyType() == "Flower" || enemies.get(i).enemyType == "ElectroDuo") {
          //System.out.println("Generating flower bullet"); 
          
          
          //flipped them somewhere along the line
          int targetXC = players[0].getYC()*20;
          int targetYC = players[0].getXC()*20;
          int myXC = (int)enemies.get(i).getXC();
          int myYC = (int)enemies.get(i).getYC();
          
          //System.out.println("TargetXC: " + targetXC);
          //System.out.println("TargetYC: " + targetYC);
         // System.out.println("MYXC: " + myXC);
         // System.out.println("MYYC: " + myYC);
          
          
          //add the bullet
          if(enemies.get(i).enemyType == "Flower" || enemies.get(i).enemyType == "ElectroDuo") {
            
            if(enemies.get(i).enemyType == "Flower") {
              introduceFlowerBullet(targetXC, targetYC, myXC, myYC, enemies.get(i).getAttack(), false);
            } else { 
              introduceFlowerBullet(targetXC, targetYC, myXC, myYC, enemies.get(i).getAttack(), true);
              //introduceFlowerBullet(targetXC, targetYC, myXC, myYC, enemies.get(i).getAttack(), true);
            }
            
          } else if (enemies.get(i).enemyType == "Robot") {
            introduceRobotBullet(targetXC, targetYC, myXC, myYC, enemies.get(i).getAttack(), false);
          }
          
      
          enemies.get(i).setNeedToShoot(false);
          
        } else if ( (enemies.get(i).getEnemyType() == "Robot") || (enemies.get(i).getEnemyType() == "ElectroQuad")) {
          
         // System.out.println("Generating robot bullet"); 
          
          
          //flipped them somewhere along the line
          int targetXC = players[0].getYC()*20;
          int targetYC = players[0].getXC()*20;
          int myXC = (int)enemies.get(i).getXC();
          int myYC = (int)enemies.get(i).getYC();
          
        //  System.out.println("TargetXC: " + targetXC);
        //  System.out.println("TargetYC: " + targetYC);
        //  System.out.println("MYXC: " + myXC);
        //  System.out.println("MYYC: " + myYC);
          
          
          //add the bullet
          if(enemies.get(i).enemyType == "Flower") {
            introduceFlowerBullet(targetXC, targetYC, myXC, myYC, enemies.get(i).getAttack(), false);
          } else if (enemies.get(i).enemyType == "Robot" || enemies.get(i).enemyType == "ElectroQuad") {
            if(enemies.get(i).enemyType == "Robot") { 
              introduceRobotBullet(targetXC, targetYC, myXC, myYC, enemies.get(i).getAttack(), false);
            } else { 
              introduceRobotBullet(targetXC, targetYC, myXC, myYC, enemies.get(i).getAttack(), true);
            }
          }
          
      
          enemies.get(i).setNeedToShoot(false);
          
          
        } else if (enemies.get(i).getEnemyType() == "Phalax") {
          
        //  System.out.println("Generating Phalax bullet"); 
          
          
          //flipped them somewhere along the line
          int targetXC = players[0].getYC()*20;
          int targetYC = players[0].getXC()*20;
          int myXC = (int)enemies.get(i).getXC();
          int myYC = (int)enemies.get(i).getYC();
          
        //  System.out.println("TargetXC: " + targetXC);
        //  System.out.println("TargetYC: " + targetYC);
        //  System.out.println("MYXC: " + myXC);
        //  System.out.println("MYYC: " + myYC);
          
          
          //add the bullet
          if(enemies.get(i).enemyType == "Flower") {
            introduceFlowerBullet(targetXC, targetYC, myXC, myYC, enemies.get(i).getAttack(), false);
          } else if (enemies.get(i).enemyType == "Robot") {
            introduceRobotBullet(targetXC, targetYC, myXC, myYC, enemies.get(i).getAttack(), false);
          } else if (enemies.get(i).enemyType == "Phalax") {
            introducePhalaxBullet(targetXC, targetYC, myXC, myYC, enemies.get(i).getAttack());
          }
      
          enemies.get(i).setNeedToShoot(false);
        
        
      } else if (enemies.get(i).getEnemyType() == "HiveMaster") {
        
         //flipped them somewhere along the line
          int targetXC = players[0].getYC()*20;
          int targetYC = players[0].getXC()*20;
          int myXC = (int)enemies.get(i).getXC();
          int myYC = (int)enemies.get(i).getYC();
          
          introduceHiveBullet(targetXC, targetYC, myXC, myYC, enemies.get(i).getAttack());
        
          enemies.get(i).setNeedToShoot(false);
        
      } else if (enemies.get(i).getEnemyType() == "PirateShip") {
        
        
        //flipped them somewhere along the line
          int targetXC = players[0].getYC()*20;
          int targetYC = players[0].getXC()*20;
          int myXC = (int)enemies.get(i).getXC();
          int myYC = (int)enemies.get(i).getYC();
          
          
          
          introduceCannonBullet(targetXC, targetYC, myXC, myYC, enemies.get(i).getAttack());
          introduceCannonBullet(targetXC, targetYC+20, myXC, myYC+60, enemies.get(i).getAttack());
          introduceCannonBullet(targetXC, targetYC+40, myXC, myYC+120, enemies.get(i).getAttack());
          introduceCannonBullet(targetXC+20, targetYC, myXC+20, myYC+40, enemies.get(i).getAttack());
          introduceCannonBullet(targetXC+20, targetYC+20, myXC+60, myYC+100, enemies.get(i).getAttack());
          introduceCannonBullet(targetXC+40, targetYC+40, myXC, myYC+120, enemies.get(i).getAttack());
           
        
          enemies.get(i).setNeedToShoot(false);
        
        
      }
      
      }
      
    }
    
  }
  
  public void checkPirateSickness() {
   
  }
  
  
  //called when the player receives fatal damage,
  public boolean endGame() {
    
    if(players[0].getHealth() <= 0) {
      return true;
    } else {
      return false; 
    }
    
  }
  
  
  //resets all of the board game variables for game restart
  public void resetBoardVariables() {
    
    
    plantedTrees = false;
    plantedTreesInSteel = false; 
    plantedTreesInTropical = false;

    collision = false;
    
    
    bulletSize = 10; 
    score = 0; 
  
    currentBiome = "grassland"; 
  
    phalaxDeath = false; 
    hiveMasterDeath = false; 
  
    shotGunSickness = false;
    shotGunAnimationTick = 0;
  
    tommyGunSickness = false; 
    tommyGunAnimationTick = 0; 
  
    pirateSicknessCounter = 0;
    pirateSickness = false;
  
    waterLoc = -1;
    
    difficulty = 0; 
  difficultyStepper = 6; 
  difficultyStepperFlower = 6;
  difficultyStepperRobot = 6;
  difficultyStepperEQuad = 6;
  difficultyStepperMonkey = 2; 
  difficultyStepperGorilla = 4;
    
    
   initialEnemies = false; 
  
  spawningFlowers = false;
  spawningRobots = false;
  spawningElectroQuads = false;
  spawningMonkeys = false; 
  spawningGorillas = false;
  
  Random r;
  
  spawner = 0; 
  
  flowerSpawner = 0;
  
  robotSpawner = 0; 
  
  electroQuadSpawner = 0; 
  
  monkeySpawner = 0; 

  gorillaSpawner = 0; 
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    players[0].reset();
    
    plantedTrees = false; 
    plantedTreesInSteel = false; 
    collision = false;
    
    bulletSize = 10;
    score = 0;
    bulletsInAction = 0;
    enemiesInAction = 1; 
    
    //reset the backing array holding the gameboard state
    for(int i = 0; i < 40; i++) {
      for(int j = 0; j < 70; j++) {
        //tiles[i][j] = null;
      }
    }
    
    for(int i = 0; i < 10; i++) {
      players[i] = null;
    }
    
    for(int i = 0; i < 20000; i++) {
      bullets[i] = null;
    }
    
    for (int i = 0; i < enemies.size(); i++) {
       enemies.remove(i); 
    }
    enemies.clear();
    
    for (int i = 0; i < flowerBullets.size(); i++) {
      flowerBullets.remove(i); 
    }
    flowerBullets.clear();
    
    for (int i = 0; i < robotBullets.size(); i++) {
      robotBullets.remove(i); 
    }
    robotBullets.clear();
    
    for (int i = 0; i < hiveBullets.size(); i++) {
      hiveBullets.remove(i); 
    }
    hiveBullets.clear();
    
    for (int i = 0; i < cannonBullets.size(); i++) {
      cannonBullets.remove(i); 
    }
    cannonBullets.clear();
    
    initialEnemies = false;
    spawner = 0; 
    
    //difficulty tracker
    difficulty = 0; 
    difficultyStepper = 6;
    difficultyStepperFlower = 6;
    difficultyStepperRobot = 6;
    difficultyStepperEQuad = 6; 
    spawningFlowers = false;
    spawningRobots = false;
    
  }
  
  //checks if the player is standing on any level and if so deals some damage to them
  public void checkLavaDamage() {
    
    //System.out.println("Checking lava damage"); 
    
    int playerXC = players[0].getXC(); 
    int playerYC = players[0].getYC();
    
    
    //if the tile the player is standing on is lava
    if(tiles[playerXC][playerYC].getType().equals("Lava")) {
      System.out.println("Dealing damage to the player due to lava");
      players[0].setHealth(players[0].getHealth() - 1);
      
    }
    
    if(tiles[playerXC+1][playerYC].getType().equals("Lava")) {
      System.out.println("Dealing damage to the player due to lava");
      players[0].setHealth(players[0].getHealth() - 1);
      
    }
    
    if(tiles[playerXC+1][playerYC+1].getType().equals("Lava")) {
      System.out.println("Dealing damage to the player due to lava");
      players[0].setHealth(players[0].getHealth() - 1);
      
    }
    
    if(tiles[playerXC][playerYC+1].getType().equals("Lava")) {
      System.out.println("Dealing damage to the player due to lava");
      players[0].setHealth(players[0].getHealth() - 1);
      
    }
    
  }
  
  //simulates the constructor for this object, for a clean new game state
  public void pseudoConstructor() {
    
    //initialize all of the tiles in the array used to represent our gameboard
    for(int i = 0; i < 40; i++) {
      
      for(int j = 0; j < 70; j++) {
        tiles[i][j] = new Tile();
      }
      
    }
    
    //initialize the player array
    for(int i = 0; i < 10; i++) {
      players[i] = new Player();
    }
    
    //initialize the bullet array
    for(int i = 0; i < 20000; i++) {
      bullets[i] = new Bullet(); 
    }
    
    
    //TESTING ENEMIES
    
    //TESTING ENEMIES
    
    //intialize the armor and weapon arrays
    
    //so far there are three types of armor upgrade
    armorAvailable[0] = new Armor("Wood", "Wood Armor", false, 100, 50, 0xff836835); 
    armorAvailable[1] = new Armor("Iron", "Iron Armor", false, 100, 100, 0xffB2A89C); 
    armorAvailable[2] = new Armor("Gold", "Gold Armor", false, 100, 200, 0xffE6ED35); 
    
    //so far there are three types of each weapon and there are only two types of weapons as per design
   //there are three tiers of each weapon, there are only two types of weapons as per design
    weaponAvailable[0] = new Weapon("Wood", "Wood Tommy", 5, 5, false, 100, 9, 40, 40, 0xff836835, "Tommy");
    weaponAvailable[0].ammo = 40;
    weaponAvailable[1] = new Weapon("Iron", "Iron Tommy", 7, 7, false, 100, 9, 50, 50, 0xffB2A89C, "Tommy");
    weaponAvailable[1].ammo = 50;
    weaponAvailable[2] = new Weapon("Gold", "Gold Tommy", 10, 10, false, 100, 10, 60, 60, 0xffE6ED35, "Tommy");
    weaponAvailable[2].ammo = 60;
    
    weaponAvailable[3] = new Weapon("Wood", "Wood Shotgun", 200, 25, false, 100, 3, 10, 2, 0xff836835, "Shotgun");
    weaponAvailable[3].ammo = 20;
    weaponAvailable[4] = new Weapon("Iron", "Iron Shotgun", 300, 50, false, 100, 3, 10, 2, 0xffB2A89C, "Shotgun");
    weaponAvailable[4].ammo = 20;
    weaponAvailable[5] = new Weapon("Gold", "Gold Shotgun", 500, 75, false, 100, 3, 12, 2, 0xffE6ED35, "Shotgun");
    weaponAvailable[5].ammo = 20;
    weaponAvailable[6] = new Weapon("Gold", "Super Power", 100, 100, false, 100, 9, 1000, 1000, 0xff836835, "Superpower");
    weaponAvailable[6].ammo = 100000;
    
    //difficulty tracker
    difficulty = 0; 
    difficultyStepper = 6; 
  }
  
  
  public void checkCannonBulletCollisions() {
    
    //for each flower bullet that is in action
    for(int i = 0; i < cannonBullets.size(); i++) {
      
      int bulletX = cannonBullets.get(i).getXC();
      int bulletY = cannonBullets.get(i).getYC(); 
      
      //switched them by accident somewhere along the line
      int playerXC = players[0].getYC()*20;
      int playerYC = players[0].getXC()*20;
      
      
      //translate the bulletX and bulletY to the index
      //System.out.println("FlowerBulletX: " + bulletX); 
      //System.out.println("FlowerBulletY: " + bulletY); 
      
      int timesLoopedX = 0; 
      int bulletXLooping = bulletX; 
      
      int timesLoopedY = 0; 
      int bulletYLooping = bulletY; 
      
      while(bulletXLooping > 0) {
        bulletXLooping = bulletXLooping - 20;
        timesLoopedX = timesLoopedX + 1;
      }
      
      while(bulletYLooping > 0) {
        bulletYLooping = bulletYLooping - 20; 
        timesLoopedY = timesLoopedY + 1;
      }
      
      
      
      if( (timesLoopedX*20 == playerXC) & (timesLoopedY*20 == playerYC)) {
        //System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(cannonBullets.get(i).getStatus()) { players[0].takeDamage(cannonBullets.get(i).getDamage()); }
      }
      
      if( (timesLoopedX*20 == playerXC+20) & (timesLoopedY*20 == playerYC)) {
        //System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(cannonBullets.get(i).getStatus()) { players[0].takeDamage(cannonBullets.get(i).getDamage()); }
      }
      
      if( (timesLoopedX*20 == playerXC+20) & (timesLoopedY*20 == playerYC+20)) {
        //System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(cannonBullets.get(i).getStatus()) { players[0].takeDamage(cannonBullets.get(i).getDamage()); }
      }
      
       if( (timesLoopedX*20 == playerXC) & (timesLoopedY*20 == playerYC+20)) {
        //System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(cannonBullets.get(i).getStatus()) { players[0].takeDamage(cannonBullets.get(i).getDamage()); }
      }
      
      
      
      
      
      if( (timesLoopedX*20+20 == playerXC) & (timesLoopedY*20 == playerYC)) {
        //System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(cannonBullets.get(i).getStatus()) { players[0].takeDamage(cannonBullets.get(i).getDamage()); }
      }
      
      if( (timesLoopedX*20+20 == playerXC+20) & (timesLoopedY*20 == playerYC)) {
        //System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(cannonBullets.get(i).getStatus()) { players[0].takeDamage(cannonBullets.get(i).getDamage()); }
      }
      
      if( (timesLoopedX*20+20 == playerXC+20) & (timesLoopedY*20 == playerYC+20)) {
        //System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(cannonBullets.get(i).getStatus()) { players[0].takeDamage(cannonBullets.get(i).getDamage()); }
      }
      
       if( (timesLoopedX*20+20 == playerXC) & (timesLoopedY*20 == playerYC+20)) {
        //System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(cannonBullets.get(i).getStatus()) { players[0].takeDamage(cannonBullets.get(i).getDamage()); }
      }
      
      
      
       if( (timesLoopedX*20+20 == playerXC) & (timesLoopedY*20+20 == playerYC)) {
        //System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(cannonBullets.get(i).getStatus()) { players[0].takeDamage(cannonBullets.get(i).getDamage()); }
      }
      
      if( (timesLoopedX*20+20 == playerXC+20) & (timesLoopedY*20+20 == playerYC)) {
        //System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(cannonBullets.get(i).getStatus()) { players[0].takeDamage(cannonBullets.get(i).getDamage()); }
      }
      
      if( (timesLoopedX*20+20 == playerXC+20) & (timesLoopedY*20+20 == playerYC+20)) {
        //System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(cannonBullets.get(i).getStatus()) { players[0].takeDamage(cannonBullets.get(i).getDamage()); }
      }
      
       if( (timesLoopedX*20+20 == playerXC) & (timesLoopedY*20+20 == playerYC+20)) {
        //System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(cannonBullets.get(i).getStatus()) { players[0].takeDamage(cannonBullets.get(i).getDamage()); }
      }
      
      
      
      if( (timesLoopedX*20 == playerXC) & (timesLoopedY*20+20 == playerYC)) {
        //System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(cannonBullets.get(i).getStatus()) { players[0].takeDamage(cannonBullets.get(i).getDamage()); }
      }
      
      if( (timesLoopedX*20 == playerXC+20) & (timesLoopedY*20+20 == playerYC)) {
        //System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(cannonBullets.get(i).getStatus()) { players[0].takeDamage(cannonBullets.get(i).getDamage()); }
      }
      
      if( (timesLoopedX*20 == playerXC+20) & (timesLoopedY*20+20 == playerYC+20)) {
        //System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(cannonBullets.get(i).getStatus()) { players[0].takeDamage(cannonBullets.get(i).getDamage()); }
      }
      
       if( (timesLoopedX*20 == playerXC) & (timesLoopedY*20+20 == playerYC+20)) {
        //System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(cannonBullets.get(i).getStatus()) { players[0].takeDamage(cannonBullets.get(i).getDamage()); }
      }
      
      
      
    }
    
    
    
  }
  
  public void checkHiveBulletCollisions() {
    //for each flower bullet that is in action
    for(int i = 0; i < hiveBullets.size(); i++) {
      
      int bulletX = hiveBullets.get(i).getXC();
      int bulletY = hiveBullets.get(i).getYC(); 
      
      //switched them by accident somewhere along the line
      int playerXC = players[0].getYC()*20;
      int playerYC = players[0].getXC()*20;
      
      
      //translate the bulletX and bulletY to the index
      //System.out.println("FlowerBulletX: " + bulletX); 
      //System.out.println("FlowerBulletY: " + bulletY); 
      
      int timesLoopedX = 0; 
      int bulletXLooping = bulletX; 
      
      int timesLoopedY = 0; 
      int bulletYLooping = bulletY; 
      
      while(bulletXLooping > 0) {
        bulletXLooping = bulletXLooping - 20;
        timesLoopedX = timesLoopedX + 1;
      }
      
      while(bulletYLooping > 0) {
        bulletYLooping = bulletYLooping - 20; 
        timesLoopedY = timesLoopedY + 1;
      }
      
      
      //System.out.println("Estimating flower bullet location: [" + timesLoopedX + "," + timesLoopedY + "]");
      
      if( (timesLoopedX*20 == playerXC) & (timesLoopedY*20 == playerYC)) {
        //System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(hiveBullets.get(i).getStatus()) { players[0].takeDamage(hiveBullets.get(i).getDamage()); }
      }
      
      if( (timesLoopedX*20 == playerXC+20) & (timesLoopedY*20 == playerYC)) {
        //System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(hiveBullets.get(i).getStatus()) { players[0].takeDamage(hiveBullets.get(i).getDamage()); }
      }
      
      if( (timesLoopedX*20 == playerXC+20) & (timesLoopedY*20 == playerYC+20)) {
        //System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(hiveBullets.get(i).getStatus()) { players[0].takeDamage(hiveBullets.get(i).getDamage()); }
      }
      
       if( (timesLoopedX*20 == playerXC) & (timesLoopedY*20 == playerYC+20)) {
        //System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(hiveBullets.get(i).getStatus()) { players[0].takeDamage(hiveBullets.get(i).getDamage()); }
      }
      
      
      
      
      
      if( (timesLoopedX*20+20 == playerXC) & (timesLoopedY*20 == playerYC)) {
        //System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(hiveBullets.get(i).getStatus()) { players[0].takeDamage(hiveBullets.get(i).getDamage()); }
      }
      
      if( (timesLoopedX*20+20 == playerXC+20) & (timesLoopedY*20 == playerYC)) {
        //System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(hiveBullets.get(i).getStatus()) { players[0].takeDamage(hiveBullets.get(i).getDamage()); }
      }
      
      if( (timesLoopedX*20+20 == playerXC+20) & (timesLoopedY*20 == playerYC+20)) {
        //System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(hiveBullets.get(i).getStatus()) { players[0].takeDamage(hiveBullets.get(i).getDamage()); }
      }
      
       if( (timesLoopedX*20+20 == playerXC) & (timesLoopedY*20 == playerYC+20)) {
        //System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(hiveBullets.get(i).getStatus()) { players[0].takeDamage(hiveBullets.get(i).getDamage()); }
      }
      
      
      
       if( (timesLoopedX*20+20 == playerXC) & (timesLoopedY*20+20 == playerYC)) {
        //System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(hiveBullets.get(i).getStatus()) { players[0].takeDamage(hiveBullets.get(i).getDamage()); }
      }
      
      if( (timesLoopedX*20+20 == playerXC+20) & (timesLoopedY*20+20 == playerYC)) {
        //System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(hiveBullets.get(i).getStatus()) { players[0].takeDamage(hiveBullets.get(i).getDamage()); }
      }
      
      if( (timesLoopedX*20+20 == playerXC+20) & (timesLoopedY*20+20 == playerYC+20)) {
        //System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(hiveBullets.get(i).getStatus()) { players[0].takeDamage(hiveBullets.get(i).getDamage()); }
      }
      
       if( (timesLoopedX*20+20 == playerXC) & (timesLoopedY*20+20 == playerYC+20)) {
        //System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(hiveBullets.get(i).getStatus()) { players[0].takeDamage(hiveBullets.get(i).getDamage()); }
      }
      
      
      
      if( (timesLoopedX*20 == playerXC) & (timesLoopedY*20+20 == playerYC)) {
        //System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(hiveBullets.get(i).getStatus()) { players[0].takeDamage(hiveBullets.get(i).getDamage()); }
      }
      
      if( (timesLoopedX*20 == playerXC+20) & (timesLoopedY*20+20 == playerYC)) {
        //System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(hiveBullets.get(i).getStatus()) { players[0].takeDamage(hiveBullets.get(i).getDamage()); }
      }
      
      if( (timesLoopedX*20 == playerXC+20) & (timesLoopedY*20+20 == playerYC+20)) {
        //System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(hiveBullets.get(i).getStatus()) { players[0].takeDamage(hiveBullets.get(i).getDamage()); }
      }
      
       if( (timesLoopedX*20 == playerXC) & (timesLoopedY*20+20 == playerYC+20)) {
        //System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(hiveBullets.get(i).getStatus()) { players[0].takeDamage(hiveBullets.get(i).getDamage()); }
      }
      
      
      
    }
   
  }
  
  
  public void checkRobotBulletCollisions() {
    
    //for each flower bullet that is in action
    for(int i = 0; i < robotBullets.size(); i++) {
      
      int bulletX = robotBullets.get(i).getXC();
      int bulletY = robotBullets.get(i).getYC(); 
      
      //switched them by accident somewhere along the line
      int playerXC = players[0].getYC()*20;
      int playerYC = players[0].getXC()*20;
      
      
      //translate the bulletX and bulletY to the index
      //System.out.println("FlowerBulletX: " + bulletX); 
      //System.out.println("FlowerBulletY: " + bulletY); 
      
      int timesLoopedX = 0; 
      int bulletXLooping = bulletX; 
      
      int timesLoopedY = 0; 
      int bulletYLooping = bulletY; 
      
      while(bulletXLooping > 0) {
        bulletXLooping = bulletXLooping - 20;
        timesLoopedX = timesLoopedX + 1;
      }
      
      while(bulletYLooping > 0) {
        bulletYLooping = bulletYLooping - 20; 
        timesLoopedY = timesLoopedY + 1;
      }
      
      
      //System.out.println("Estimating flower bullet location: [" + timesLoopedX + "," + timesLoopedY + "]");
      
      if( (timesLoopedX*20 == playerXC) & (timesLoopedY*20 == playerYC)) {
        System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(robotBullets.get(i).getStatus()) { players[0].takeDamage(robotBullets.get(i).getDamage()); }
      }
      
      if( (timesLoopedX*20 == playerXC+20) & (timesLoopedY*20 == playerYC)) {
        System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(robotBullets.get(i).getStatus()) { players[0].takeDamage(robotBullets.get(i).getDamage()); }
      }
      
      if( (timesLoopedX*20 == playerXC+20) & (timesLoopedY*20 == playerYC+20)) {
        System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(robotBullets.get(i).getStatus()) { players[0].takeDamage(robotBullets.get(i).getDamage()); }
      }
      
       if( (timesLoopedX*20 == playerXC) & (timesLoopedY*20 == playerYC+20)) {
        System.out.println("There has been damage dealt from a robot bullet to the player"); 
        if(robotBullets.get(i).getStatus()) { players[0].takeDamage(robotBullets.get(i).getDamage()); }
      }
      
    }
    
    
  }
  
  //checks if there are any collisions amongst the player and the flower bullets that are still in action
  public void checkFlowerBulletCollisions() {
    
    
    //for each flower bullet that is in action
    for(int i = 0; i < flowerBullets.size(); i++) {
      
      int bulletX = flowerBullets.get(i).getXC();
      int bulletY = flowerBullets.get(i).getYC(); 
      
      //switched them by accident somewhere along the line
      int playerXC = players[0].getYC()*20;
      int playerYC = players[0].getXC()*20;
      
      
      //translate the bulletX and bulletY to the index
      //System.out.println("FlowerBulletX: " + bulletX); 
      //System.out.println("FlowerBulletY: " + bulletY); 
      
      int timesLoopedX = 0; 
      int bulletXLooping = bulletX; 
      
      int timesLoopedY = 0; 
      int bulletYLooping = bulletY; 
      
      while(bulletXLooping > 0) {
        bulletXLooping = bulletXLooping - 20;
        timesLoopedX = timesLoopedX + 1;
      }
      
      while(bulletYLooping > 0) {
        bulletYLooping = bulletYLooping - 20; 
        timesLoopedY = timesLoopedY + 1;
      }
      
      
      //System.out.println("Estimating flower bullet location: [" + timesLoopedX + "," + timesLoopedY + "]");
      
      if( (timesLoopedX*20 == playerXC) & (timesLoopedY*20 == playerYC)) {
        System.out.println("There has been damage dealt from a flower bullet to the player"); 
        if(flowerBullets.get(i).getStatus()) { players[0].takeDamage(flowerBullets.get(i).getDamage()); }
      }
      
      if( (timesLoopedX*20 == playerXC+20) & (timesLoopedY*20 == playerYC)) {
        System.out.println("There has been damage dealt from a flower bullet to the player"); 
        if(flowerBullets.get(i).getStatus()) { players[0].takeDamage(flowerBullets.get(i).getDamage()); }
      }
      
      if( (timesLoopedX*20 == playerXC+20) & (timesLoopedY*20 == playerYC+20)) {
        System.out.println("There has been damage dealt from a flower bullet to the player"); 
        if(flowerBullets.get(i).getStatus()) { players[0].takeDamage(flowerBullets.get(i).getDamage()); }
      }
      
      if( (timesLoopedX*20 == playerXC) & (timesLoopedY*20 == playerYC+20)) {
        System.out.println("There has been damage dealt from a flower bullet to the player"); 
        if(flowerBullets.get(i).getStatus()) { players[0].takeDamage(flowerBullets.get(i).getDamage()); }
      }
      
    }
    
    
  }
  
  
  //checks every active bullet and every active enemy for collision
  //processor demanding
  public void checkCollisions() {
     
    //System.out.println("Checking collisions"); 
    
    //for each bullet
    for(int i = 0; i < playerBullets.size(); i++) {
      
      
      //for each enemy
      for (int e = 0; e < enemies.size(); e++) {
       
        //if the bullet is on the visible screen
        if(playerBullets.get(i).status) {
          //get the necessary variables in order to check collision
          float enemyX = enemies.get(e).xC;    
          float enemyY = enemies.get(e).yC;   
        
          float bulletX = playerBullets.get(i).xCoor; 
          float bulletY = playerBullets.get(i).yCoor;
          
          //System.out.println("Enemy XC: " + enemyX);
          //System.out.println("Enemy YC: " + enemyY);
          //System.out.println("Bullet XC: " + bulletX); 
          //System.out.println("Bullet YC: " + bulletY);
        
          //testing only
          //System.out.println("Collision: " + collision);
          //testing only
          
          
          //if the origin of the circle (the bullet) + the radius of the circle is within the square that is occupied by an enemy then there has been a collision
          if(  ( ((enemyX-bulletSize/2) < bulletX) & (bulletX < (enemyX+20+bulletSize/2)) ) & ( ((enemyY-bulletSize/2) < bulletY) & (bulletY < (enemyY+20+bulletSize/2)) ) & (enemies.get(e).getEnemyType() != "Phalax") & (enemies.get(e).getEnemyType() != "ElectroQuad") )  {
            
            //println("There has been a collision");
            collision = true;
            
            //deal the damage
            
            System.out.println(playerBullets.get(i).getDamage() + " damage dealt to enemy");
            
            boolean death = false;
            
            death = enemies.get(e).receiveDamage(playerBullets.get(i).getDamage());
            
            //if an enemy death has occured, remove it from the game
            if(death) {
              System.out.println("There has been a MURDER");
              
              //get the appropriate score to add
              int addedScore = enemies.get(e).getScore();
              score = score + addedScore; 
          
              //set the players score
              players[0].setScore(score);
              
              //remove the enemy from the game
              enemies.remove(enemies.get(e));
              
            }
            
          } else if (enemies.get(e).getEnemyType() == "Phalax") {
            
            boolean phalaxCollision = false; 
            
            //first hitbox (left of head)
            if(   ((enemyX+20-bulletSize/2) < bulletX) & (bulletX < (enemyX+40+bulletSize/2)) & ( ((enemyY-bulletSize/2) < bulletY) & (bulletY < (enemyY+20+bulletSize/2)) ) ) { phalaxCollision = true; }
              
            //second hitbox (right of head)
            if(   ((enemyX+40-bulletSize/2) < bulletX) & (bulletX < (enemyX+60+bulletSize/2)) & ( ((enemyY-bulletSize/2) < bulletY) & (bulletY < (enemyY+20+bulletSize/2)) ) ) { phalaxCollision = true; }
            
           
           
           
            //third hitbox (left of chin and neck)
            if(   ((enemyX+20-bulletSize/2) < bulletX) & (bulletX < (enemyX+40+bulletSize/2)) & ( ((enemyY+20-bulletSize/2) < bulletY) & (bulletY < (enemyY+40+bulletSize/2)) ) ) { phalaxCollision = true; }
            
            //fourth hitbox (right of chin and neck)
            if(   ((enemyX+40-bulletSize/2) < bulletX) & (bulletX < (enemyX+60+bulletSize/2)) & ( ((enemyY+20-bulletSize/2) < bulletY) & (bulletY < (enemyY+40+bulletSize/2)) ) ) { phalaxCollision = true; }
            
            
            
            
            
            //fifth hitbox (left arm)
            if(   ((enemyX-bulletSize/2) < bulletX) & (bulletX < (enemyX+20+bulletSize/2)) & ( ((enemyY+40-bulletSize/2) < bulletY) & (bulletY < (enemyY+60+bulletSize/2)) ) ) { phalaxCollision = true; }
            
            //sixth hitbox (left shoulder)
            if(   ((enemyX+20-bulletSize/2) < bulletX) & (bulletX < (enemyX+40+bulletSize/2)) & ( ((enemyY+40-bulletSize/2) < bulletY) & (bulletY < (enemyY+60+bulletSize/2)) ) ) { phalaxCollision = true; }
            
            //seventh hitbox (right shoulder)
            if(   ((enemyX+40-bulletSize/2) < bulletX) & (bulletX < (enemyX+60+bulletSize/2)) & ( ((enemyY+40-bulletSize/2) < bulletY) & (bulletY < (enemyY+60+bulletSize/2)) ) ) { phalaxCollision = true; }
            
            //eighth hitbox (right arm)
            if(   ((enemyX+60-bulletSize/2) < bulletX) & (bulletX < (enemyX+80+bulletSize/2)) & ( ((enemyY+40-bulletSize/2) < bulletY) & (bulletY < (enemyY+60+bulletSize/2)) ) ) { phalaxCollision = true; }
            
            
            
            
            //ninth hitbox (left knee and thigh)
            if(   ((enemyX+20-bulletSize/2) < bulletX) & (bulletX < (enemyX+40+bulletSize/2)) & ( ((enemyY+60-bulletSize/2) < bulletY) & (bulletY < (enemyY+80+bulletSize/2)) ) ) { phalaxCollision = true; }
            
            //tenth hitbox (right knee and thigh)
            if(   ((enemyX+40-bulletSize/2) < bulletX) & (bulletX < (enemyX+60+bulletSize/2)) & ( ((enemyY+60-bulletSize/2) < bulletY) & (bulletY < (enemyY+80+bulletSize/2)) ) ) { phalaxCollision = true; }
            
            
            
            
            
            //eleventh hitbox (left chin and foot)
            if(   ((enemyX+20-bulletSize/2) < bulletX) & (bulletX < (enemyX+40+bulletSize/2)) & ( ((enemyY+80-bulletSize/2) < bulletY) & (bulletY < (enemyY+100+bulletSize/2)) ) ) { phalaxCollision = true; }
            
            //twelvth hitbox (right chin and foot)
            if(   ((enemyX+40-bulletSize/2) < bulletX) & (bulletX < (enemyX+60+bulletSize/2)) & ( ((enemyY+80-bulletSize/2) < bulletY) & (bulletY < (enemyY+100+bulletSize/2)) ) ) { phalaxCollision = true; }

              
            
            if(phalaxCollision) {
              
               System.out.println("PHALAX COLLISION");
              
               boolean death = false;
            
               death = enemies.get(e).receiveDamage(playerBullets.get(i).getDamage());
            
              //if an enemy death has occured, remove it from the game
              if(death) {
                System.out.println("There has been a MURDER");
              
                //get the appropriate score to add
                int addedScore = enemies.get(e).getScore();
                score = score + addedScore; 
          
                //set the players score
                players[0].setScore(score);
              
                //remove the enemy from the game
                enemies.remove(enemies.get(e));
                
                this.generateBiome();
              
              
              }
          
            
            }
          
         } else if (enemies.get(e).getEnemyType().equals("HiveMaster")) {
              
              int collisions = 0;
              boolean hiveMasterCollision = false; 
            
            //first hitbox (left of head)
            if(   ((enemyX+20-bulletSize/2) < bulletX) & (bulletX < (enemyX+40+bulletSize/2)) & ( ((enemyY-bulletSize/2) < bulletY) & (bulletY < (enemyY+20+bulletSize/2)) ) ) { hiveMasterCollision = true; collisions++; }
              
            //second hitbox (middle of head)
            if(   ((enemyX+40-bulletSize/2) < bulletX) & (bulletX < (enemyX+60+bulletSize/2)) & ( ((enemyY-bulletSize/2) < bulletY) & (bulletY < (enemyY+20+bulletSize/2)) ) ) { hiveMasterCollision = true; collisions++;}
            
            //third hitbox (right of head)
            if(   ((enemyX+60-bulletSize/2) < bulletX) & (bulletX < (enemyX+80+bulletSize/2)) & ( ((enemyY-bulletSize/2) < bulletY) & (bulletY < (enemyY+20+bulletSize/2)) ) ) { hiveMasterCollision = true; collisions++;}
            
           
           
           
            //fourth hitbox (left of chin and neck)
            if(   ((enemyX+20-bulletSize/2) < bulletX) & (bulletX < (enemyX+40+bulletSize/2)) & ( ((enemyY+20-bulletSize/2) < bulletY) & (bulletY < (enemyY+40+bulletSize/2)) ) ) { hiveMasterCollision = true; collisions++;}
            
            //fifth hitbox (middle of chin and neck)
            if(   ((enemyX+40-bulletSize/2) < bulletX) & (bulletX < (enemyX+60+bulletSize/2)) & ( ((enemyY+20-bulletSize/2) < bulletY) & (bulletY < (enemyY+40+bulletSize/2)) ) ) { hiveMasterCollision = true; collisions++;}
            
            //sixth hitbox (right of chin and neck)
            if(   ((enemyX+60-bulletSize/2) < bulletX) & (bulletX < (enemyX+80+bulletSize/2)) & ( ((enemyY+20-bulletSize/2) < bulletY) & (bulletY < (enemyY+40+bulletSize/2)) ) ) { hiveMasterCollision = true; collisions++;}
            
            
            
            
            
            //seventh hitbox (left arm)
            if(   ((enemyX-bulletSize/2) < bulletX) & (bulletX < (enemyX+20+bulletSize/2)) & ( ((enemyY+40-bulletSize/2) < bulletY) & (bulletY < (enemyY+60+bulletSize/2)) ) ) { hiveMasterCollision = true; collisions++;}
            
            //eight hitbox (left shoulder)
            if(   ((enemyX+20-bulletSize/2) < bulletX) & (bulletX < (enemyX+40+bulletSize/2)) & ( ((enemyY+40-bulletSize/2) < bulletY) & (bulletY < (enemyY+60+bulletSize/2)) ) ) { hiveMasterCollision = true; collisions++;}
            
            //ninth hitbox (chest)
            if(   ((enemyX+40-bulletSize/2) < bulletX) & (bulletX < (enemyX+60+bulletSize/2)) & ( ((enemyY+40-bulletSize/2) < bulletY) & (bulletY < (enemyY+60+bulletSize/2)) ) ) { hiveMasterCollision = true; collisions++;}
            
            //tenth hitbox (right shoulder)
            if(   ((enemyX+60-bulletSize/2) < bulletX) & (bulletX < (enemyX+80+bulletSize/2)) & ( ((enemyY+40-bulletSize/2) < bulletY) & (bulletY < (enemyY+60+bulletSize/2)) ) ) { hiveMasterCollision = true; collisions++;}
            
            //eleventh hitbox (right arm)
            if(   ((enemyX+80-bulletSize/2) < bulletX) & (bulletX < (enemyX+100+bulletSize/2)) & ( ((enemyY+40-bulletSize/2) < bulletY) & (bulletY < (enemyY+60+bulletSize/2)) ) ) { hiveMasterCollision = true; collisions++;}
            
            
            
            
            //twelvth hitbox (left part of stomach)
            if(   ((enemyX-bulletSize/2) < bulletX) & (bulletX < (enemyX+20+bulletSize/2)) & ( ((enemyY+60-bulletSize/2) < bulletY) & (bulletY < (enemyY+80+bulletSize/2)) ) ) { hiveMasterCollision = true; collisions++;}
            
            //thirteenth hitbox 
            if(   ((enemyX+20-bulletSize/2) < bulletX) & (bulletX < (enemyX+40+bulletSize/2)) & ( ((enemyY+60-bulletSize/2) < bulletY) & (bulletY < (enemyY+80+bulletSize/2)) ) ) { hiveMasterCollision = true; collisions++;}
            
            
             //fourteenth hitbox 
            if(   ((enemyX+40-bulletSize/2) < bulletX) & (bulletX < (enemyX+60+bulletSize/2)) & ( ((enemyY+60-bulletSize/2) < bulletY) & (bulletY < (enemyY+80+bulletSize/2)) ) ) { hiveMasterCollision = true; collisions++;}
            
             //fifteenth hitbox 
            if(   ((enemyX+60-bulletSize/2) < bulletX) & (bulletX < (enemyX+80+bulletSize/2)) & ( ((enemyY+60-bulletSize/2) < bulletY) & (bulletY < (enemyY+80+bulletSize/2)) ) ) { hiveMasterCollision = true; collisions++;}
            
             //sixteenth hitbox 
            if(   ((enemyX+80-bulletSize/2) < bulletX) & (bulletX < (enemyX+100+bulletSize/2)) & ( ((enemyY+60-bulletSize/2) < bulletY) & (bulletY < (enemyY+80+bulletSize/2)) ) ) { hiveMasterCollision = true; collisions++;}
            
            
            
            
            //17th
            if(   ((enemyX-bulletSize/2) < bulletX) & (bulletX < (enemyX+20+bulletSize/2)) & ( ((enemyY+80-bulletSize/2) < bulletY) & (bulletY < (enemyY+100+bulletSize/2)) ) ) { hiveMasterCollision = true; collisions++;}
            
            //18th
            if(   ((enemyX+20-bulletSize/2) < bulletX) & (bulletX < (enemyX+40+bulletSize/2)) & ( ((enemyY+80-bulletSize/2) < bulletY) & (bulletY < (enemyY+100+bulletSize/2)) ) ) { hiveMasterCollision = true; collisions++;}
              
              
             //19th
            if(   ((enemyX+40-bulletSize/2) < bulletX) & (bulletX < (enemyX+60+bulletSize/2)) & ( ((enemyY+80-bulletSize/2) < bulletY) & (bulletY < (enemyY+100+bulletSize/2)) ) ) { hiveMasterCollision = true; collisions++;} 
            
            //20th
            if(   ((enemyX+60-bulletSize/2) < bulletX) & (bulletX < (enemyX+80+bulletSize/2)) & ( ((enemyY+80-bulletSize/2) < bulletY) & (bulletY < (enemyY+100+bulletSize/2)) ) ) { hiveMasterCollision = true; collisions++;} 
            
            //21st
            if(   ((enemyX+80-bulletSize/2) < bulletX) & (bulletX < (enemyX+100+bulletSize/2)) & ( ((enemyY+80-bulletSize/2) < bulletY) & (bulletY < (enemyY+100+bulletSize/2)) ) ) { hiveMasterCollision = true; collisions++;} 
              
              
              if(hiveMasterCollision) {
              
               System.out.println("HiveMaster COLLISION");
              
               boolean death = false;
            
               death = enemies.get(e).receiveDamage(playerBullets.get(i).getDamage()*collisions);
               
               collisions = 0;
            
              //if an enemy death has occured, remove it from the game
              if(death) {
                System.out.println("There has been a MURDER");
              
                //get the appropriate score to add
                int addedScore = enemies.get(e).getScore();
                score = score + addedScore; 
          
                //set the players score
                players[0].setScore(score);
              
                //remove the enemy from the game
                enemies.remove(enemies.get(e));
                
                this.generateTropical();
              
              
              }
          
            
            }
              
            } else if (enemies.get(e).getEnemyType().equals("PirateShip")) {
              
              int collisions = 0;
              boolean pirateCollision = false;
              
              //the pirate ship image is eleven blocks wide and 5 blocks tall, but not all of those boxes should be hitboxes
              //the pirate ship hit box image looks like the following: 
              
              /*
              
              o o o o o x x x o o o 
              o o x x x x x x x o o 
              x x x x x x x x x x x 
              o x x x x x x x x x o 
              o o x x x x x x x x o 
              
              
              */
              
              
              
              
              
              //first row
              
            if(   ((enemyX+100-bulletSize/2) < bulletX) & (bulletX < (enemyX+120+bulletSize/2)) & ( ((enemyY-bulletSize/2) < bulletY) & (bulletY < (enemyY+20+bulletSize/2)) ) ) { pirateCollision = true; collisions++; }
            
            if(   ((enemyX+120-bulletSize/2) < bulletX) & (bulletX < (enemyX+140+bulletSize/2)) & ( ((enemyY-bulletSize/2) < bulletY) & (bulletY < (enemyY+20+bulletSize/2)) ) ) { pirateCollision = true; collisions++; }
              
            if(   ((enemyX+140-bulletSize/2) < bulletX) & (bulletX < (enemyX+160+bulletSize/2)) & ( ((enemyY-bulletSize/2) < bulletY) & (bulletY < (enemyY+20+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
            
            
            //second row
            
            if(   ((enemyX+40-bulletSize/2) < bulletX) & (bulletX < (enemyX+60+bulletSize/2)) & ( ((enemyY+20-bulletSize/2) < bulletY) & (bulletY < (enemyY+40+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
            
            if(   ((enemyX+60-bulletSize/2) < bulletX) & (bulletX < (enemyX+80+bulletSize/2)) & ( ((enemyY+20-bulletSize/2) < bulletY) & (bulletY < (enemyY+40+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
            
            if(   ((enemyX+80-bulletSize/2) < bulletX) & (bulletX < (enemyX+100+bulletSize/2)) & ( ((enemyY+20-bulletSize/2) < bulletY) & (bulletY < (enemyY+40+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
            
            if(   ((enemyX+100-bulletSize/2) < bulletX) & (bulletX < (enemyX+120+bulletSize/2)) & ( ((enemyY+20-bulletSize/2) < bulletY) & (bulletY < (enemyY+40+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
            
            if(   ((enemyX+120-bulletSize/2) < bulletX) & (bulletX < (enemyX+140+bulletSize/2)) & ( ((enemyY+20-bulletSize/2) < bulletY) & (bulletY < (enemyY+40+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
            
            if(   ((enemyX+140-bulletSize/2) < bulletX) & (bulletX < (enemyX+160+bulletSize/2)) & ( ((enemyY+20-bulletSize/2) < bulletY) & (bulletY < (enemyY+40+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
            
            if(   ((enemyX+160-bulletSize/2) < bulletX) & (bulletX < (enemyX+180+bulletSize/2)) & ( ((enemyY+20-bulletSize/2) < bulletY) & (bulletY < (enemyY+40+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
            
            
            
            //third row
            
             if(   ((enemyX+bulletSize/2) < bulletX) & (bulletX < (enemyX+20+bulletSize/2)) & ( ((enemyY+40-bulletSize/2) < bulletY) & (bulletY < (enemyY+60+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
             
             if(   ((enemyX+20+bulletSize/2) < bulletX) & (bulletX < (enemyX+40+bulletSize/2)) & ( ((enemyY+40-bulletSize/2) < bulletY) & (bulletY < (enemyY+60+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
             
             if(   ((enemyX+40+bulletSize/2) < bulletX) & (bulletX < (enemyX+60+bulletSize/2)) & ( ((enemyY+40-bulletSize/2) < bulletY) & (bulletY < (enemyY+60+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
             
             if(   ((enemyX+60+bulletSize/2) < bulletX) & (bulletX < (enemyX+80+bulletSize/2)) & ( ((enemyY+40-bulletSize/2) < bulletY) & (bulletY < (enemyY+60+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
             
              if(   ((enemyX+80+bulletSize/2) < bulletX) & (bulletX < (enemyX+100+bulletSize/2)) & ( ((enemyY+40-bulletSize/2) < bulletY) & (bulletY < (enemyY+60+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
             
             if(   ((enemyX+100+bulletSize/2) < bulletX) & (bulletX < (enemyX+120+bulletSize/2)) & ( ((enemyY+40-bulletSize/2) < bulletY) & (bulletY < (enemyY+60+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
             
             if(   ((enemyX+120+bulletSize/2) < bulletX) & (bulletX < (enemyX+140+bulletSize/2)) & ( ((enemyY+40-bulletSize/2) < bulletY) & (bulletY < (enemyY+60+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
             
             if(   ((enemyX+140+bulletSize/2) < bulletX) & (bulletX < (enemyX+160+bulletSize/2)) & ( ((enemyY+40-bulletSize/2) < bulletY) & (bulletY < (enemyY+60+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
             
              if(   ((enemyX+160+bulletSize/2) < bulletX) & (bulletX < (enemyX+180+bulletSize/2)) & ( ((enemyY+40-bulletSize/2) < bulletY) & (bulletY < (enemyY+60+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
             
             if(   ((enemyX+180+bulletSize/2) < bulletX) & (bulletX < (enemyX+200+bulletSize/2)) & ( ((enemyY+40-bulletSize/2) < bulletY) & (bulletY < (enemyY+60+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
             
             if(   ((enemyX+200+bulletSize/2) < bulletX) & (bulletX < (enemyX+220+bulletSize/2)) & ( ((enemyY+40-bulletSize/2) < bulletY) & (bulletY < (enemyY+60+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
             
            
            //fourth row
            
            if(   ((enemyX+20+bulletSize/2) < bulletX) & (bulletX < (enemyX+40+bulletSize/2)) & ( ((enemyY+60-bulletSize/2) < bulletY) & (bulletY < (enemyY+80+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
             
             if(   ((enemyX+40+bulletSize/2) < bulletX) & (bulletX < (enemyX+60+bulletSize/2)) & ( ((enemyY+60-bulletSize/2) < bulletY) & (bulletY < (enemyY+80+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
             
             if(   ((enemyX+60+bulletSize/2) < bulletX) & (bulletX < (enemyX+80+bulletSize/2)) & ( ((enemyY+60-bulletSize/2) < bulletY) & (bulletY < (enemyY+80+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
             
              if(   ((enemyX+80+bulletSize/2) < bulletX) & (bulletX < (enemyX+100+bulletSize/2)) & ( ((enemyY+60-bulletSize/2) < bulletY) & (bulletY < (enemyY+80+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
             
             if(   ((enemyX+100+bulletSize/2) < bulletX) & (bulletX < (enemyX+120+bulletSize/2)) & ( ((enemyY+60-bulletSize/2) < bulletY) & (bulletY < (enemyY+80+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
             
             if(   ((enemyX+120+bulletSize/2) < bulletX) & (bulletX < (enemyX+140+bulletSize/2)) & ( ((enemyY+60-bulletSize/2) < bulletY) & (bulletY < (enemyY+80+bulletSize/2)) ) ) { pirateCollision = true; collisions++; }
             
             if(   ((enemyX+140+bulletSize/2) < bulletX) & (bulletX < (enemyX+160+bulletSize/2)) & ( ((enemyY+60-bulletSize/2) < bulletY) & (bulletY < (enemyY+80+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
             
              if(   ((enemyX+160+bulletSize/2) < bulletX) & (bulletX < (enemyX+180+bulletSize/2)) & ( ((enemyY+60-bulletSize/2) < bulletY) & (bulletY < (enemyY+80+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
             
             if(   ((enemyX+180+bulletSize/2) < bulletX) & (bulletX < (enemyX+200+bulletSize/2)) & ( ((enemyY+60-bulletSize/2) < bulletY) & (bulletY < (enemyY+80+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
             
             
             //fifth row
             
             if(   ((enemyX+40+bulletSize/2) < bulletX) & (bulletX < (enemyX+60+bulletSize/2)) & ( ((enemyY+80-bulletSize/2) < bulletY) & (bulletY < (enemyY+100+bulletSize/2)) ) ) { pirateCollision = true; collisions++; }
             
             if(   ((enemyX+60+bulletSize/2) < bulletX) & (bulletX < (enemyX+80+bulletSize/2)) & ( ((enemyY+80-bulletSize/2) < bulletY) & (bulletY < (enemyY+100+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
             
              if(   ((enemyX+80+bulletSize/2) < bulletX) & (bulletX < (enemyX+100+bulletSize/2)) & ( ((enemyY+80-bulletSize/2) < bulletY) & (bulletY < (enemyY+100+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
             
             if(   ((enemyX+100+bulletSize/2) < bulletX) & (bulletX < (enemyX+120+bulletSize/2)) & ( ((enemyY+80-bulletSize/2) < bulletY) & (bulletY < (enemyY+100+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
             
             if(   ((enemyX+120+bulletSize/2) < bulletX) & (bulletX < (enemyX+140+bulletSize/2)) & ( ((enemyY+80-bulletSize/2) < bulletY) & (bulletY < (enemyY+100+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
             
             if(   ((enemyX+140+bulletSize/2) < bulletX) & (bulletX < (enemyX+160+bulletSize/2)) & ( ((enemyY+80-bulletSize/2) < bulletY) & (bulletY < (enemyY+100+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
             
              if(   ((enemyX+160+bulletSize/2) < bulletX) & (bulletX < (enemyX+180+bulletSize/2)) & ( ((enemyY+80-bulletSize/2) < bulletY) & (bulletY < (enemyY+100+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
             
             if(   ((enemyX+180+bulletSize/2) < bulletX) & (bulletX < (enemyX+200+bulletSize/2)) & ( ((enemyY+80-bulletSize/2) < bulletY) & (bulletY < (enemyY+100+bulletSize/2)) ) ) { pirateCollision = true; collisions++;}
             
             
              if(pirateCollision) {
              
               System.out.println("Pirate COLLISION");
               System.out.println("collisions: " + collisions);
              
               boolean death = false;
            
               death = enemies.get(e).receiveDamage(playerBullets.get(i).getDamage()*collisions);
               
               collisions = 0;
            
              //if an enemy death has occured, remove it from the game
              if(death) {
                System.out.println("There has been a MURDER");
              
                //get the appropriate score to add
                int addedScore = enemies.get(e).getScore();
                score = score + addedScore; 
          
                //set the players score
                players[0].setScore(score);
              
                //remove the enemy from the game
                enemies.remove(enemies.get(e));
                
                
                
                System.out.println("You have won the game");
              
              
              }
          
            
            }
              
              
            } else if (enemies.get(e).getEnemyType() == "ElectroQuad" || enemies.get(e).getEnemyType() == "ElectroDuo" || enemies.get(e).getEnemyType() == "Gorilla") {
           
           boolean electroQuadCollision = false;
           
           //first hitbox (left of head)
            if(   ((enemyX+20-bulletSize/2) < bulletX) & (bulletX < (enemyX+40+bulletSize/2)) & ( ((enemyY-bulletSize/2) < bulletY) & (bulletY < (enemyY+20+bulletSize/2)) ) ) { electroQuadCollision = true; }
              
            //second hitbox (right of head)
            if(   ((enemyX+40-bulletSize/2) < bulletX) & (bulletX < (enemyX+60+bulletSize/2)) & ( ((enemyY-bulletSize/2) < bulletY) & (bulletY < (enemyY+20+bulletSize/2)) ) ) { electroQuadCollision = true; }
            
           
           
           
            //third hitbox (left of body)
            if(   ((enemyX+20-bulletSize/2) < bulletX) & (bulletX < (enemyX+40+bulletSize/2)) & ( ((enemyY+20-bulletSize/2) < bulletY) & (bulletY < (enemyY+40+bulletSize/2)) ) ) { electroQuadCollision = true; }
            
            //fourth hitbox (right of body)
            if(   ((enemyX+40-bulletSize/2) < bulletX) & (bulletX < (enemyX+60+bulletSize/2)) & ( ((enemyY+20-bulletSize/2) < bulletY) & (bulletY < (enemyY+40+bulletSize/2)) ) ) { electroQuadCollision = true; }
            
            
            if(electroQuadCollision & enemies.get(e).getEnemyType().equals("ElectroQuad")) {
             
              
               System.out.println("ELECTRO QUAD COLLISION");
              
               boolean death = false;
            
               death = enemies.get(e).receiveDamage(playerBullets.get(i).getDamage());
            
              //if an enemy death has occured, remove it from the game
              if(death) {
                System.out.println("There has been a MURDER");
              
                //get the appropriate score to add
                int addedScore = enemies.get(e).getScore();
                score = score + addedScore; 
          
                //set the players score
                players[0].setScore(score);
                
                //spawn two electro duo's near where this electro quad died
                if(enemies.get(e).getEnemyType().equals("ElectroQuad")) { electroQuadDeath(enemyX, enemyY); }
              
                //remove the enemy from the game
                enemies.remove(enemies.get(e));
                
                
                
              
              
              }
          
            
            } else if (electroQuadCollision & enemies.get(e).getEnemyType().equals("ElectroDuo")) {
              
              System.out.println("ELECTRO DUO COLLISION");
              
               boolean death = false;
            
               death = enemies.get(e).receiveDamage(playerBullets.get(i).getDamage());
            
              //if an enemy death has occured, remove it from the game
              if(death) {
                System.out.println("There has been a MURDER");
              
                //get the appropriate score to add
                int addedScore = enemies.get(e).getScore();
                score = score + addedScore; 
          
                //set the players score
                players[0].setScore(score);
                
                //spawn two electro duo's near where this electro quad died
                electroDuoDeath(enemyX, enemyY);
              
                //remove the enemy from the game
                enemies.remove(enemies.get(e));
                
              }
              
              
            } 
           
           
           
         }
      }
      
     }
    }
    
    
  }
  
  public void electroDuoDeath(float deathX, float deathY) {
    
    //TODO: make sure not outside of gameboard
      ElectroMan tempMan1 = new ElectroMan(deathX, deathY+40);
      
      ElectroMan tempMan2 = new ElectroMan(deathX, deathY-40);
      
      ElectroMan tempMan3 = new ElectroMan(deathX+40, deathY);
      
      ElectroMan tempMan4 = new ElectroMan(deathX-40, deathY);
      
      
      enemies.add(tempMan1);
      enemies.add(tempMan2);
      enemies.add(tempMan3);
      enemies.add(tempMan4);
      
    
  }
  
  public void electroQuadDeath(float deathX, float deathY) {
    
    //TODO: make sure not outside of gameboard
      ElectroDuo tempDuo1 = new ElectroDuo(deathX, deathY+40);
      
      ElectroDuo tempDuo2 = new ElectroDuo(deathX, deathY-40);
      
     
      enemies.add(tempDuo1);
      enemies.add(tempDuo2);
      
    
  }
  
  
  public void introducePhalaxBullet(int shootingAtX, int shootingAtY, int phalaxX, int phalaxY, int damage) {
    
    System.out.println("Phalax Shooting"); 
   
    introduceFlowerBullet(shootingAtX, shootingAtY, phalaxX, phalaxY, damage, false); 
    introduceFlowerBullet(shootingAtX+20, shootingAtY+20, phalaxX+20, phalaxY+20, damage, false);
    introduceFlowerBullet(shootingAtX+40, shootingAtY+40, phalaxX+40, phalaxY+40, damage, false);
    introduceFlowerBullet(shootingAtX+60, shootingAtY+60, phalaxX+60, phalaxY+60, damage, false);
    introduceFlowerBullet(shootingAtX+80, shootingAtY+80, phalaxX+80, phalaxY+80, damage, false);
    
    introduceRobotBullet(shootingAtX, shootingAtY, phalaxX, phalaxY, damage, false); 
    introduceRobotBullet(shootingAtX+20, shootingAtY+20, phalaxX+20, phalaxY+20, damage, false);
    introduceRobotBullet(shootingAtX+40, shootingAtY+40, phalaxX+40, phalaxY+40, damage, false);
    introduceRobotBullet(shootingAtX+60, shootingAtY+60, phalaxX+60, phalaxY+60, damage, false);
    introduceRobotBullet(shootingAtX+80, shootingAtY+80, phalaxX+80, phalaxY+80, damage, false);
    
  }
  
  
  public void introduceCannonBullet(int shootingAtX, int shootingAtY, int robotX, int robotY, int damage) {
    
    System.out.println("ROBOT SHOOTING");
    
    println("Shooting from (" + robotX + "," + robotY + ")");
    println("Shooting at (" + shootingAtX + "," + shootingAtY + ")");
    
    CannonBullet tempCannonBullet; 
    
    float a = 0; 
    float b = 0; 
    float hypotenuse = 0; 
    float theta = 0.0f; 
    
    float ratio;
    float xPercentage;
    float yPercentage; 
    
    float xSpeed = 0; 
    float ySpeed = 0; 
    
    
    
    if (robotY >= shootingAtY) {   //the robot is shooting upwards or horizontally
      
      
      if(robotX <= shootingAtX) { //the robot is shooting to the right and up
         println("the robot is shooting to the right and up");
         
         //calculating lengths of sides of the right angle triangle
         b = shootingAtX - robotX; 
         a = robotY - shootingAtY; 
         
         //calculating the size of the hypotenuse
         hypotenuse = sqrt( (b*b) + (a*a) );
         
         //calculating the angle of the bullet
         theta = asin(  (a/hypotenuse) );
         
         //println("Theta: " + theta); 
         
         //These next lines essentially calculate the appropriate X and Y components
         //of the bullet, in order to generate the appropriate X and Y speeds,
         //to feel as though one has the ability to shoot at any angle desired
         
         ratio = theta / 1.570796326f;  //pi/2 
         
        // println("Ratio: " + ratio); 
         ratio = ratio*100;
         
         yPercentage = ratio; 
         xPercentage = 100 - yPercentage; 
         
         ySpeed = yPercentage/10; 
         xSpeed = xPercentage/10;
         
         //get negative Y speed for this case
         ySpeed = ySpeed - ySpeed*2; 
         
        // System.out.println("X speed of bullet: " + xSpeed); 
       //  System.out.println("Y speed of bullet: " + ySpeed); 
         
         tempCannonBullet = new CannonBullet(xSpeed*4, ySpeed*4, 10, robotX, robotY, (int)damage/2); 
      
      } else if (robotX > shootingAtX) { //the robot is shooting to the left and up
        // println("the robot is shooting to the left and up");
       //  
         
         b = robotX - shootingAtX; 
         a = robotY - shootingAtY; 
         
         hypotenuse = sqrt( (b*b) + (a*a) );
         
         theta = asin(  (a/hypotenuse) );
         
        // println("Theta: " + theta);
         
         
         //These next lines essentially calculate the appropriate X and Y components
         //of the bullet, in order to generate the appropriate X and Y speeds,
         //to feel as though one has the ability to shoot at any angle desired
         
         ratio = theta / 1.570796326f;  //pi/2 
         
        // println("Ratio: " + ratio); 
         ratio = ratio*100;
         
         yPercentage = ratio; 
         xPercentage = 100 - yPercentage; 
         
         ySpeed = yPercentage/10; 
         xSpeed = xPercentage/10;
         
         //get negative Y speed for this case
         ySpeed = ySpeed - ySpeed*2;
         
         //get negative X speed for this case
         xSpeed = xSpeed - xSpeed*2; 
         
        // System.out.println("X speed of bullet: " + xSpeed); 
         //System.out.println("Y speed of bullet: " + ySpeed); 
         
         tempCannonBullet = new CannonBullet(xSpeed*4, ySpeed*4, 10, robotX, robotY, (int)damage/2); 
      
      }
      
    } else if (robotY < shootingAtY) { //the player is shooting down
   
        if(robotX <= shootingAtX) { //the player is shooting to the right and down
         //  println("the player is shooting to the right and down");
           
           a = shootingAtY - robotY; 
           b = shootingAtX - robotX;
           
           hypotenuse = sqrt( (b*b) + (a*a) );
         
           theta = asin(  (a/hypotenuse) );
         
         //  println("Theta: " + theta);
           
           
           //These next lines essentially calculate the appropriate X and Y components
           //of the bullet, in order to generate the appropriate X and Y speeds,
           //to feel as though one has the ability to shoot at any angle desired
         
           ratio = theta / 1.570796326f;  //pi/2 
         
        //   println("Ratio: " + ratio); 
           ratio = ratio*100;
         
           yPercentage = ratio; 
           xPercentage = 100 - yPercentage; 
         
           ySpeed = yPercentage/10; 
           xSpeed = xPercentage/10;
         
         //  System.out.println("X speed of bullet: " + xSpeed); 
         //  System.out.println("Y speed of bullet: " + ySpeed); 
           
           tempCannonBullet = new CannonBullet(xSpeed*4, ySpeed*4, 10, robotX, robotY, (int)damage/2); 
           
        } else if (robotX > shootingAtX) { //the robot is shooting to the left and down
         //  println("the robot is shooting to the left and down");
         //  
           
           b = robotX - shootingAtX; 
           a = shootingAtY - robotY;
           
           hypotenuse = sqrt( (b*b) + (a*a) );
         
           theta = asin(  (a/hypotenuse) );
         
         //  println("Theta: " + theta);        
           
           //These next lines essentially calculate the appropriate X and Y components
           //of the bullet, in order to generate the appropriate X and Y speeds,
           //to feel as though one has the ability to shoot at any angle desired
         
           ratio = theta / 1.570796326f;  //pi/2 
         
         //  println("Ratio: " + ratio); 
           ratio = ratio*100;
         
           yPercentage = ratio; 
           xPercentage = 100 - yPercentage; 
         
           ySpeed = yPercentage/10; 
           xSpeed = xPercentage/10;
         
           //negative X speed for this case
           xSpeed = xSpeed - xSpeed*2; 
         
          // System.out.println("X speed of bullet: " + xSpeed); 
          // System.out.println("Y speed of bullet: " + ySpeed); 
           
           tempCannonBullet = new CannonBullet(xSpeed*4, ySpeed*4, 10, robotX, robotY, (int)damage/2); 
        }
        
    }
    
    cannonBullets.add(tempCannonBullet = new CannonBullet(xSpeed*4, ySpeed*4, 10, robotX, robotY, (int)damage)); 
    
   
  }
  
  
  
  public void introduceHiveBullet(int shootingAtX, int shootingAtY, int hiveX, int hiveY, int damage) {
    
    System.out.println("HiveMaster shooting");
    
    
    println("Shooting from (" + hiveX + "," + hiveY + ")");
    println("Shooting at (" + shootingAtX + "," + shootingAtY + ")");
    
    HiveBullet tempHiveBullet; 
    
    float a = 0; 
    float b = 0; 
    float hypotenuse = 0; 
    float theta = 0.0f; 
    
    float ratio;
    float xPercentage;
    float yPercentage; 
    
    float xSpeed = 0; 
    float ySpeed = 0; 
    
    
    
    if (hiveY >= shootingAtY) {   //the robot is shooting upwards or horizontally
      
      
      if(hiveX <= shootingAtX) { //the robot is shooting to the right and up
         println("the robot is shooting to the right and up");
         
         //calculating lengths of sides of the right angle triangle
         b = shootingAtX - hiveX; 
         a = hiveY - shootingAtY; 
         
         //calculating the size of the hypotenuse
         hypotenuse = sqrt( (b*b) + (a*a) );
         
         //calculating the angle of the bullet
         theta = asin(  (a/hypotenuse) );
         
         //println("Theta: " + theta); 
         
         //These next lines essentially calculate the appropriate X and Y components
         //of the bullet, in order to generate the appropriate X and Y speeds,
         //to feel as though one has the ability to shoot at any angle desired
         
         ratio = theta / 1.570796326f;  //pi/2 
         
        // println("Ratio: " + ratio); 
         ratio = ratio*100;
         
         yPercentage = ratio; 
         xPercentage = 100 - yPercentage; 
         
         ySpeed = yPercentage/10; 
         xSpeed = xPercentage/10;
         
         //get negative Y speed for this case
         ySpeed = ySpeed - ySpeed*2; 
         
        // System.out.println("X speed of bullet: " + xSpeed); 
       //  System.out.println("Y speed of bullet: " + ySpeed); 
         
         tempHiveBullet = new HiveBullet(xSpeed*2, ySpeed*2, 10, hiveX, hiveY, (int)damage/2); 
      
      } else if (hiveX > shootingAtX) { //the robot is shooting to the left and up
        // println("the robot is shooting to the left and up");
       //  
         
         b = hiveX - shootingAtX; 
         a = hiveY - shootingAtY; 
         
         hypotenuse = sqrt( (b*b) + (a*a) );
         
         theta = asin(  (a/hypotenuse) );
         
        // println("Theta: " + theta);
         
         
         //These next lines essentially calculate the appropriate X and Y components
         //of the bullet, in order to generate the appropriate X and Y speeds,
         //to feel as though one has the ability to shoot at any angle desired
         
         ratio = theta / 1.570796326f;  //pi/2 
         
        // println("Ratio: " + ratio); 
         ratio = ratio*100;
         
         yPercentage = ratio; 
         xPercentage = 100 - yPercentage; 
         
         ySpeed = yPercentage/10; 
         xSpeed = xPercentage/10;
         
         //get negative Y speed for this case
         ySpeed = ySpeed - ySpeed*2;
         
         //get negative X speed for this case
         xSpeed = xSpeed - xSpeed*2; 
         
        // System.out.println("X speed of bullet: " + xSpeed); 
         //System.out.println("Y speed of bullet: " + ySpeed); 
         
         tempHiveBullet = new HiveBullet(xSpeed*2, ySpeed*2, 10, hiveX, hiveY, (int)damage/2); 
      
      }
      
    } else if (hiveY < shootingAtY) { //the player is shooting down
   
        if(hiveX <= shootingAtX) { //the player is shooting to the right and down
         //  println("the player is shooting to the right and down");
           
           a = shootingAtY - hiveY; 
           b = shootingAtX - hiveX;
           
           hypotenuse = sqrt( (b*b) + (a*a) );
         
           theta = asin(  (a/hypotenuse) );
         
         //  println("Theta: " + theta);
           
           
           //These next lines essentially calculate the appropriate X and Y components
           //of the bullet, in order to generate the appropriate X and Y speeds,
           //to feel as though one has the ability to shoot at any angle desired
         
           ratio = theta / 1.570796326f;  //pi/2 
         
        //   println("Ratio: " + ratio); 
           ratio = ratio*100;
         
           yPercentage = ratio; 
           xPercentage = 100 - yPercentage; 
         
           ySpeed = yPercentage/10; 
           xSpeed = xPercentage/10;
         
         //  System.out.println("X speed of bullet: " + xSpeed); 
         //  System.out.println("Y speed of bullet: " + ySpeed); 
           
           tempHiveBullet = new HiveBullet(xSpeed*2, ySpeed*2, 10, hiveX, hiveY, (int)damage/2); 
           
        } else if (hiveX > shootingAtX) { //the robot is shooting to the left and down
         //  println("the robot is shooting to the left and down");
         //  
           
           b = hiveX - shootingAtX; 
           a = shootingAtY - hiveY;
           
           hypotenuse = sqrt( (b*b) + (a*a) );
         
           theta = asin(  (a/hypotenuse) );
         
         //  println("Theta: " + theta);        
           
           //These next lines essentially calculate the appropriate X and Y components
           //of the bullet, in order to generate the appropriate X and Y speeds,
           //to feel as though one has the ability to shoot at any angle desired
         
           ratio = theta / 1.570796326f;  //pi/2 
         
         //  println("Ratio: " + ratio); 
           ratio = ratio*100;
         
           yPercentage = ratio; 
           xPercentage = 100 - yPercentage; 
         
           ySpeed = yPercentage/10; 
           xSpeed = xPercentage/10;
         
           //negative X speed for this case
           xSpeed = xSpeed - xSpeed*2; 
         
          // System.out.println("X speed of bullet: " + xSpeed); 
          // System.out.println("Y speed of bullet: " + ySpeed); 
           
           tempHiveBullet = new HiveBullet(xSpeed*2, ySpeed*2, 10, hiveX, hiveY, (int)damage/2); 
        }
        
    }
    
    hiveBullets.add(tempHiveBullet = new HiveBullet(xSpeed*4, ySpeed*4, 10, hiveX, hiveY, (int)damage/2)); 
    hiveBullets.add(tempHiveBullet = new HiveBullet(xSpeed*4, ySpeed*4, 10, hiveX-40, hiveY, (int)damage/2));
    
  }
    
  
    
    
  
  
  public void introduceRobotBullet(int shootingAtX, int shootingAtY, int robotX, int robotY, int damage, boolean electroQuad) {
    
    System.out.println("ROBOT SHOOTING");
    
    println("Shooting from (" + robotX + "," + robotY + ")");
    println("Shooting at (" + shootingAtX + "," + shootingAtY + ")");
    
    RobotBullet tempRobotBullet; 
    
    float a = 0; 
    float b = 0; 
    float hypotenuse = 0; 
    float theta = 0.0f; 
    
    float ratio;
    float xPercentage;
    float yPercentage; 
    
    float xSpeed = 0; 
    float ySpeed = 0; 
    
    
    
    if (robotY >= shootingAtY) {   //the robot is shooting upwards or horizontally
      
      
      if(robotX <= shootingAtX) { //the robot is shooting to the right and up
         println("the robot is shooting to the right and up");
         
         //calculating lengths of sides of the right angle triangle
         b = shootingAtX - robotX; 
         a = robotY - shootingAtY; 
         
         //calculating the size of the hypotenuse
         hypotenuse = sqrt( (b*b) + (a*a) );
         
         //calculating the angle of the bullet
         theta = asin(  (a/hypotenuse) );
         
         //println("Theta: " + theta); 
         
         //These next lines essentially calculate the appropriate X and Y components
         //of the bullet, in order to generate the appropriate X and Y speeds,
         //to feel as though one has the ability to shoot at any angle desired
         
         ratio = theta / 1.570796326f;  //pi/2 
         
        // println("Ratio: " + ratio); 
         ratio = ratio*100;
         
         yPercentage = ratio; 
         xPercentage = 100 - yPercentage; 
         
         ySpeed = yPercentage/10; 
         xSpeed = xPercentage/10;
         
         //get negative Y speed for this case
         ySpeed = ySpeed - ySpeed*2; 
         
        // System.out.println("X speed of bullet: " + xSpeed); 
       //  System.out.println("Y speed of bullet: " + ySpeed); 
         
         tempRobotBullet = new RobotBullet(xSpeed*2, ySpeed*2, 10, robotX, robotY, (int)damage/2); 
      
      } else if (robotX > shootingAtX) { //the robot is shooting to the left and up
        // println("the robot is shooting to the left and up");
       //  
         
         b = robotX - shootingAtX; 
         a = robotY - shootingAtY; 
         
         hypotenuse = sqrt( (b*b) + (a*a) );
         
         theta = asin(  (a/hypotenuse) );
         
        // println("Theta: " + theta);
         
         
         //These next lines essentially calculate the appropriate X and Y components
         //of the bullet, in order to generate the appropriate X and Y speeds,
         //to feel as though one has the ability to shoot at any angle desired
         
         ratio = theta / 1.570796326f;  //pi/2 
         
        // println("Ratio: " + ratio); 
         ratio = ratio*100;
         
         yPercentage = ratio; 
         xPercentage = 100 - yPercentage; 
         
         ySpeed = yPercentage/10; 
         xSpeed = xPercentage/10;
         
         //get negative Y speed for this case
         ySpeed = ySpeed - ySpeed*2;
         
         //get negative X speed for this case
         xSpeed = xSpeed - xSpeed*2; 
         
        // System.out.println("X speed of bullet: " + xSpeed); 
         //System.out.println("Y speed of bullet: " + ySpeed); 
         
         tempRobotBullet = new RobotBullet(xSpeed*2, ySpeed*2, 10, robotX, robotY, (int)damage/2); 
      
      }
      
    } else if (robotY < shootingAtY) { //the player is shooting down
   
        if(robotX <= shootingAtX) { //the player is shooting to the right and down
         //  println("the player is shooting to the right and down");
           
           a = shootingAtY - robotY; 
           b = shootingAtX - robotX;
           
           hypotenuse = sqrt( (b*b) + (a*a) );
         
           theta = asin(  (a/hypotenuse) );
         
         //  println("Theta: " + theta);
           
           
           //These next lines essentially calculate the appropriate X and Y components
           //of the bullet, in order to generate the appropriate X and Y speeds,
           //to feel as though one has the ability to shoot at any angle desired
         
           ratio = theta / 1.570796326f;  //pi/2 
         
        //   println("Ratio: " + ratio); 
           ratio = ratio*100;
         
           yPercentage = ratio; 
           xPercentage = 100 - yPercentage; 
         
           ySpeed = yPercentage/10; 
           xSpeed = xPercentage/10;
         
         //  System.out.println("X speed of bullet: " + xSpeed); 
         //  System.out.println("Y speed of bullet: " + ySpeed); 
           
           tempRobotBullet = new RobotBullet(xSpeed*2, ySpeed*2, 10, robotX, robotY, (int)damage/2); 
           
        } else if (robotX > shootingAtX) { //the robot is shooting to the left and down
         //  println("the robot is shooting to the left and down");
         //  
           
           b = robotX - shootingAtX; 
           a = shootingAtY - robotY;
           
           hypotenuse = sqrt( (b*b) + (a*a) );
         
           theta = asin(  (a/hypotenuse) );
         
         //  println("Theta: " + theta);        
           
           //These next lines essentially calculate the appropriate X and Y components
           //of the bullet, in order to generate the appropriate X and Y speeds,
           //to feel as though one has the ability to shoot at any angle desired
         
           ratio = theta / 1.570796326f;  //pi/2 
         
         //  println("Ratio: " + ratio); 
           ratio = ratio*100;
         
           yPercentage = ratio; 
           xPercentage = 100 - yPercentage; 
         
           ySpeed = yPercentage/10; 
           xSpeed = xPercentage/10;
         
           //negative X speed for this case
           xSpeed = xSpeed - xSpeed*2; 
         
          // System.out.println("X speed of bullet: " + xSpeed); 
          // System.out.println("Y speed of bullet: " + ySpeed); 
           
           tempRobotBullet = new RobotBullet(xSpeed*2, ySpeed*2, 10, robotX, robotY, (int)damage/2); 
        }
        
    }
    
    robotBullets.add(tempRobotBullet = new RobotBullet(xSpeed*2, ySpeed*2, 10, robotX, robotY, (int)damage/2)); 
    
    if(electroQuad) { 
      
      robotBullets.add(new RobotBullet(xSpeed*2, ySpeed*2, 10, robotX+20, robotY, (int)damage/2));
      robotBullets.add(new RobotBullet(xSpeed*2, ySpeed*2, 10, robotX+40, robotY, (int)damage/2));
    }
  }
    
  public void checkSuperPowerAmount() {
    
    int superLevel = players[0].superPowerUpgradePieces;
    
    if(superLevel < 10) {
    
       weaponAvailable[6].setMaxDamage(100);
       weaponAvailable[6].setMinDamage(100);
     
      
    } else if ((superLevel >= 10) & (superLevel < 20)) {
      
      
       weaponAvailable[6].setMaxDamage(200);
       weaponAvailable[6].setMinDamage(200);
      
      
      
    } else {
      
       weaponAvailable[6].setMaxDamage(300);
       weaponAvailable[6].setMinDamage(300);
      
     
    }
    
  }
  
  public void introduceFlowerBullet(int shootingAtX, int shootingAtY, int flowerX, int flowerY, int damage, boolean electroDuo) {
    
   // println("Shooting from (" + flowerX + "," + flowerY + ")");
   // println("Shooting at (" + shootingAtX + "," + shootingAtY + ")");
    
    FlowerBullet tempFlowerBullet; 
    FlowerBullet tempFlowerBulletDuo; 
    
    //flower is shooting either up or down
    if (flowerX == shootingAtX) {
       
      //flower is directly shooting downwards
       if(flowerY < shootingAtY) {
         
         //no xSpeed
         if(electroDuo) {
           tempFlowerBullet = new FlowerBullet(0,15,20,flowerX,flowerY, damage);
           tempFlowerBulletDuo = new FlowerBullet(0,15,20,flowerX+20,flowerY, damage);
           flowerBullets.add(tempFlowerBulletDuo);
         } else {
           tempFlowerBullet = new FlowerBullet(0,15,10,flowerX,flowerY, damage);
         }
         
      
      //flower is directly shooting updwards
       } else {
         
         //no xSpeed.
         if(electroDuo) {
           tempFlowerBullet = new FlowerBullet(0,-30,20,flowerX,flowerY, damage);
           tempFlowerBulletDuo = new FlowerBullet(0,-30,20,flowerX+20,flowerY, damage);
           flowerBullets.add(tempFlowerBulletDuo);
         } else {
           tempFlowerBullet = new FlowerBullet(0,-30,10,flowerX,flowerY, damage);
         }
         
       }
      
     
    //flower is shooting eith left or right  
    } else {
      
      
      
      //flower is shooting directly to the left
      if (flowerX > shootingAtX) {
        
        //no ySpeed
        if(electroDuo) {
          tempFlowerBullet = new FlowerBullet(-30,0,20,flowerX,flowerY, damage);
          tempFlowerBulletDuo = new FlowerBullet(-30,0,20,flowerX,flowerY+20, damage);
          flowerBullets.add(tempFlowerBulletDuo);
        } else {
          tempFlowerBullet = new FlowerBullet(-30,0,10,flowerX,flowerY, damage);
        }
        
        
        
      //flower is shooting directly to the right  
      } else {
        
        //no ySpeed
        if(electroDuo) {
          tempFlowerBullet = new FlowerBullet(30,0,20,flowerX,flowerY, damage);
          tempFlowerBulletDuo = new FlowerBullet(30,0,20,flowerX,flowerY+20, damage);
          flowerBullets.add(tempFlowerBulletDuo);
        } else {
          tempFlowerBullet = new FlowerBullet(30,0,10,flowerX,flowerY, damage);
        }
        
        
      }
      
      
      
    }
    
    
    flowerBullets.add(tempFlowerBullet); 
    
      
        
  }
  
  public void superPowerApplied() {
    
    System.out.println("Power being applied to the board"); 
    
    //flipped them somewhere along the line
    int originXC = players[0].getYC();
    int originYC = players[0].getXC();
    
    introduceBullet(originXC+10, originYC, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC+10, originYC+1, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC+10, originYC+2, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC+10, originYC+3, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC+10, originYC+4, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC+10, originYC+5, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC+10, originYC+6, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC+10, originYC+7, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC+10, originYC+8, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC+10, originYC+9, originXC, originYC, weaponAvailable[6], false, true);
    
    
    introduceBullet(originXC+10, originYC, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC+10, originYC-1, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC+10, originYC-2, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC+10, originYC-3, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC+10, originYC-4, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC+10, originYC-5, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC+10, originYC-6, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC+10, originYC-7, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC+10, originYC-8, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC+10, originYC-9, originXC, originYC, weaponAvailable[6], false, true);
    
    
    introduceBullet(originXC-10, originYC, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC-10, originYC+1, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC-10, originYC+2, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC-10, originYC+3, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC-10, originYC+4, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC-10, originYC+5, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC-10, originYC+6, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC-10, originYC+7, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC-10, originYC+8, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC-10, originYC+9, originXC, originYC, weaponAvailable[6], false, true);
    
    
    introduceBullet(originXC-10, originYC, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC-10, originYC-1, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC-10, originYC-2, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC-10, originYC-3, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC-10, originYC-4, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC-10, originYC-5, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC-10, originYC-6, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC-10, originYC-7, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC-10, originYC-8, originXC, originYC, weaponAvailable[6], false, true);
    introduceBullet(originXC-10, originYC-9, originXC, originYC, weaponAvailable[6], false, true);
   // players[0].getTommy().addAmmo(30);
    
   
  }
  
  
  public void introduceBullet(int shootingAtX, int shootingAtY, int playerX, int playerY, Weapon weaponUsed, Boolean shotgunBullet, Boolean superPowerBullet) {
    
   // println("Shooting from (" + playerX + "," + playerY + ")");
   // println("Shooting at (" + shootingAtX + "," + shootingAtY + ")");
    
    
    float a = 0; 
    float b = 0; 
    float hypotenuse = 0; 
    float theta = 0.0f; 
    
    float ratio;
    float xPercentage;
    float yPercentage; 
    
    float xSpeed; 
    float ySpeed; 
    
    weaponUsed.useAmmo(1);
    
    
    //System.out.println("Max damage of weapon used: " + weaponUsed.getMaxDamage());
    
    if (playerY >= shootingAtY & (!shotgunBullet)) {   //the player is shooting upwards or horizontally
    
    
      
      
      if(playerX <= shootingAtX & ((players[0].activeTommy.ammo >= 1)||superPowerBullet)) { //the player is shooting to the right and up
       //  println("the player is shooting to the right and up");
         
         //calculating lengths of sides of the right angle triangle
         b = shootingAtX - playerX; 
         a = playerY - shootingAtY; 
         
         //calculating the size of the hypotenuse
         hypotenuse = sqrt( (b*b) + (a*a) );
         
         //calculating the angle of the bullet
         theta = asin(  (a/hypotenuse) );
         
         //println("Theta: " + theta); 
         
         //These next lines essentially calculate the appropriate X and Y components
         //of the bullet, in order to generate the appropriate X and Y speeds,
         //to feel as though one has the ability to shoot at any angle desired
         
         ratio = theta / 1.570796326f;  //pi/2 
         
       //  println("Ratio: " + ratio); 
         ratio = ratio*100;
         
         yPercentage = ratio; 
         xPercentage = 100 - yPercentage; 
         
         ySpeed = yPercentage/10; 
         xSpeed = xPercentage/10;
         
         //get negative Y speed for this case
         ySpeed = ySpeed - ySpeed*2; 
         
       //  System.out.println("X speed of bullet: " + xSpeed); 
       //  System.out.println("Y speed of bullet: " + ySpeed); 
         
         
         if(!superPowerBullet) { players[0].activeTommy.useAmmo(1); }
         
        // bullets[bulletsInAction].setSpeedX(xSpeed); 
        // bullets[bulletsInAction].setSpeedY(ySpeed);
        // bullets[bulletsInAction].setLocX(playerX*20); 
        // bullets[bulletsInAction].setLocY(playerY*20);
        // bullets[bulletsInAction].status = true;
         
        // bullets[bulletsInAction].setDamage(weaponUsed.getMaxDamage());
        // bullets[bulletsInAction].setShotFrom(weaponUsed.getName());
        // bulletsInAction++;
         
         
         Bullet tempBullet = new Bullet(xSpeed*3, ySpeed*3, playerX*20, playerY*20, true, weaponUsed.getMaxDamage(), weaponUsed.getName());
         
         playerBullets.add(tempBullet); 
         
         if(players[0].activeTommy.ammo <= 0) {
      
           this.tommyGunSickness = true; 
      
         }
    
         
         
      
      } else if (playerX > shootingAtX & ((players[0].activeTommy.ammo >= 1)||superPowerBullet)) { //the player is shooting to the left and up
       //  println("the player is shooting to the left and up");
         
         
         b = playerX - shootingAtX; 
         a = playerY - shootingAtY; 
         
         hypotenuse = sqrt( (b*b) + (a*a) );
         
         theta = asin(  (a/hypotenuse) );
         
        // println("Theta: " + theta);
         
         
         //These next lines essentially calculate the appropriate X and Y components
         //of the bullet, in order to generate the appropriate X and Y speeds,
         //to feel as though one has the ability to shoot at any angle desired
         
         ratio = theta / 1.570796326f;  //pi/2 
         
        // println("Ratio: " + ratio); 
         ratio = ratio*100;
         
         yPercentage = ratio; 
         xPercentage = 100 - yPercentage; 
         
         ySpeed = yPercentage/10; 
         xSpeed = xPercentage/10;
         
         //get negative Y speed for this case
         ySpeed = ySpeed - ySpeed*2;
         
         //get negative X speed for this case
         xSpeed = xSpeed - xSpeed*2; 
         
        // System.out.println("X speed of bullet: " + xSpeed); 
       //  System.out.println("Y speed of bullet: " + ySpeed); 
         
        if(!superPowerBullet) { players[0].activeTommy.useAmmo(1); }
         
        // bullets[bulletsInAction].setSpeedX(xSpeed); 
        // bullets[bulletsInAction].setSpeedY(ySpeed);
        // bullets[bulletsInAction].setLocX(playerX*20); 
       //  bullets[bulletsInAction].setLocY(playerY*20);
         
        // bullets[bulletsInAction].setDamage(weaponUsed.getMaxDamage());
        // bullets[bulletsInAction].setShotFrom(weaponUsed.getName());
         
        // bulletsInAction++;
         
         
         Bullet tempBullet = new Bullet(xSpeed*3, ySpeed*3, playerX*20, playerY*20, true, weaponUsed.getMaxDamage(), weaponUsed.getName());
         
         playerBullets.add(tempBullet); 
         
         
         if(players[0].activeTommy.ammo <= 0) {
      
           this.tommyGunSickness = true; 
      
         }
         
      
      }
      
    } else if (playerY < shootingAtY & (!shotgunBullet) & ((players[0].activeTommy.ammo >= 1)||superPowerBullet)) { //the player is shooting down
   
        if(playerX <= shootingAtX) { //the player is shooting to the right and down
          // println("the player is shooting to the right and down");
           
           a = shootingAtY - playerY; 
           b = shootingAtX - playerX;
           
           hypotenuse = sqrt( (b*b) + (a*a) );
         
           theta = asin(  (a/hypotenuse) );
         
          // println("Theta: " + theta);
           
           
           //These next lines essentially calculate the appropriate X and Y components
           //of the bullet, in order to generate the appropriate X and Y speeds,
           //to feel as though one has the ability to shoot at any angle desired
         
           ratio = theta / 1.570796326f;  //pi/2 
         
        //   println("Ratio: " + ratio); 
           ratio = ratio*100;
         
           yPercentage = ratio; 
           xPercentage = 100 - yPercentage; 
         
           ySpeed = yPercentage/10; 
           xSpeed = xPercentage/10;
         
         //  System.out.println("X speed of bullet: " + xSpeed); 
         //  System.out.println("Y speed of bullet: " + ySpeed); 
           
        if(!superPowerBullet) { players[0].activeTommy.useAmmo(1); }
           
        //   bullets[bulletsInAction].setSpeedX(xSpeed); 
         //  bullets[bulletsInAction].setSpeedY(ySpeed);
         //  bullets[bulletsInAction].setLocX(playerX*20); 
         //  bullets[bulletsInAction].setLocY(playerY*20);
           
         //  bullets[bulletsInAction].setDamage(weaponUsed.getMaxDamage());
         //  bullets[bulletsInAction].setShotFrom(weaponUsed.getName());
        // 
        //   bulletsInAction++;
        
       Bullet tempBullet = new Bullet(xSpeed*3, ySpeed*3, playerX*20, playerY*20, true, weaponUsed.getMaxDamage(), weaponUsed.getName());
         
         playerBullets.add(tempBullet); 
         
           
           if(players[0].activeTommy.ammo <= 0) {
      
           this.tommyGunSickness = true; 
      
         }
           
      
        } else if (playerX > shootingAtX & ((players[0].activeTommy.ammo >= 1)||superPowerBullet)) { //the player is shooting to the left and down
          // println("the player is shooting to the left and down");
           
           
           b = playerX - shootingAtX; 
           a = shootingAtY - playerY;
           
           hypotenuse = sqrt( (b*b) + (a*a) );
         
           theta = asin(  (a/hypotenuse) );
         
         //  println("Theta: " + theta);        
           
           //These next lines essentially calculate the appropriate X and Y components
           //of the bullet, in order to generate the appropriate X and Y speeds,
           //to feel as though one has the ability to shoot at any angle desired
         
           ratio = theta / 1.570796326f;  //pi/2 
         
          // println("Ratio: " + ratio); 
           ratio = ratio*100;
         
           yPercentage = ratio; 
           xPercentage = 100 - yPercentage; 
         
           ySpeed = yPercentage/10; 
           xSpeed = xPercentage/10;
         
           //negative X speed for this case
           xSpeed = xSpeed - xSpeed*2; 
         
          // System.out.println("X speed of bullet: " + xSpeed); 
          // System.out.println("Y speed of bullet: " + ySpeed); 
           
          if(!superPowerBullet) { players[0].activeTommy.useAmmo(1); }
           
         //  bullets[bulletsInAction].setSpeedX(xSpeed); 
          // bullets[bulletsInAction].setSpeedY(ySpeed);
         //  bullets[bulletsInAction].setLocX(playerX*20); 
         //  bullets[bulletsInAction].setLocY(playerY*20);
           
         //  bullets[bulletsInAction].setDamage(weaponUsed.getMaxDamage());
        //   bullets[bulletsInAction].setShotFrom(weaponUsed.getName());
        // 
         //  bulletsInAction++;
         
         Bullet tempBullet = new Bullet(xSpeed*3, ySpeed*3, playerX*20, playerY*20, true, weaponUsed.getMaxDamage(), weaponUsed.getName());
         
         playerBullets.add(tempBullet); 
         
           
           if(players[0].activeTommy.ammo <= 0) {
      
           this.tommyGunSickness = true; 
      
         }
           
        }
        
        checkTommySickness();
        
    }
       
    //the incoming coordinates are a shotgun bullet
    if (shotgunBullet & players[0].activeShotgun.ammo >= 1) {
      
      if (playerY >= shootingAtY) {   //the player is shooting upwards or horizontally
      
      
      if(playerX <= shootingAtX) { //the player is shooting to the right and up
       //  println("the player is shooting to the right and up");
         
         players[0].activeShotgun.useAmmo(1);
         
         
         //calculating lengths of sides of the right angle triangle
         b = shootingAtX - playerX; 
         a = playerY - shootingAtY; 
         
         //calculating the size of the hypotenuse
         hypotenuse = sqrt( (b*b) + (a*a) );
         
         //calculating the angle of the bullet
         theta = asin(  (a/hypotenuse) );
         
        // System.out.println("Theta: " + theta); 
         
         //These next lines essentially calculate the appropriate X and Y components
         //of the bullet, in order to generate the appropriate X and Y speeds,
         //to feel as though one has the ability to shoot at any angle desired
         
         ratio = theta / 1.570796326f;  //pi/2 
         
       //  println("Ratio: " + ratio); 
         ratio = ratio*100;
         
         yPercentage = ratio; 
         xPercentage = 100 - yPercentage; 
         
         ySpeed = yPercentage/10; 
         xSpeed = xPercentage/10;
         
         //get negative Y speed for this case
         ySpeed = ySpeed - ySpeed*2; 
         
        // System.out.println("X speed of bullet: " + xSpeed); 
       //  System.out.println("Y speed of bullet: " + ySpeed); 
         
         if ( (theta < 0.39f) ) {
           
          // bullets[bulletsInAction].setSpeedX(xSpeed); 
        // bullets[bulletsInAction].setSpeedY(ySpeed);
        // bullets[bulletsInAction].setLocX(playerX*20); 
        // bullets[bulletsInAction].setLocY(playerY*20);
        // bullets[bulletsInAction].status = true;
         
        // bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());
       //  bullets[bulletsInAction].setShotFrom("Shotgun");
        // bulletsInAction++;
         
         
         Bullet tempBullet = new Bullet(xSpeed*2, ySpeed*2, playerX*20, playerY*20, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet); 
         
         
        // bullets[bulletsInAction].setSpeedX(xSpeed); 
        // bullets[bulletsInAction].setSpeedY(ySpeed);
       //  bullets[bulletsInAction].setLocX(playerX*20); 
       //  bullets[bulletsInAction].setLocY(playerY*20+10);
       //  bullets[bulletsInAction].status = true;
         
        // bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
        // bullets[bulletsInAction].setShotFrom("Shotgun");
        // bulletsInAction++;
         
          Bullet tempBullet2 = new Bullet(xSpeed*2, ySpeed*2, playerX*20, playerY*20+10, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet2); 
         
       //  bullets[bulletsInAction].setSpeedX(xSpeed); 
      //   bullets[bulletsInAction].setSpeedY(ySpeed);
       //  bullets[bulletsInAction].setLocX(playerX*20); 
       //  bullets[bulletsInAction].setLocY(playerY*20+20);
       //  bullets[bulletsInAction].status = true;
         
       //  bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
       //  bullets[bulletsInAction].setShotFrom("Shotgun");
       //  bulletsInAction++;
         
          
          Bullet tempBullet3 = new Bullet(xSpeed*2, ySpeed*2, playerX*20, playerY*20+20, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet3); 
         
         
      //   bullets[bulletsInAction].setSpeedX(xSpeed); 
     //    bullets[bulletsInAction].setSpeedY(ySpeed);
      //   bullets[bulletsInAction].setLocX(playerX*20); 
       //  bullets[bulletsInAction].setLocY(playerY*20-10);
       //  bullets[bulletsInAction].status = true;
         
       //  bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
       //  bullets[bulletsInAction].setShotFrom("Shotgun");
       //  bulletsInAction++;
         
         
          Bullet tempBullet4 = new Bullet(xSpeed*2, ySpeed*2, playerX*20, playerY*20-10, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet4); 
         
         
        // bullets[bulletsInAction].setSpeedX(xSpeed); 
       //  bullets[bulletsInAction].setSpeedY(ySpeed);
       //  bullets[bulletsInAction].setLocX(playerX*20); 
       //  bullets[bulletsInAction].setLocY(playerY*20-20);
       //  bullets[bulletsInAction].status = true;
         
       //  bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
       //  bullets[bulletsInAction].setShotFrom("Shotgun");
       //  bulletsInAction++;
         
         
          Bullet tempBullet5 = new Bullet(xSpeed*2, ySpeed*2, playerX*20, playerY*20-20, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet5); 
         
         
         //extra
          Bullet tempBullet6 = new Bullet(xSpeed*2, ySpeed*2, playerX*20-10, playerY*20-10, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet6); 
         
         Bullet tempBullet7 = new Bullet(xSpeed*2, ySpeed*2, playerX*20-10, playerY*20+10, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet7); 
         
         Bullet tempBullet8 = new Bullet(xSpeed*2, ySpeed*2, playerX*20-10, playerY*20, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet8); 
         
           
         shotGunSickness = true;
           
         
         } else { 
           
         //  bullets[bulletsInAction].setSpeedX(xSpeed); 
        // bullets[bulletsInAction].setSpeedY(ySpeed);
        // bullets[bulletsInAction].setLocX(playerX*20); 
        // bullets[bulletsInAction].setLocY(playerY*20);
       //  bullets[bulletsInAction].status = true;
         
       //  bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
        // bullets[bulletsInAction].setShotFrom("Shotgun");
         //bulletsInAction++;
         
         
          Bullet tempBullet = new Bullet(xSpeed*2, ySpeed*2, playerX*20, playerY*20, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet); 
         
         
        // bullets[bulletsInAction].setSpeedX(xSpeed); 
        // bullets[bulletsInAction].setSpeedY(ySpeed);
        // bullets[bulletsInAction].setLocX(playerX*20+10); 
        // bullets[bulletsInAction].setLocY(playerY*20);
        // bullets[bulletsInAction].status = true;
         
       //  bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
       //  bullets[bulletsInAction].setShotFrom("Shotgun");
       //  bulletsInAction++;
         
         
          Bullet tempBullet2 = new Bullet(xSpeed*2, ySpeed*2, playerX*20, playerY*20+10, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet2); 
         
         
         
        // bullets[bulletsInAction].setSpeedX(xSpeed); 
       //  bullets[bulletsInAction].setSpeedY(ySpeed);
       //  bullets[bulletsInAction].setLocX(playerX*20+20); 
       //  bullets[bulletsInAction].setLocY(playerY*20);
       //  bullets[bulletsInAction].status = true;
         
       //  bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
       //  bullets[bulletsInAction].setShotFrom("Shotgun");
       //  bulletsInAction++;
         
         
         
          Bullet tempBullet3 = new Bullet(xSpeed*2, ySpeed*2, playerX*20, playerY*20+20, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet3); 
         
         
       //  bullets[bulletsInAction].setSpeedX(xSpeed); 
       //  bullets[bulletsInAction].setSpeedY(ySpeed);
       //  bullets[bulletsInAction].setLocX(playerX*20-10); 
       //  bullets[bulletsInAction].setLocY(playerY*20);
       //  bullets[bulletsInAction].status = true;
         
      //   bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
      //   bullets[bulletsInAction].setShotFrom("Shotgun");
      //   bulletsInAction++;
         
         
          Bullet tempBullet4 = new Bullet(xSpeed*2, ySpeed*2, playerX*20, playerY*20-10, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet4); 
         
         
       //  bullets[bulletsInAction].setSpeedX(xSpeed); 
       //  bullets[bulletsInAction].setSpeedY(ySpeed);
       //  bullets[bulletsInAction].setLocX(playerX*20-20); 
       //  bullets[bulletsInAction].setLocY(playerY*20);
       //  bullets[bulletsInAction].status = true;
         
       //  bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
      //   bullets[bulletsInAction].setShotFrom("Shotgun");
       //  bulletsInAction++;
         
         
            Bullet tempBullet5 = new Bullet(xSpeed*2, ySpeed*2, playerX*20, playerY*20-20, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet5); 
         
         
         
         //extra
          Bullet tempBullet6 = new Bullet(xSpeed*2, ySpeed*2, playerX*20-10, playerY*20-10, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet6); 
         
         Bullet tempBullet7 = new Bullet(xSpeed*2, ySpeed*2, playerX*20-10, playerY*20+10, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet7); 
         
         Bullet tempBullet8 = new Bullet(xSpeed*2, ySpeed*2, playerX*20-10, playerY*20, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet8); 
         
         
         shotGunSickness = true;
           
           
         }
         
           
             
      } else if (playerX > shootingAtX) { //the player is shooting to the left and up
        // println("the player is shooting to the left and up");
         
          players[0].activeShotgun.useAmmo(1);
         
         b = playerX - shootingAtX; 
         a = playerY - shootingAtY; 
         
         hypotenuse = sqrt( (b*b) + (a*a) );
         
         theta = asin(  (a/hypotenuse) );
         
        // System.out.println("Theta: " + theta);
         
         
         //These next lines essentially calculate the appropriate X and Y components
         //of the bullet, in order to generate the appropriate X and Y speeds,
         //to feel as though one has the ability to shoot at any angle desired
         
         ratio = theta / 1.570796326f;  //pi/2 
         
      //   println("Ratio: " + ratio); 
         ratio = ratio*100;
         
         yPercentage = ratio; 
         xPercentage = 100 - yPercentage; 
         
         ySpeed = yPercentage/10; 
         xSpeed = xPercentage/10;
         
         //get negative Y speed for this case
         ySpeed = ySpeed - ySpeed*2;
         
         //get negative X speed for this case
         xSpeed = xSpeed - xSpeed*2; 
         
        // System.out.println("X speed of bullet: " + xSpeed); 
         //System.out.println("Y speed of bullet: " + ySpeed); 
         
         
         if( (theta < 0.38f) ) {
           
       //    bullets[bulletsInAction].setSpeedX(xSpeed); 
       //  bullets[bulletsInAction].setSpeedY(ySpeed);
       //  bullets[bulletsInAction].setLocX(playerX*20); 
       //  bullets[bulletsInAction].setLocY(playerY*20);
       //  bullets[bulletsInAction].status = true;
         
        // bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
        // bullets[bulletsInAction].setShotFrom("Shotgun");
        // bulletsInAction++;
         
          Bullet tempBullet = new Bullet(xSpeed*2, ySpeed*2, playerX*20, playerY*20, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet); 
         
       //  bullets[bulletsInAction].setSpeedX(xSpeed); 
       //  bullets[bulletsInAction].setSpeedY(ySpeed);
       //  bullets[bulletsInAction].setLocX(playerX*20); 
       //  bullets[bulletsInAction].setLocY(playerY*20+10);
      //  bullets[bulletsInAction].status = true;
         
       //  bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
       //  bullets[bulletsInAction].setShotFrom("Shotgun");
        // bulletsInAction++;
         
         
          Bullet tempBullet2 = new Bullet(xSpeed*2, ySpeed*2, playerX*20, playerY*20+10, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet2); 
         
         
        // bullets[bulletsInAction].setSpeedX(xSpeed); 
        // bullets[bulletsInAction].setSpeedY(ySpeed);
       //  bullets[bulletsInAction].setLocX(playerX*20); 
       //  bullets[bulletsInAction].setLocY(playerY*20+20);
       //  bullets[bulletsInAction].status = true;
         
        // bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
        // bullets[bulletsInAction].setShotFrom("Shotgun");
        // bulletsInAction++;
         
         
         Bullet tempBullet3 = new Bullet(xSpeed*2, ySpeed*2, playerX*20, playerY*20+20, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet3); 
         
         
        // bullets[bulletsInAction].setSpeedX(xSpeed); 
        // bullets[bulletsInAction].setSpeedY(ySpeed);
        // bullets[bulletsInAction].setLocX(playerX*20); 
        // bullets[bulletsInAction].setLocY(playerY*20-10);
        // bullets[bulletsInAction].status = true;
         
        // bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
        // bullets[bulletsInAction].setShotFrom("Shotgun");
        // bulletsInAction++;
         
         
          Bullet tempBullet4 = new Bullet(xSpeed*2, ySpeed*2, playerX*20, playerY*20-10, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet4); 
         
         
       //  bullets[bulletsInAction].setSpeedX(xSpeed); 
       //  bullets[bulletsInAction].setSpeedY(ySpeed);
       //  bullets[bulletsInAction].setLocX(playerX*20); 
       //  bullets[bulletsInAction].setLocY(playerY*20-20);
       //  bullets[bulletsInAction].status = true;
         
       //  bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
       //  bullets[bulletsInAction].setShotFrom("Shotgun");
       //  bulletsInAction++;
         
         
          Bullet tempBullet5 = new Bullet(xSpeed*2, ySpeed*2, playerX*20, playerY*20-20, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet5); 
           
         shotGunSickness = true;
        
         
         } else {
           
          //  bullets[bulletsInAction].setSpeedX(xSpeed); 
        // bullets[bulletsInAction].setSpeedY(ySpeed);
        // bullets[bulletsInAction].setLocX(playerX*20); 
       //  bullets[bulletsInAction].setLocY(playerY*20);
       //  bullets[bulletsInAction].status = true;
         
       //  bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
       //  bullets[bulletsInAction].setShotFrom("Shotgun");
       //  bulletsInAction++;
         
         
           Bullet tempBullet = new Bullet(xSpeed*2, ySpeed*2, playerX*20, playerY*20, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet); 
         
         
        // bullets[bulletsInAction].setSpeedX(xSpeed); 
       //  bullets[bulletsInAction].setSpeedY(ySpeed);
       //  bullets[bulletsInAction].setLocX(playerX*20+10); 
       //  bullets[bulletsInAction].setLocY(playerY*20);
        // bullets[bulletsInAction].status = true;
         
       //  bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
       //  bullets[bulletsInAction].setShotFrom("Shotgun");
        // bulletsInAction++;
         
         
         Bullet tempBullet2 = new Bullet(xSpeed*2, ySpeed*2, playerX*20+10, playerY*20, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet2); 
         
         
      //   bullets[bulletsInAction].setSpeedX(xSpeed); 
        // bullets[bulletsInAction].setSpeedY(ySpeed);
        // bullets[bulletsInAction].setLocX(playerX*20+20); 
        // bullets[bulletsInAction].setLocY(playerY*20);
       //  bullets[bulletsInAction].status = true;
         
       //  bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
       //  bullets[bulletsInAction].setShotFrom("Shotgun");
       //  bulletsInAction++;
         
            Bullet tempBullet3 = new Bullet(xSpeed*2, ySpeed*2, playerX*20+20, playerY*20, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet3); 
         
        
        // bullets[bulletsInAction].setSpeedX(xSpeed); 
        // bullets[bulletsInAction].setSpeedY(ySpeed);
       //  bullets[bulletsInAction].setLocX(playerX*20-10); 
       //  bullets[bulletsInAction].setLocY(playerY*20);
        // bullets[bulletsInAction].status = true;
         
        // bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
       //  bullets[bulletsInAction].setShotFrom("Shotgun");
       //  bulletsInAction++;
         
         
            Bullet tempBullet4 = new Bullet(xSpeed*2, ySpeed*2, playerX*20-10, playerY*20, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet4); 
         
         
       //  bullets[bulletsInAction].setSpeedX(xSpeed); 
        // bullets[bulletsInAction].setSpeedY(ySpeed);
        // bullets[bulletsInAction].setLocX(playerX*20-20); 
       //  bullets[bulletsInAction].setLocY(playerY*20);
       //  bullets[bulletsInAction].status = true;
         
       //  bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
       //  bullets[bulletsInAction].setShotFrom("Shotgun");
       //  bulletsInAction++;
       
       Bullet tempBullet5 = new Bullet(xSpeed*2, ySpeed*2, playerX*20-20, playerY*20, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet5); 
         
         shotGunSickness = true;
         
         
         
           
         }
        
      
      }
      
    } else if (playerY < shootingAtY) { //the player is shooting down
   
        if(playerX <= shootingAtX) { //the player is shooting to the right and down
         //  println("the player is shooting to the right and down");
           
            players[0].activeShotgun.useAmmo(1);
           
           a = shootingAtY - playerY; 
           b = shootingAtX - playerX;
           
           hypotenuse = sqrt( (b*b) + (a*a) );
         
           theta = asin(  (a/hypotenuse) );
         
          // System.out.println("Theta: " + theta);
           
           
           //These next lines essentially calculate the appropriate X and Y components
           //of the bullet, in order to generate the appropriate X and Y speeds,
           //to feel as though one has the ability to shoot at any angle desired
         
           ratio = theta / 1.570796326f;  //pi/2 
         
        //   println("Ratio: " + ratio); 
           ratio = ratio*100;
         
           yPercentage = ratio; 
           xPercentage = 100 - yPercentage; 
         
           ySpeed = yPercentage/10; 
           xSpeed = xPercentage/10;
         
          // System.out.println("X speed of bullet: " + xSpeed); 
          // System.out.println("Y speed of bullet: " + ySpeed); 
           
           if ( (theta < 0.39f) ) {
             
             //bullets[bulletsInAction].setSpeedX(xSpeed); 
        // bullets[bulletsInAction].setSpeedY(ySpeed);
        // bullets[bulletsInAction].setLocX(playerX*20); 
        // bullets[bulletsInAction].setLocY(playerY*20);
        // bullets[bulletsInAction].status = true;
         
       //  bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
       //  bullets[bulletsInAction].setShotFrom("Shotgun");
       //  bulletsInAction++;
         
         
         Bullet tempBullet = new Bullet(xSpeed*2, ySpeed*2, playerX*20, playerY*20, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet); 
         
        // bullets[bulletsInAction].setSpeedX(xSpeed); 
        // bullets[bulletsInAction].setSpeedY(ySpeed);
        // bullets[bulletsInAction].setLocX(playerX*20); 
        // bullets[bulletsInAction].setLocY(playerY*20+10);
        // bullets[bulletsInAction].status = true;
         
       //  bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
       //  bullets[bulletsInAction].setShotFrom("Shotgun");
       //  bulletsInAction++;
         
         
          Bullet tempBullet2 = new Bullet(xSpeed*2, ySpeed*2, playerX*20, playerY*20+10, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet2); 
         
        // bullets[bulletsInAction].setSpeedX(xSpeed); 
        // bullets[bulletsInAction].setSpeedY(ySpeed);
        // bullets[bulletsInAction].setLocX(playerX*20); 
       //  bullets[bulletsInAction].setLocY(playerY*20+20);
       //  bullets[bulletsInAction].status = true;
         
       //  bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
        // bullets[bulletsInAction].setShotFrom("Shotgun");
        // bulletsInAction++;
         
         
           Bullet tempBullet3 = new Bullet(xSpeed*2, ySpeed*2, playerX*20, playerY*20+20, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet3); 
         
         
       //  bullets[bulletsInAction].setSpeedX(xSpeed); 
       //  bullets[bulletsInAction].setSpeedY(ySpeed);
        // bullets[bulletsInAction].setLocX(playerX*20); 
       //  bullets[bulletsInAction].setLocY(playerY*20-10);
       //  bullets[bulletsInAction].status = true;
         
       //  bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
       //  bullets[bulletsInAction].setShotFrom("Shotgun");
       //  bulletsInAction++;
         
          Bullet tempBullet4 = new Bullet(xSpeed*2, ySpeed*2, playerX*20, playerY*20-10, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet4); 
         
         
         
        // bullets[bulletsInAction].setSpeedX(xSpeed); 
       //  bullets[bulletsInAction].setSpeedY(ySpeed);
        // bullets[bulletsInAction].setLocX(playerX*20); 
        // bullets[bulletsInAction].setLocY(playerY*20-20);
       //  bullets[bulletsInAction].status = true;
         
       //  bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
       //  bullets[bulletsInAction].setShotFrom("Shotgun");
        // bulletsInAction++;
         
         
          Bullet tempBullet5 = new Bullet(xSpeed*2, ySpeed*2, playerX*20, playerY*20-20, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet5); 
         
           
           shotGunSickness = true;
           
          
           } else {
             
             // bullets[bulletsInAction].setSpeedX(xSpeed); 
        // bullets[bulletsInAction].setSpeedY(ySpeed);
       //  bullets[bulletsInAction].setLocX(playerX*20); 
       //  bullets[bulletsInAction].setLocY(playerY*20);
       //  bullets[bulletsInAction].status = true;
         
       //  bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
       //  bullets[bulletsInAction].setShotFrom("Shotgun");
       //  bulletsInAction++;
         
           Bullet tempBullet = new Bullet(xSpeed*2, ySpeed*2, playerX*20, playerY*20, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet); 
         
         
        // bullets[bulletsInAction].setSpeedX(xSpeed); 
        // bullets[bulletsInAction].setSpeedY(ySpeed);
        // bullets[bulletsInAction].setLocX(playerX*20+10); 
        // bullets[bulletsInAction].setLocY(playerY*20);
       //  bullets[bulletsInAction].status = true;
         
       //  bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
       //  bullets[bulletsInAction].setShotFrom("Shotgun");
       //  bulletsInAction++;
         
         
          Bullet tempBullet2 = new Bullet(xSpeed*2, ySpeed*2, playerX*20+10, playerY*20, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet2); 
         
         
       //  bullets[bulletsInAction].setSpeedX(xSpeed); 
       //  bullets[bulletsInAction].setSpeedY(ySpeed);
       //  bullets[bulletsInAction].setLocX(playerX*20+20); 
        // bullets[bulletsInAction].setLocY(playerY*20);
        // bullets[bulletsInAction].status = true;
         
       //  bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
       //  bullets[bulletsInAction].setShotFrom("Shotgun");
       //  bulletsInAction++;
         
         
          Bullet tempBullet3 = new Bullet(xSpeed*2, ySpeed*2, playerX*20+20, playerY*20, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet3); 
      
         
       //  bullets[bulletsInAction].setSpeedX(xSpeed); 
       //  bullets[bulletsInAction].setSpeedY(ySpeed);
        // bullets[bulletsInAction].setLocX(playerX*20-10); 
        // bullets[bulletsInAction].setLocY(playerY*20);
        // bullets[bulletsInAction].status = true;
         
       //  bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
       //  bullets[bulletsInAction].setShotFrom("Shotgun");
       //  bulletsInAction++;
         
         
         Bullet tempBullet4 = new Bullet(xSpeed*2, ySpeed*2, playerX*20-10, playerY*20, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet4); 
         
       //  bullets[bulletsInAction].setSpeedX(xSpeed); 
        // bullets[bulletsInAction].setSpeedY(ySpeed);
        // bullets[bulletsInAction].setLocX(playerX*20-20); 
       //  bullets[bulletsInAction].setLocY(playerY*20);
       //  bullets[bulletsInAction].status = true;
         
       //  bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
       //  bullets[bulletsInAction].setShotFrom("Shotgun");
      //   bulletsInAction++;
         
         
         Bullet tempBullet5 = new Bullet(xSpeed*2, ySpeed*2, playerX*20-20, playerY*20, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet5); 
         
         shotGunSickness = true;
         
             
           }
         
    
      
        } else if (playerX > shootingAtX) { //the player is shooting to the left and down
          // println("the player is shooting to the left and down");
           
           
            players[0].activeShotgun.useAmmo(1);
           
           
           b = playerX - shootingAtX; 
           a = shootingAtY - playerY;
           
           hypotenuse = sqrt( (b*b) + (a*a) );
         
           theta = asin(  (a/hypotenuse) );
         
         //  System.out.println("Theta: " + theta);        
           
           //These next lines essentially calculate the appropriate X and Y components
           //of the bullet, in order to generate the appropriate X and Y speeds,
           //to feel as though one has the ability to shoot at any angle desired
         
           ratio = theta / 1.570796326f;  //pi/2 
         
        //   println("Ratio: " + ratio); 
           ratio = ratio*100;
         
           yPercentage = ratio; 
           xPercentage = 100 - yPercentage; 
         
           ySpeed = yPercentage/10; 
           xSpeed = xPercentage/10;
         
           //negative X speed for this case
           xSpeed = xSpeed - xSpeed*2; 
         
          // System.out.println("X speed of bullet: " + xSpeed); 
          // System.out.println("Y speed of bullet: " + ySpeed); 
           
           if( (theta < 0.38f) ) {
             
            // bullets[bulletsInAction].setSpeedX(xSpeed); 
       //  bullets[bulletsInAction].setSpeedY(ySpeed);
       //  bullets[bulletsInAction].setLocX(playerX*20); 
       //  bullets[bulletsInAction].setLocY(playerY*20);
       //  bullets[bulletsInAction].status = true;
         
        // bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
       //  bullets[bulletsInAction].setShotFrom("Shotgun");
       //  bulletsInAction++;
         
         
          Bullet tempBullet = new Bullet(xSpeed*2, ySpeed*2, playerX*20, playerY*20, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet); 
         
         
        // bullets[bulletsInAction].setSpeedX(xSpeed); 
        // bullets[bulletsInAction].setSpeedY(ySpeed);
        // bullets[bulletsInAction].setLocX(playerX*20); 
        // bullets[bulletsInAction].setLocY(playerY*20+10);
       //  bullets[bulletsInAction].status = true;
         
       //  bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
      //   bullets[bulletsInAction].setShotFrom("Shotgun");
       //  bulletsInAction++;
         
         
         Bullet tempBullet2 = new Bullet(xSpeed*2, ySpeed*2, playerX*20, playerY*20+10, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet2); 
         
       //  bullets[bulletsInAction].setSpeedX(xSpeed); 
      //   bullets[bulletsInAction].setSpeedY(ySpeed);
       //  bullets[bulletsInAction].setLocX(playerX*20); 
        // bullets[bulletsInAction].setLocY(playerY*20+20);
       //  bullets[bulletsInAction].status = true;
         
      //   bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
      //   bullets[bulletsInAction].setShotFrom("Shotgun");
      //  bulletsInAction++;
         
         
         Bullet tempBullet3 = new Bullet(xSpeed*2, ySpeed*2, playerX*20, playerY*20+20, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet3); 
         
         
         
        // bullets[bulletsInAction].setSpeedX(xSpeed); 
       //  bullets[bulletsInAction].setSpeedY(ySpeed);
        // bullets[bulletsInAction].setLocX(playerX*20); 
       //  bullets[bulletsInAction].setLocY(playerY*20-10);
       //  bullets[bulletsInAction].status = true;
         
       //  bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
       //  bullets[bulletsInAction].setShotFrom("Shotgun");
       //  bulletsInAction++;
         
          Bullet tempBullet4 = new Bullet(xSpeed*2, ySpeed*2, playerX*20, playerY*20-10, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet4); 
         
         
        // bullets[bulletsInAction].setSpeedX(xSpeed); 
       //  bullets[bulletsInAction].setSpeedY(ySpeed);
       //  bullets[bulletsInAction].setLocX(playerX*20); 
        // bullets[bulletsInAction].setLocY(playerY*20-20);
       //  bullets[bulletsInAction].status = true;
         
       //  bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
       //  bullets[bulletsInAction].setShotFrom("Shotgun");
      //   bulletsInAction++;
         
         
          Bullet tempBullet5 = new Bullet(xSpeed*2, ySpeed*2, playerX*20, playerY*20-20, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet5); 
         
         
         shotGunSickness = true;
           
           
         
           } else {
             
             // bullets[bulletsInAction].setSpeedX(xSpeed); 
       //  bullets[bulletsInAction].setSpeedY(ySpeed);
       //  bullets[bulletsInAction].setLocX(playerX*20); 
      //   bullets[bulletsInAction].setLocY(playerY*20);
      //   bullets[bulletsInAction].status = true;
         
       //  bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
      //   bullets[bulletsInAction].setShotFrom("Shotgun");
      //   bulletsInAction++;
         
         Bullet tempBullet = new Bullet(xSpeed*2, ySpeed*2, playerX*20, playerY*20, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet); 
         
         
         
       //  bullets[bulletsInAction].setSpeedX(xSpeed); 
       //  bullets[bulletsInAction].setSpeedY(ySpeed);
       //  bullets[bulletsInAction].setLocX(playerX*20+10); 
       //  bullets[bulletsInAction].setLocY(playerY*20);
       //  bullets[bulletsInAction].status = true;
         
       //  bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
       //  bullets[bulletsInAction].setShotFrom("Shotgun");
       //  bulletsInAction++;
         
         
          Bullet tempBullet2 = new Bullet(xSpeed*2, ySpeed*2, playerX*20+10, playerY*20, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet2); 
         
       //  bullets[bulletsInAction].setSpeedX(xSpeed); 
       //  bullets[bulletsInAction].setSpeedY(ySpeed);
       //  bullets[bulletsInAction].setLocX(playerX*20+20); 
       //  bullets[bulletsInAction].setLocY(playerY*20);
       //  bullets[bulletsInAction].status = true;
         
       //  bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
       //  bullets[bulletsInAction].setShotFrom("Shotgun");
       //  bulletsInAction++;
         
         
         Bullet tempBullet3 = new Bullet(xSpeed*2, ySpeed*2, playerX*20+20, playerY*20, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet3); 
         
  
      //   bullets[bulletsInAction].setSpeedX(xSpeed); 
      //   bullets[bulletsInAction].setSpeedY(ySpeed);
      //   bullets[bulletsInAction].setLocX(playerX*20-10); 
      //   bullets[bulletsInAction].setLocY(playerY*20);
       ///  bullets[bulletsInAction].status = true;
         
       //  bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
      //   bullets[bulletsInAction].setShotFrom("Shotgun");
      //   bulletsInAction++;
         
         
          Bullet tempBullet4 = new Bullet(xSpeed*2, ySpeed*2, playerX*20-10, playerY*20, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet4); 
         
         
         
      //   bullets[bulletsInAction].setSpeedX(xSpeed); 
      //   bullets[bulletsInAction].setSpeedY(ySpeed);
      //   bullets[bulletsInAction].setLocX(playerX*20-20); 
      //   bullets[bulletsInAction].setLocY(playerY*20);
      //   bullets[bulletsInAction].status = true;
         
      //   bullets[bulletsInAction].setDamage(players[0].activeShotgun.getMaxDamage());;
      //   bullets[bulletsInAction].setShotFrom("Shotgun");
       //  bulletsInAction++;
         
         
         Bullet tempBullet5 = new Bullet(xSpeed*2, ySpeed*2, playerX*20-20, playerY*20, true, weaponUsed.getMaxDamage(), "Shotgun");
         
         playerBullets.add(tempBullet5); 
             
             shotGunSickness = true; 
             
             
           }
         
     
           
        }
        
    }
      
      
      
      
      
      
    }
    
  }
  
  public void checkTommySickness() {
    
    
  }
  
  public void grantShottyAmmo(int frame) {
    
    if(frame == 0) {
      
      players[0].activeShotgun.addAmmo(1);
      
    }
    
    
  }
  
  public void drawRobotBullets() {
    
    //for each flower bullet currently in service
    for(int i = 0; i < robotBullets.size(); i++) {
      
      if(robotBullets.get(i).getStatus()) {
      
 
        fill(0xffF01B1B);
        
        robotBullets.get(i).setXC(robotBullets.get(i).getXC() + robotBullets.get(i).getSpeedX()); 
        robotBullets.get(i).setYC(robotBullets.get(i).getYC() + robotBullets.get(i).getSpeedY());
        
        //rect(robotBullets.get(i).getXC()+10, robotBullets.get(i).getYC()+10, robotBullets.get(i).getSize()+5, robotBullets.get(i).getSize()+5);
        
        circle(robotBullets.get(i).getXC()+10, robotBullets.get(i).getYC()+10, 10);
      
      }
    }
    
    
    
  }
  
   public void drawCannonBullets() {
    
    //for each flower bullet currently in service
    for(int i = 0; i < cannonBullets.size(); i++) {
      
      if(cannonBullets.get(i).getStatus()) {
      
 
        fill(0xffF01B1B);
        
        cannonBullets.get(i).setXC(cannonBullets.get(i).getXC() + cannonBullets.get(i).getSpeedX()); 
        cannonBullets.get(i).setYC(cannonBullets.get(i).getYC() + cannonBullets.get(i).getSpeedY());
        
        
        
       // rect(flowerBullets.get(i).getXC()+10, flowerBullets.get(i).getYC()+10, flowerBullets.get(i).getSize()+5, flowerBullets.get(i).getSize()+5);
         image(imageList[49],cannonBullets.get(i).getXC(), cannonBullets.get(i).getYC());
      }
    }
    
    
    
  }
  
  
  public void drawFlowerBullets() {
    
    //for each flower bullet currently in service
    for(int i = 0; i < flowerBullets.size(); i++) {
      
      if(flowerBullets.get(i).getStatus()) {
      
 
        fill(0xffF01B1B);
        
        flowerBullets.get(i).setXC(flowerBullets.get(i).getXC() + flowerBullets.get(i).getSpeedX()); 
        flowerBullets.get(i).setYC(flowerBullets.get(i).getYC() + flowerBullets.get(i).getSpeedY());
        
        flowerBullets.get(i).show();
        
       // rect(flowerBullets.get(i).getXC()+10, flowerBullets.get(i).getYC()+10, flowerBullets.get(i).getSize()+5, flowerBullets.get(i).getSize()+5);
         //image(imageList[41],flowerBullets.get(i).getXC(), flowerBullets.get(i).getYC());
      }
    }
    
    
    
  }
  
  
  public void drawHiveBullets() {
    
     //for each hive bullet currently in service
    for(int i = 0; i < hiveBullets.size(); i++) {
      
      if(hiveBullets.get(i).getStatus()) {
      
 
        fill(0xffF01B1B);
        
        hiveBullets.get(i).setXC(hiveBullets.get(i).getXC() + hiveBullets.get(i).getSpeedX()); 
        hiveBullets.get(i).setYC(hiveBullets.get(i).getYC() + hiveBullets.get(i).getSpeedY());
        
        
        
       // rect(flowerBullets.get(i).getXC()+10, flowerBullets.get(i).getYC()+10, flowerBullets.get(i).getSize()+5, flowerBullets.get(i).getSize()+5);
         image(imageList[42], hiveBullets.get(i).getXC(), hiveBullets.get(i).getYC());
      }
    }
    
    
  }
  
  
  
  public void drawBullets() {
    
    for(int i = 0; i < playerBullets.size(); i++) {
      
        if(playerBullets.get(i).status) {
        fill(0xff002AF2);
        
      
        playerBullets.get(i).timesAnimated = playerBullets.get(i).timesAnimated + 1;
        
        if( (playerBullets.get(i).timesAnimated == 6) & (playerBullets.get(i).getShotFrom() == "Shotgun")) {
          
          playerBullets.get(i).status = false;
          //this.checkBulletRedundancy();
        }
      
        if(playerBullets.get(i).status) {
        playerBullets.get(i).xCoor += (playerBullets.get(i).speedX); 
        playerBullets.get(i).yCoor += (playerBullets.get(i).speedY);
        }
        //line(i*20+10,j*20+10,i*20,j*20);
      
        circle(playerBullets.get(i).xCoor,playerBullets.get(i).yCoor,bulletSize);
       // line(bullets[i].xCoor,bullets[i].yCoor,bullets[i].xCoor-5,bullets[i].yCoor+5);
      
      }
    }
    
  }
      
      
      
 
  //gives the player the appropriate weapon based on where they clicked on the GUI
  //check for correct balance and remove materials from player in this function
  //wood weapons not implemented yet (implement once durability feature of weapons is introduced)
  public void giveWeapon(String s) {
    
    if(s.equals("Iron Tommy")) {
      
      if(players[0].getIronAmount() >= weaponAvailable[1].getCost()) {
        
        println("Giving Iron Tommy"); 
        players[0].setTommy(weaponAvailable[1]); 
        players[0].addIron(-100); 
        
      }
      
    } else if (s.equals("Gold Tommy")) {
      
      if(players[0].getGoldAmount() >= weaponAvailable[2].getCost()) {
        
        println("Giving Gold Tommy"); 
        players[0].setTommy(weaponAvailable[2]); 
        players[0].addGold(-100); 
        
      }
      
    } else if (s.equals("Iron Shotgun")) {
      
      if(players[0].getIronAmount() >= weaponAvailable[4].getCost()) {
        
        println("Giving Iron Shotgun"); 
        players[0].setShotgun(weaponAvailable[4]); 
        players[0].getShotty().setMaxDamage(300);
        players[0].addIron(-100); 
        
      }
      
    } else if (s.equals("Gold Shotgun")) {
      
      
       if(players[0].getGoldAmount() >= weaponAvailable[5].getCost()) {
        
        println("Giving Gold Shotgun"); 
        players[0].setShotgun(weaponAvailable[5]); 
        players[0].addGold(-100); 
        
      }
      
    }
  }
  
  
  public void addSuperPowerAnimateTick(int animateTick) {
    
     animateTick = (int) animateTick/9;
    //for each animateTick that is to be added ontop of the potion box
    for(int i = 0; i < animateTick; i++) {
      
      fill(100); 
      rect(320,890-i,80,1);
      
    }
    
    
  }
  
  //adds one of 300 ticks to the potion regeneration animation
  public void addPotionAnimateTick(int animateTick) {
    
    animateTick = (int) animateTick/3;
    //for each animateTick that is to be added ontop of the potion box
    for(int i = 0; i < animateTick; i++) {
      
      fill(100); 
      rect(410,890-i,80,1);
      
    }
    
  }
  
  public void addTommyGunAnimateTick(int animateTick) {
    
    if(animateTick == 80) {
      this.tommyGunSickness = false; 
      this.tommyGunAnimationTick = 0; 
      players[0].activeTommy.addAmmo(players[0].activeTommy.getClipSize());
    }
    
    for(int i = 0; i < animateTick; i++) {
      fill(1000); 
      rect(50,890-i,80,1);
      
    }
    
    this.tommyGunAnimationTick = this.tommyGunAnimationTick + 1;
    
    
    
    
  }
  
  //adds one of __ ticks to the shotgun regenaration animation
  public void addShotGunAnimateTick(int animateTick) {
    //System.out.println("animating");
    
    if(animateTick == 60) {
      this.shotGunSickness = false; 
      this.shotGunAnimationTick = 0; 
    }
    
    for(int i = 0; i < animateTick; i++) {
      fill(1000); 
      rect(140,890-i,80,1);
      
    }
    
    this.shotGunAnimationTick = this.shotGunAnimationTick + 1; 
    
  }
  
  public void checkAnimations() {
    
    if(this.shotGunSickness) {
      addShotGunAnimateTick(this.shotGunAnimationTick);
    }
    
    if(this.tommyGunSickness) {
      addTommyGunAnimateTick(this.tommyGunAnimationTick);
    }
    
    
  }
  
  public void addPlayer(Player p) {
    players[0] = p;
    players[0].setWeapons(weaponAvailable[0], weaponAvailable[3]);
  }
  
  //displays the heads up display for the user
  public void hud(Player player) {
    
    //START: makes the iron, gold, wood and score amounts appear
    rectMode(CENTER);
    fill(0xffE6ED35);
    rect(935,830,50,30);
    
    fill(0);
    text("Gold",920,830);
    text(playerone.goldAmount,985,830);
    
    
    fill(0xffB2A89C);
    rect(935,870,50,30);
    
    fill(0);
    text("Iron",920,870);
    text(playerone.ironAmount,985,870);
    
    fill(0xff397619);
    rect(1050,830,50,30);
    
    fill(0);
    text("Wood",1035,830);
    text(playerone.woodAmount,1100,830);
    
    fill(0); 
    text("Score",1035,870);
    text(playerone.score,1100,870);
    
    //END: make the iron, gold, wood and score amounts appear
    
    //START: makes the build options available
    //show the wood options
    if(playerone.woodAmount >= 100) {
       armorAvailable[0].setBuildable(true);
       weaponAvailable[0].setBuildable(true); 
       weaponAvailable[3].setBuildable(true);
    } else {
       
    }
    
    //show the iron options
    if(playerone.ironAmount >= 100) {
       armorAvailable[1].setBuildable(true);
       weaponAvailable[1].setBuildable(true); 
       weaponAvailable[4].setBuildable(true);
    } else {
      
    }
    
    //show the gold options
    if(playerone.goldAmount >= 100) {
       armorAvailable[2].setBuildable(true);
       weaponAvailable[2].setBuildable(true); 
       weaponAvailable[5].setBuildable(true);
    } else {
      
    }
    
    //set the buildable values of the armor based on the players available materials
    if(armorAvailable[0].getCost() > players[0].getWoodAmount()) {
      armorAvailable[0].setBuildable(false); 
    } 
    if(armorAvailable[1].getCost() > players[0].getIronAmount()) {
      armorAvailable[1].setBuildable(false); 
    }
    if(armorAvailable[2].getCost() > players[0].getGoldAmount()) {
      armorAvailable[2].setBuildable(false);
    }
    
    //makes the boxes for the available armors to be selected
    for(int i = 0; i < 3; i++) {
      if(armorAvailable[i].buildable) {
        fill(armorAvailable[i].colour);
        rect(1160+i*60, 820, 50, 20);
        fill(0);
        text("Armor", 1140+i*60, 825);
      }
    }
    
    //set the buildable values of the weapons based on the players available materials
    if(weaponAvailable[0].getCost() > players[0].getWoodAmount()) {
      weaponAvailable[0].setBuildable(false); 
    } 
    if(weaponAvailable[1].getCost() > players[0].getIronAmount()) {
      weaponAvailable[1].setBuildable(false); 
    }
    if(weaponAvailable[2].getCost() > players[0].getGoldAmount()) {
      weaponAvailable[2].setBuildable(false);
    }
    
    //makes the boxes for the available tommy guns to be selected
    for(int i = 0; i < 3; i++) {
      if(weaponAvailable[i].buildable) {
        fill(weaponAvailable[i].colour);
        rect(1160+i*60, 850, 50, 20);
        fill(0);
        text("Tommy", 1140+i*60, 855);
      }
    }
    
    //set the buildable values of the weapons based on the players available materials
    if(weaponAvailable[3].getCost() > players[0].getWoodAmount()) {
      weaponAvailable[3].setBuildable(false); 
    } 
    if(weaponAvailable[4].getCost() > players[0].getIronAmount()) {
      weaponAvailable[4].setBuildable(false); 
    }
    if(weaponAvailable[5].getCost() > players[0].getGoldAmount()) {
      weaponAvailable[5].setBuildable(false);
    }
    
    //makes the boxes for the available shot guns to be selected
    for(int i = 3; i < 6; i++) {
      if(weaponAvailable[i].buildable) {
        fill(weaponAvailable[i].colour);
        rect(1160+(i-3)*60, 880, 50, 20);
        fill(0);
        text("Shotgun", 1140+(i-3)*60, 885);
      }
    }
    
    //END: makes the build options available
    
    //START: makes the toolbar appear
    //tommy gun box
    fill(0xffB2A89C);
    fill(player.activeTommy.colour);
    if(player.active == 1) {
      fill(0xff00FCE5);
    } 
    rect(50,850,80,80);
    fill(0);
    
    if(player.activeTommy.tier=="Wood") {
    
       image(imageList[27],12,850);
       
    } else if (player.activeTommy.tier=="Iron") {
       
       image(imageList[28],12,850);
       
    } else {
       
       image(imageList[29],12,850);
       
    }
    
    //text("Gun",40,850);
    text(""+player.activeTommy.ammo,40,830);
    
    
    
    
    fill(0xffB2A89C);
    
    //shotgun box
    fill(player.activeShotgun.colour);
    if(player.active == 2) {
      fill(0xff00FCE5);
    }
    rect(140,850,80,80);
    fill(0);
    
    if(player.activeShotgun.tier=="Wood") {
    
       image(imageList[30],104,850);
       
    } else if (player.activeShotgun.tier=="Iron") {
       
       image(imageList[31],104,850);
       
    } else {
       
       image(imageList[32],104,850);
       
    }
    
    
    //text("Shotgun",120,850);
    text(""+player.activeShotgun.ammo,120,830);
    fill(0xffB2A89C);
    
    
    //pickaxe box
    if(player.active == 3) {
      fill(0xff00FCE5);
    } 
    rect(230,850,80,80);
    fill(0); 
    
    
    //pickaxe image
    image(imageList[26],197,817); 
    
    //text("Pickaxe",210,850);
    fill(0xffB2A89C);
    
    //hammer box
    if(player.active == 4) {
      fill(0xff00FCE5);
    } 
    rect(320,850,80,80);
    fill(0);
    
    //superpower image
    image(imageList[40],287,817);
    
    fill(0xffB2A89C);
    
    //potion box
    if(player.active == 5) {
      fill(0xff00FCE5);
    } else {
      fill(0xffB2A89C);
    }
    rect(410,850,80,80);
    fill(0);
    
    //potion image
    image(imageList[25],377,817);
    
    //text("Potion",400,850);
    fill(0xffB2A89C);
    //END: makes the toolbar appear
    
    
    //START: makes the health bar appear
    //health
    fill(255,0,0); 
    for(int i = 0; i < player.getHealth(); i++) {
      rect(480+(i*2),870,2,30);
    }
    
    //shield
    fill(0,0,255);
    for(int i = 0; i < player.getShield(); i++) {
      rect(480+(i*2),830,2,30);
    }
    //END: makes the health bar appear
    
  }
  
  //this displays all of the tiles on the gameboard
  public void display() {
    
    
    //display all of the blocks
    for(int i = 0; i < 70; i++) {
      
      for(int j = 0; j < 40; j++) {
         fill(tiles[j][i].getColour());
         
         tiles[j][i].setXCoor(i*20+10);
         tiles[j][i].setYCoor(j*20+10);
         
         tiles[j][i].setIndexI(j);
         tiles[j][i].setIndexJ(i);
         
         //if the tile has already been mined
         if(tiles[j][i].health <= 0) {
           fill(0xffA0681F); 
           tiles[j][i].nothing();
         }
      
         
         
         //rect(i*20+10,j*20+10,20,20);
         
         
         //if the tile has been hit once
         //if(tiles[j][i].health == 75) {
           //line(i*20+10,j*20+10,i*20,j*20);
         //}
         //if the tile has been damaged halfway
         //if(tiles[j][i].health == 50) {
           //line(i*20+20,j*20+20,i*20,j*20);
         //}
         //if the tile has been damaged 3/4 of the way
        // if(tiles[j][i].health == 25) {
           //line(i*20+20,j*20+20,i*20,j*20);
           //line(i*20+20,j*20,i*20,j*20+20);
         //}
      }
    }
    
    
    showImages();
 }
 
 
 //tropical biome
 public void generateTropical() {
   
   //reset the difficulty for the new biome's enemies to progress
   difficulty = 0; 
   
   Random r = new Random();
   
   System.out.println("Generating new biome");
    
   int streamSize = 2800; 
   int start = 0; 
   int bound = 2799; 
   int goldBound = 150;
   int ironBound = 250;
   int goldMin = 100; 
   int ironMin = 100;
   int resourceXYMin = 2; //so that cluster placed resources dont out of bounds error 
   int lavaMin = 0; 
   int lavaBound = 20;
   
   
   //generateBiome is only called after the initial biome has been defeated so the player should now have access to the potion and superpower upgrades
   int potionUpgradeMin = 30; 
   int potionUpgradeBound = 50;
   
   
   int superPowerMin = 30; 
   int superPowerBound = 50; 
   
   
   //generate the water area
   
    
   r.ints(streamSize, start, bound);
   
   //initialize all of the tiles in the array used to represent our gameboard
    for(int i = 0; i < 40; i++) {
      
      for(int j = 0; j < 70; j++) {
        tiles[i][j] = new Tile();
      }
      
    }
   
   
   //GENERATE THE NEW BIOME
   //reset all of the pieces to tropical default
   for (int i = 0; i < 70; i++) {
     
     for(int j = 0; j < 40; j++) {
       
       tiles[j][i].tropical();
       
     }
     
   }
   
   //GOLD GENERATION
    int goldPieces = r.nextInt(goldBound+1-goldMin) + goldMin;
    //println("gold pieces" + goldPieces);
    
    int goldplaceCounter = 0;
    
    int goldClusters = goldPieces/5; 
    
    //println("gold clusters" + goldClusters);
    while(goldplaceCounter < goldClusters) {
      
      int x = r.nextInt(39-resourceXYMin) + resourceXYMin;
      int y = r.nextInt(69-resourceXYMin) + resourceXYMin;
      
      tiles[x][y].gold();
      tiles[x+1][y+1].gold();
      tiles[x-1][y-1].gold();
      tiles[x][y+1].gold();
      tiles[x][y-1].gold();
      tiles[x+1][y].gold();
      tiles[x-1][y].gold();
      
      goldplaceCounter++;
    }
    //GOLD GENERATION DONE
    //IRON GENERATION
    int ironPieces = r.nextInt(ironBound+1-ironMin) + ironMin;
    //println("iron pieces" + ironPieces);
    
    int ironplaceCounter = 0;
    
    int ironClusters = ironPieces/5; 
    
    //println("iron clusters" + ironClusters);
    while(ironplaceCounter < ironClusters) {
      
      int x = r.nextInt(39-resourceXYMin) + resourceXYMin;
      int y = r.nextInt(69-resourceXYMin) + resourceXYMin;
      
      tiles[x][y].iron();
      tiles[x+1][y+1].iron();
      tiles[x-1][y-1].iron();
      tiles[x][y+1].iron();
      tiles[x][y-1].iron();
      tiles[x+1][y].iron();
      tiles[x-1][y].iron();
      
      ironplaceCounter++;
    }
    //IRON GENERATION DONE
    
    
    
    //LAVA GENERATION
    int lavaPieces = r.nextInt(lavaBound+1-lavaMin) + lavaMin;
    //println("lava tiles" + lavaPieces);
    
    int lavaplaceCounter = 0;
    
    int lavaClusters = lavaPieces/5; 
    
    //println("lava clusters" + lavaClusters);
    while(lavaplaceCounter < lavaClusters) {
      
      int x = r.nextInt(39-resourceXYMin) + resourceXYMin;
      int y = r.nextInt(69-resourceXYMin) + resourceXYMin;
      
      tiles[x][y].lava();
      tiles[x+1][y+1].lava();
      tiles[x-1][y-1].lava();
      tiles[x][y+1].lava();
      tiles[x][y-1].lava();
      tiles[x+1][y].lava();
      tiles[x-1][y].lava();
      
      lavaplaceCounter++;
    }
    //LAVA GENERATION DONE
    
    
    //SUPER POWER UPGRADE GENERATION
    int superPowerPieces = r.nextInt(superPowerBound+1-superPowerMin) + superPowerMin;
    //println("lava tiles" + lavaPieces);
    
    int superPowerplaceCounter = 0;
    
    int superPowerClusters = superPowerPieces/5; 
    
    //println("lava clusters" + lavaClusters);
    while(superPowerplaceCounter < superPowerClusters) {
      
      int x = r.nextInt(39-resourceXYMin) + resourceXYMin;
      int y = r.nextInt(69-resourceXYMin) + resourceXYMin;
      
      tiles[x][y].superPower();
      tiles[x+1][y+1].superPower();
      tiles[x-1][y-1].superPower();
      tiles[x][y+1].superPower();
      tiles[x][y-1].superPower();
      tiles[x+1][y].superPower();
      tiles[x-1][y].superPower();
      
      superPowerplaceCounter++;
    }
    
    
    
    
    //SUPER POWER UPGRADE GENERATION DONE
    
    
    //POTION UPGRADE GENERATION
    int potionUpgradePieces = r.nextInt(potionUpgradeBound+1-potionUpgradeMin) + potionUpgradeMin;
    //println("lava tiles" + lavaPieces);
    
    int potionUpgradeplaceCounter = 0;
    
    int potionUpgradeClusters = potionUpgradePieces/5; 
    
    //println("lava clusters" + lavaClusters);
    while(potionUpgradeplaceCounter < potionUpgradeClusters) {
      
      int x = r.nextInt(39-resourceXYMin) + resourceXYMin;
      int y = r.nextInt(69-resourceXYMin) + resourceXYMin;
      
      tiles[x][y].potionUpgrade();
      tiles[x+1][y+1].potionUpgrade();
      tiles[x-1][y-1].potionUpgrade();
      tiles[x][y+1].potionUpgrade();
      tiles[x][y-1].potionUpgrade();
      tiles[x+1][y].potionUpgrade();
      tiles[x-1][y].potionUpgrade();
      
      potionUpgradeplaceCounter++;
    }
    
    
    
    
    
    //POTION GENERATION DONE
   
   this.currentBiome = "tropical";
   
   plantTreesInTropicalBiome();
   
   makeTheWater();
   
 }
 
 public void makeTheWater() {
   
   Random r = new Random();
   
   int streamSize = 10; 
   int start = 0; 
   int bound = 9; 
   int waterLocationsMin = 1; 
   int waterLocationsBound = 1;
   
   r.ints(streamSize, start, bound);
   
   int waterLocation = r.nextInt(waterLocationsBound+1-waterLocationsMin) + waterLocationsMin;
   
   this.waterLoc = waterLocation;
   
   System.out.println(waterLocation);
   
   
   if(waterLocation == 1) {
     
     tiles[0][0].water();
     tiles[1][0].water();
     tiles[2][0].water();
     tiles[3][0].water();
     tiles[4][0].water();
     tiles[5][0].water();
     tiles[6][0].water();
     tiles[7][0].water();
     tiles[8][0].water();
     tiles[9][0].water();
     tiles[10][0].water();
     tiles[10][0].water();
     tiles[11][0].water();
     tiles[12][0].water();
     tiles[13][0].water();
     
     tiles[14][0].sand();
     tiles[14][1].sand();
     tiles[14][2].sand();
     
     
     tiles[15][0].sand();
     tiles[15][1].sand();
     tiles[15][2].sand();
     
     tiles[0][1].water();
     tiles[1][1].water();
     tiles[2][1].water();
     tiles[3][1].water();
     tiles[4][1].water();
     tiles[5][1].water();
     tiles[6][1].water();
     tiles[7][1].water();
     tiles[8][1].water();
     tiles[9][1].water();
     tiles[10][1].water();
     tiles[10][1].water();
     tiles[11][1].water();
     tiles[12][1].water();
     tiles[13][1].water();
     
     
     tiles[13][3].sand();
     tiles[13][4].sand();
     
     tiles[14][3].sand();
     tiles[14][4].sand();
    
     
     
     
     tiles[0][2].water();
     tiles[1][2].water();
     tiles[2][2].water();
     tiles[3][2].water();
     tiles[4][2].water();
     tiles[5][2].water();
     tiles[6][2].water();
     tiles[7][2].water();
     tiles[8][2].water();
     tiles[9][2].water();
     tiles[10][2].water();
     tiles[10][2].water();
     tiles[11][2].water();
     tiles[12][2].water();
     tiles[13][2].water();
     
     
     tiles[12][5].sand();
     tiles[12][6].sand();
     tiles[12][7].sand();
     tiles[12][8].sand();
     
      tiles[13][5].sand();
     tiles[13][6].sand();
     tiles[13][7].sand();
     tiles[13][8].sand();
     
     
     tiles[0][3].water();
     tiles[1][3].water();
     tiles[2][3].water();
     tiles[3][3].water();
     tiles[4][3].water();
     tiles[5][3].water();
     tiles[6][3].water();
     tiles[7][3].water();
     tiles[8][3].water();
     tiles[9][3].water();
     tiles[10][3].water();
     tiles[10][3].water();
     tiles[11][3].water();
     tiles[12][3].water();
     
     
     tiles[11][9].sand();
     tiles[11][10].sand();
     tiles[11][11].sand();
     tiles[11][12].sand();
     tiles[11][13].sand();
     tiles[11][14].sand();
     
     tiles[12][9].sand();
     tiles[12][10].sand();
     tiles[12][11].sand();
     tiles[12][12].sand();
     tiles[12][13].sand();
     tiles[12][14].sand();
     
     tiles[10][15].sand();
     
     tiles[9][16].sand();
     tiles[9][17].sand();
     tiles[10][16].sand();
     tiles[10][17].sand();
     
     tiles[8][18].sand();
     tiles[7][19].sand();
     tiles[6][20].sand();
     tiles[5][21].sand();
     tiles[4][22].sand();
     tiles[3][23].sand();
     tiles[2][24].sand();
     tiles[1][25].sand();
     tiles[0][26].sand();
     
     tiles[9][18].sand();
     tiles[8][19].sand();
     tiles[7][20].sand();
     tiles[6][21].sand();
     tiles[5][22].sand();
     tiles[4][23].sand();
     tiles[3][24].sand();
     tiles[2][25].sand();
     tiles[1][26].sand();
     
     
     
     tiles[11][15].sand();
     tiles[10][16].sand();
    
     tiles[0][4].water();
     tiles[1][4].water();
     tiles[2][4].water();
     tiles[3][4].water();
     tiles[4][4].water();
     tiles[5][4].water();
     tiles[6][4].water();
     tiles[7][4].water();
     tiles[8][4].water();
     tiles[9][4].water();
     tiles[10][4].water();
     tiles[10][4].water();
     tiles[11][4].water();
     tiles[12][4].water();
    
     tiles[0][5].water();
     tiles[1][5].water();
     tiles[2][5].water();
     tiles[3][5].water();
     tiles[4][5].water();
     tiles[5][5].water();
     tiles[6][5].water();
     tiles[7][5].water();
     tiles[8][5].water();
     tiles[9][5].water();
     tiles[10][5].water();
     tiles[10][5].water();
     tiles[11][5].water();
     
     tiles[0][6].water();
     tiles[1][6].water();
     tiles[2][6].water();
     tiles[3][6].water();
     tiles[4][6].water();
     tiles[5][6].water();
     tiles[6][6].water();
     tiles[7][6].water();
     tiles[8][6].water();
     tiles[9][6].water();
     tiles[10][6].water();
     tiles[10][6].water();
     tiles[11][6].water();
     
     
     tiles[0][7].water();
     tiles[1][7].water();
     tiles[2][7].water();
     tiles[3][7].water();
     tiles[4][7].water();
     tiles[5][7].water();
     tiles[6][7].water();
     tiles[7][7].water();
     tiles[8][7].water();
     tiles[9][7].water();
     tiles[10][7].water();
     tiles[10][7].water();
     tiles[11][7].water();
     
     
     tiles[0][8].water();
     tiles[1][8].water();
     tiles[2][8].water();
     tiles[3][8].water();
     tiles[4][8].water();
     tiles[5][8].water();
     tiles[6][8].water();
     tiles[7][8].water();
     tiles[8][8].water();
     tiles[9][8].water();
     tiles[10][8].water();
     tiles[10][8].water();
     tiles[11][8].water();
     
     
     tiles[0][9].water();
     tiles[1][9].water();
     tiles[2][9].water();
     tiles[3][9].water();
     tiles[4][9].water();
     tiles[5][9].water();
     tiles[6][9].water();
     tiles[7][9].water();
     tiles[8][9].water();
     tiles[9][9].water();
     tiles[10][9].water();
     tiles[10][9].water();
     
     
     tiles[0][10].water();
     tiles[1][10].water();
     tiles[2][10].water();
     tiles[3][10].water();
     tiles[4][10].water();
     tiles[5][10].water();
     tiles[6][10].water();
     tiles[7][10].water();
     tiles[8][10].water();
     tiles[9][10].water();
     tiles[10][10].water();
     tiles[10][10].water();
     
     tiles[0][11].water();
     tiles[1][11].water();
     tiles[2][11].water();
     tiles[3][11].water();
     tiles[4][11].water();
     tiles[5][11].water();
     tiles[6][11].water();
     tiles[7][11].water();
     tiles[8][11].water();
     tiles[9][11].water();
     tiles[10][11].water();
     tiles[10][11].water();
     
     
     tiles[0][12].water();
     tiles[1][12].water();
     tiles[2][12].water();
     tiles[3][12].water();
     tiles[4][12].water();
     tiles[5][12].water();
     tiles[6][12].water();
     tiles[7][12].water();
     tiles[8][12].water();
     tiles[9][12].water();
     tiles[10][12].water();
     tiles[10][12].water();
     
     
     tiles[0][13].water();
     tiles[1][13].water();
     tiles[2][13].water();
     tiles[3][13].water();
     tiles[4][13].water();
     tiles[5][13].water();
     tiles[6][13].water();
     tiles[7][13].water();
     tiles[8][13].water();
     tiles[9][13].water();
     tiles[10][13].water();
     
     
     tiles[0][14].water();
     tiles[1][14].water();
     tiles[2][14].water();
     tiles[3][14].water();
     tiles[4][14].water();
     tiles[5][14].water();
     tiles[6][14].water();
     tiles[7][14].water();
     tiles[8][14].water();
     tiles[9][14].water();
     tiles[10][14].water();
     
     
     tiles[0][15].water();
     tiles[1][15].water();
     tiles[2][15].water();
     tiles[3][15].water();
     tiles[4][15].water();
     tiles[5][15].water();
     tiles[6][15].water();
     tiles[7][15].water();
     tiles[8][15].water();
     tiles[9][15].water();
     
     tiles[0][16].water();
     tiles[1][16].water();
     tiles[2][16].water();
     tiles[3][16].water();
     tiles[4][16].water();
     tiles[5][16].water();
     tiles[6][16].water();
     tiles[7][16].water();
     tiles[8][16].water();
    
     tiles[0][17].water();
     tiles[1][17].water();
     tiles[2][17].water();
     tiles[3][17].water();
     tiles[4][17].water();
     tiles[5][17].water();
     tiles[6][17].water();
     tiles[7][17].water();
     tiles[8][17].water();
     
     
     tiles[0][18].water();
     tiles[1][18].water();
     tiles[2][18].water();
     tiles[3][18].water();
     tiles[4][18].water();
     tiles[5][18].water();
     tiles[6][18].water();
     tiles[7][18].water();
     
     tiles[0][19].water();
     tiles[1][19].water();
     tiles[2][19].water();
     tiles[3][19].water();
     tiles[4][19].water();
     tiles[5][19].water();
     tiles[6][19].water();
     
     
     tiles[0][20].water();
     tiles[1][20].water();
     tiles[2][20].water();
     tiles[3][20].water();
     tiles[4][20].water();
     tiles[5][20].water();
     
     tiles[0][21].water();
     tiles[1][21].water();
     tiles[2][21].water();
     tiles[3][21].water();
     tiles[4][21].water();
    
     tiles[0][22].water();
     tiles[1][22].water();
     tiles[2][22].water();
     tiles[3][22].water();
     
     tiles[0][23].water();
     tiles[1][23].water();
     tiles[2][23].water();
    
     tiles[0][24].water();
     tiles[1][24].water();
     
     tiles[0][25].water();
    
    
     
     
   } else if (waterLocation == 2) {
     
     
     
   } else if (waterLocation == 3) {
     
     
   } else {
     
     
     
   }
     
     
   
 }
 
 
 //steel biome
 public void generateBiome() {
   
   //reset the difficulty for the new biome's enemies to progress
   difficulty = 0; 
   
   Random r = new Random();
   
   System.out.println("Generating new biome");
    
   int streamSize = 2800; 
   int start = 0; 
   int bound = 2799; 
   int goldBound = 100;
   int ironBound = 200;
   int goldMin = 25; 
   int ironMin = 50;
   int resourceXYMin = 2; //so that cluster placed resources dont out of bounds error 
   int lavaMin = 50; 
   int lavaBound = 150;
   
   
   //generateBiome is only called after the initial biome has been defeated so the player should now have access to the potion and superpower upgrades
   int potionUpgradeMin = 10; 
   int potionUpgradeBound = 20;
   
   
   int superPowerMin = 10; 
   int superPowerBound = 20; 
    
   r.ints(streamSize, start, bound);
   
   //initialize all of the tiles in the array used to represent our gameboard
    for(int i = 0; i < 40; i++) {
      
      for(int j = 0; j < 70; j++) {
        tiles[i][j] = new Tile();
      }
      
    }
   
   
   //GENERATE THE NEW BIOME
   //reset all of the pieces to steel default
   for (int i = 0; i < 70; i++) {
     
     for(int j = 0; j < 40; j++) {
       
       tiles[j][i].steel();
       
     }
     
   }
   
   //GOLD GENERATION
    int goldPieces = r.nextInt(goldBound+1-goldMin) + goldMin;
    //println("gold pieces" + goldPieces);
    
    int goldplaceCounter = 0;
    
    int goldClusters = goldPieces/5; 
    
    //println("gold clusters" + goldClusters);
    while(goldplaceCounter < goldClusters) {
      
      int x = r.nextInt(39-resourceXYMin) + resourceXYMin;
      int y = r.nextInt(69-resourceXYMin) + resourceXYMin;
      
      tiles[x][y].gold();
      tiles[x+1][y+1].gold();
      tiles[x-1][y-1].gold();
      tiles[x][y+1].gold();
      tiles[x][y-1].gold();
      tiles[x+1][y].gold();
      tiles[x-1][y].gold();
      
      goldplaceCounter++;
    }
    //GOLD GENERATION DONE
    //IRON GENERATION
    int ironPieces = r.nextInt(ironBound+1-ironMin) + ironMin;
    //println("iron pieces" + ironPieces);
    
    int ironplaceCounter = 0;
    
    int ironClusters = ironPieces/5; 
    
    //println("iron clusters" + ironClusters);
    while(ironplaceCounter < ironClusters) {
      
      int x = r.nextInt(39-resourceXYMin) + resourceXYMin;
      int y = r.nextInt(69-resourceXYMin) + resourceXYMin;
      
      tiles[x][y].iron();
      tiles[x+1][y+1].iron();
      tiles[x-1][y-1].iron();
      tiles[x][y+1].iron();
      tiles[x][y-1].iron();
      tiles[x+1][y].iron();
      tiles[x-1][y].iron();
      
      ironplaceCounter++;
    }
    //IRON GENERATION DONE
    
    
    
    //LAVA GENERATION
    int lavaPieces = r.nextInt(lavaBound+1-lavaMin) + lavaMin;
    //println("lava tiles" + lavaPieces);
    
    int lavaplaceCounter = 0;
    
    int lavaClusters = lavaPieces/5; 
    
    //println("lava clusters" + lavaClusters);
    while(lavaplaceCounter < lavaClusters) {
      
      int x = r.nextInt(39-resourceXYMin) + resourceXYMin;
      int y = r.nextInt(69-resourceXYMin) + resourceXYMin;
      
      tiles[x][y].lava();
      tiles[x+1][y+1].lava();
      tiles[x-1][y-1].lava();
      tiles[x][y+1].lava();
      tiles[x][y-1].lava();
      tiles[x+1][y].lava();
      tiles[x-1][y].lava();
      
      lavaplaceCounter++;
    }
    //LAVA GENERATION DONE
    
    
    //SUPER POWER UPGRADE GENERATION
    int superPowerPieces = r.nextInt(superPowerBound+1-superPowerMin) + superPowerMin;
    //println("lava tiles" + lavaPieces);
    
    int superPowerplaceCounter = 0;
    
    int superPowerClusters = superPowerPieces/5; 
    
    //println("lava clusters" + lavaClusters);
    while(superPowerplaceCounter < superPowerClusters) {
      
      int x = r.nextInt(39-resourceXYMin) + resourceXYMin;
      int y = r.nextInt(69-resourceXYMin) + resourceXYMin;
      
      tiles[x][y].superPower();
      tiles[x+1][y+1].superPower();
      tiles[x-1][y-1].superPower();
      tiles[x][y+1].superPower();
      tiles[x][y-1].superPower();
      tiles[x+1][y].superPower();
      tiles[x-1][y].superPower();
      
      superPowerplaceCounter++;
    }
    
    
    
    
    //SUPER POWER UPGRADE GENERATION DONE
    
    
    //POTION UPGRADE GENERATION
    int potionUpgradePieces = r.nextInt(potionUpgradeBound+1-potionUpgradeMin) + potionUpgradeMin;
    //println("lava tiles" + lavaPieces);
    
    int potionUpgradeplaceCounter = 0;
    
    int potionUpgradeClusters = potionUpgradePieces/5; 
    
    //println("lava clusters" + lavaClusters);
    while(potionUpgradeplaceCounter < potionUpgradeClusters) {
      
      int x = r.nextInt(39-resourceXYMin) + resourceXYMin;
      int y = r.nextInt(69-resourceXYMin) + resourceXYMin;
      
      tiles[x][y].potionUpgrade();
      tiles[x+1][y+1].potionUpgrade();
      tiles[x-1][y-1].potionUpgrade();
      tiles[x][y+1].potionUpgrade();
      tiles[x][y-1].potionUpgrade();
      tiles[x+1][y].potionUpgrade();
      tiles[x-1][y].potionUpgrade();
      
      potionUpgradeplaceCounter++;
    }
    
    
    
    
    
    //POTION GENERATION DONE
   
   this.currentBiome = "steel";
   
   plantTreesInSteelBiome();
   
 }
 
 
  public void createMap() {
    Random r = new Random();
    
    int streamSize = 2800; 
    int start = 0; 
    int bound = 2799; 
    int goldBound = 100;
    int ironBound = 200;
    int goldMin = 35; 
    int ironMin = 75;
    int resourceXYMin = 2; //so that cluster placed resources dont out of bounds error 
    int lavaMin = 30; 
    int lavaBound = 60;
    
    r.ints(streamSize, start, bound);
    
    
    //GENERATE THE MAP
    //GOLD GENERATION
    int goldPieces = r.nextInt(goldBound+1-goldMin) + goldMin;
    //println("gold pieces" + goldPieces);
    
    int goldplaceCounter = 0;
    
    int goldClusters = goldPieces/5; 
    
    //println("gold clusters" + goldClusters);
    while(goldplaceCounter < goldClusters) {
      
      int x = r.nextInt(39-resourceXYMin) + resourceXYMin;
      int y = r.nextInt(69-resourceXYMin) + resourceXYMin;
      
      tiles[x][y].gold();
      tiles[x+1][y+1].gold();
      tiles[x-1][y-1].gold();
      tiles[x][y+1].gold();
      tiles[x][y-1].gold();
      tiles[x+1][y].gold();
      tiles[x-1][y].gold();
      
      goldplaceCounter++;
    }
    //GOLD GENERATION DONE
    
    
    //IRON GENERATION
    int ironPieces = r.nextInt(ironBound+1-ironMin) + ironMin;
    //println("iron pieces" + ironPieces);
    
    int ironplaceCounter = 0;
    
    int ironClusters = ironPieces/5; 
    
    //println("iron clusters" + ironClusters);
    while(ironplaceCounter < ironClusters) {
      
      int x = r.nextInt(39-resourceXYMin) + resourceXYMin;
      int y = r.nextInt(69-resourceXYMin) + resourceXYMin;
      
      tiles[x][y].iron();
      tiles[x+1][y+1].iron();
      tiles[x-1][y-1].iron();
      tiles[x][y+1].iron();
      tiles[x][y-1].iron();
      tiles[x+1][y].iron();
      tiles[x-1][y].iron();
      
      ironplaceCounter++;
    }
    //IRON GENERATION DONE
    
    
    
    //LAVA GENERATION
    int lavaPieces = r.nextInt(lavaBound+1-lavaMin) + lavaMin;
    //println("lava tiles" + lavaPieces);
    
    int lavaplaceCounter = 0;
    
    int lavaClusters = lavaPieces/5; 
    
    //println("lava clusters" + lavaClusters);
    while(lavaplaceCounter < lavaClusters) {
      
      int x = r.nextInt(39-resourceXYMin) + resourceXYMin;
      int y = r.nextInt(69-resourceXYMin) + resourceXYMin;
      
      tiles[x][y].lava();
      tiles[x+1][y+1].lava();
      tiles[x-1][y-1].lava();
      tiles[x][y+1].lava();
      tiles[x][y-1].lava();
      tiles[x+1][y].lava();
      tiles[x-1][y].lava();
      
      lavaplaceCounter++;
    }
    //LAVA GENERATION DONE
 
    //tiles[0][0].showYourself();
    //tiles[1][0].showYourself();
    //tiles[0][1].showYourself();
    //tiles[39][69].showYourself();
    
    System.out.println("map generated"); 
   
    plantTrees();
    
    
    
  }
  
  public void displayPlayers() {
    
    
    
  }
  
  public void showImages() {
    
    for(int i = 0; i<40; i++) {
       
        for(int j = 0; j<70; j++) {
          
          tiles[i][j].hasPlayer = false;
          
        }
        
    }
    
    //find where the player is standing
    int playerI; 
    int playerJ; 
    
    playerI = players[0].indexI; 
    playerJ = players[0].indexJ;
    
    tiles[playerI][playerJ].hasPlayer = true; 
    
    for(int i = 0; i<40; i++) {
       
        for(int j = 0; j<70; j++) {
          
          //rect(i*20+10,j*20+10,20,20);
          
          if(tiles[i][j].getType().equals("Tree")) {
            
            if(tiles[i][j].getHealth() == 100) {
              image(imageList[0],j*20,i*20);
            } else if (tiles[i][j].getHealth() == 75) {
              image(imageList[1],j*20,i*20);
            } else if (tiles[i][j].getHealth() == 50) {
              image(imageList[2],j*20,i*20);
            } else if (tiles[i][j].getHealth() == 25) {
              image(imageList[3],j*20,i*20);
            }
              
              
          } else if (tiles[i][j].getType().equals("Iron")) {
            
            if(tiles[i][j].getHealth() == 100) {
              image(imageList[4],j*20,i*20);
            } else if (tiles[i][j].getHealth() == 75) {
              image(imageList[5],j*20,i*20);
            } else if (tiles[i][j].getHealth() == 50) {
              image(imageList[6],j*20,i*20);
            } else if (tiles[i][j].getHealth() == 25) {
              image(imageList[7],j*20,i*20);
            }
            
             
              
          } else if (tiles[i][j].getType().equals("Gold")) {
            
            if(tiles[i][j].getHealth() == 100) {
              image(imageList[8],j*20,i*20);
            } else if (tiles[i][j].getHealth() == 75) {
              image(imageList[9],j*20,i*20);
            } else if (tiles[i][j].getHealth() == 50) {
              image(imageList[10],j*20,i*20);
            } else if (tiles[i][j].getHealth() == 25) {
              image(imageList[11],j*20,i*20);
            }
             
          } else if (tiles[i][j].getType().equals("Lava")) {
            
            image(imageList[12],j*20,i*20);
            
          } else if (tiles[i][j].getType().equals("Dirt")) {
          
            image(imageList[13],j*20,i*20);
            
          } else if (tiles[i][j].getType().equals("Nothing")) {
            
            image(imageList[14],j*20,i*20);
            
          } else if (tiles[i][j].getType().equals("Steel")) {
            
            image(imageList[34],j*20,i*20);
            
          } else if (tiles[i][j].getType().equals("SuperPower")) {
            
            image(imageList[36],j*20,i*20); 
            
          } else if (tiles[i][j].getType().equals("PotionUpgrade")) {
            
            image(imageList[35],j*20,i*20);
            
          } else if (tiles[i][j].getType().equals("Tropical")) {
            
            image(imageList[43],j*20,i*20);
            
            
          } else if (tiles[i][j].getType().equals("TropicalTree")) {
            
            
          } else if (tiles[i][j].getType().equals("Water")) {
            
            image(imageList[44],j*20,i*20);
            
          } else if (tiles[i][j].getType().equals("Sand")) {
            
            image(imageList[46],j*20,i*20);
            
          }
            
        }
        
    }
    
    //places the player in their spot
    image(imageList[15],playerJ*20,playerI*20);
    
     //image(images[45],0,0);
      
  }
  
  public void plantTrees() {
    int choice = 0;
    //TREE GENERATION START
    
    //start by finding all of the remaining spots that are not filled in, they are dirt. 
    //only plant trees once per match
    if(!plantedTrees) {
      println("Planting trees");
    
      for(int i = 0; i<40; i++) {
       
        for(int j = 0; j<70; j++) {
        
          //if the tile is dirt
          if(tiles[i][j].getType().equals("Dirt")) {
          
            //choose between 0,1,2,3,4,5,6
            choice = (int) random(7);
          
            //turn one seventh (probabilistically) of the dirt tiles to a tree tile
            if(choice == 0) {
               tiles[i][j].tree(); 
            }
            
          }
        
        
        }
      
      }
      plantedTrees = true;
    }
    
    
      //TREE GENERATION DONE
      
      
    
  }
  
  
  public void plantTreesInSteelBiome() {
    
    int choice = 0;
    //TREE GENERATION START
    
    //start by finding all of the remaining spots that are not filled in, they are steel. 
    //only plant trees once per biome creation
    if(!plantedTreesInSteel) {
      println("Planting trees in steel");
    
      for(int i = 0; i<40; i++) {
       
        for(int j = 0; j<70; j++) {
        
          //if the tile is dirt
          if(tiles[i][j].getType().equals("Steel")) {
          
            //choose between 0,1,2,3,4,5,6 ... 15
            choice = (int) random(16);
          
            //turn one sixteenth (probabilistically) of the steel tiles to a tree tile
            if(choice == 0) {
               tiles[i][j].tree(); 
            }
            
          }
        
        
        }
      
      }
      plantedTreesInSteel = true;
    }
    
    
  }
  
  
  public void plantTreesInTropicalBiome() {
    
    int choice = 0;
    //TREE GENERATION START
    
    //start by finding all of the remaining spots that are not filled in, they are steel. 
    //only plant trees once per biome creation
    if(!plantedTreesInTropical) {
      println("Planting trees in tropical");
    
      for(int i = 0; i<40; i++) {
       
        for(int j = 0; j<70; j++) {
        
          //if the tile is dirt
          if(tiles[i][j].getType().equals("Tropical")) {
          
            //choose between 0,1,2,3,4,5,6 ... 15
            choice = (int) random(16);
          
            //turn one sixteenth (probabilistically) of the steel tiles to a tree tile
            if(choice == 0) {
               tiles[i][j].tropicalTree(); 
            }
            
          }
        
        
        }
      
      }
      plantedTreesInTropical = true;
    }
    
    
  }
  
 
}
class Gorilla extends Enemy {
  
  PImage[] images = new PImage[3];
  
  //100 health
  //20 attack
  
  
  //for testing spawns an ant (0,0)
  Gorilla() {
    super(500, 3, 0, 0, 0, 0, "Gorilla", 60);
    images[0] = loadImage("gorilla.png");
    images[1] = loadImage("gorilla75.png");
    images[2] = loadImage("gorilla50.png");
    
    images[0].resize(40,40);
    images[1].resize(40,40);
    images[2].resize(40,40);
   
  }
  
  
  //for when the location is specified
  Gorilla(float x, float y) {
    super(500, 3, x, y, x/20, y/20, "Gorilla", 60);
   images[0] = loadImage("gorilla.png");
    images[1] = loadImage("gorilla75.png");
    images[2] = loadImage("gorilla50.png");
    
    images[0].resize(40,40);
    images[1].resize(40,40);
    images[2].resize(40,40);
    
  }
  
  
  public void show() {
    
    
      if(this.health > 350) {
        image(images[0], this.xC, this.yC);
      } else if ( (this.health <= 350) & (this.health > 200)) {
        image(images[1], this.xC, this.yC);  
      } else if(this.health <= 200 & (this.health > 0)) {
        image(images[2], this.xC, this.yC);
      } else if(this.health <= 0) {
        this.die();
      }
    
    
  }
  
  public void move(int targetX, int targetY) {
    
    //make targetX and targetY into the graphics coordinate not index
      targetX = targetX*20; 
      targetY = targetY*20;
    
      //accidentaly switched them somewhere along the line
      int temp = targetY; 
      targetY = targetX; 
      targetX = temp;
      
      
      int myLocX = (int)this.xC; 
        int myLocY = (int)this.yC;
      
        //System.out.println("MyLocX: " + myLocX); 
        //System.out.println("MyLocY: " + myLocY); 
        //System.out.println("TargetX: " + targetX); 
        //System.out.println("TargetY: " + targetY); 
      
      
        if( (targetX > myLocX)&(targetY > myLocY) ) {
        
          //System.out.println("TOOK A STEP FOR REAL 1"); 
        
          this.xC = this.xC+40; 
          this.yC = this.yC+40;
        
          this.indexI = this.indexI+2; 
          this.indexJ = this.indexJ+2; 
        
        } else if ( (targetX > myLocX)&(targetY<myLocY) ) {
        
          //System.out.println("TOOK A STEP FOR REAL 2"); 
        
          this.xC = this.xC+40; 
          this.yC = this.yC-40;
        
          this.indexI = this.indexI+2; 
          this.indexJ = this.indexJ-2; 
        
        } else if ( (targetX < myLocX)&(targetY < myLocY) ) {
        
          //System.out.println("TOOK A STEP FOR REAL 3"); 
        
          this.xC = this.xC-40; 
          this.yC = this.yC-40;
        
          this.indexI = this.indexI-2; 
          this.indexJ = this.indexJ-2; 
        
      } else if ( (targetX < myLocX)&(targetY > myLocY) ) {
        
        //System.out.println("TOOK A STEP FOR REAL 4"); 
        
        this.xC = this.xC-40; 
        this.yC = this.yC+40;
        
        this.indexI = this.indexI-2; 
        this.indexJ = this.indexJ+2; 
        
      } else if ( (targetX == myLocX)&(targetY > myLocY) ) {
        
        //System.out.println("TOOK A STEP FOR REAL 5");
        
        this.yC = this.yC+40; 
        
        this.indexJ = this.indexJ+2; 
        
        this.xC = this.xC+40;
        
        this.indexI = this.indexI+2;
        
      } else if ( (targetX == myLocX)&(targetY < myLocY) ) {
        
        //System.out.println("TOOK A STEP FOR REAL 6");
        
        this.yC = this.yC-40; 
        
        this.indexJ = this.indexJ-2; 
        
        this.xC = this.xC-40;
        
        this.indexI = this.indexI-2;
        
      } else if ( (targetX > myLocX)&(targetY == myLocY) ) {
        
        //System.out.println("TOOK A STEP FOR REAL 7"); 
        
        this.xC = this.xC+40;
        
        this.indexI = this.indexI+2; 
        
        this.xC = this.xC+40;
        
        this.indexI = this.indexI+2;
        
      } else if ( (targetX < myLocX)&(targetY == myLocY) ) {
        
        //System.out.println("TOOK A STEP FOR REAL 8"); 
        
        this.xC = this.xC-40; 
        
        this.indexI = this.indexI-2; 
        
        this.xC = this.xC-40;
        
        this.indexI = this.indexI-2;
        
      }
    
  }
  
  
}
class HiveBullet {
  
  float speedX; 
  float speedY;
  
  int speedXMultiple; 
  int speedYMultiple; 
  int size; 
  
  float xCoor; 
  float yCoor; 
  
  int damage; 
  
  boolean status = true;
  
  HiveBullet() {
    speedX = 0; 
    speedY = 0;
    speedXMultiple = 5;
    speedYMultiple = 5;
  }
  
  public void setSpeedX(float sx) {
    speedX = sx*speedXMultiple; 
  }
  
  public void setSpeedY(float sy) {
    speedY = sy*speedYMultiple; 
  }
  
  public void setLocX(float lx) {
    xCoor = lx; 
  }
  
  public void setLocY(float ly) {
    yCoor = ly; 
  }
  
  public void setDamage(int d) {
    damage = d;
  }
  
  public void setXC(int xc) {
    xCoor = xc; 
  }
  
  public void setYC(int yc) {
    yCoor = yc; 
  }
  
  public int getDamage() { 
    return damage; 
  }
  
  public int getSpeedX() {
    return (int)speedX;  
  }
  
  public int getSpeedY() {
    return (int)speedY; 
  }
  
  public int getXC() {
    return (int)xCoor; 
  }
  
  public int getYC() {
    return (int)yCoor; 
  }
  
  public int getSize() {
    return size; 
  }
  
  public boolean getStatus() {
    return status; 
  }
 
  //determines if the bullet is on the screen or not
  public void checkStatus() {
    
    if (xCoor < 0) {
      this.status = false; 
    }
    
    if (yCoor < 0) {
      this.status = false; 
    }
    
    if (xCoor > 1400) {
      this.status = false; 
    }
    
    if (yCoor > 800) {
      this.status = false; 
    }
    
    
  }
  
  HiveBullet(float spX, float spY, int sze, int x, int y, int d) {
    speedX = spX;
    speedY = spY; 
    size = sze; 
    xCoor = x; 
    yCoor = y; 
    damage = d;
  }
  
}
class HiveMaster extends Enemy {
  
   PImage[] images = new PImage[3];
  
  //100 health
  //20 attack
  
  
  //for testing spawns a Phalax (0,0)
  HiveMaster() {
    super(20000, 8, 0, 0, 0, 0, "HiveMaster", 1000);
    
    images[0] = loadImage("hiveMaster.png");
    
    
    images[0].resize(100,100);
  }
  
  
  //for when the location is specified
  HiveMaster(float x, float y) {
    super(20000, 8, x, y, x/20, y/20, "HiveMaster", 1000);
    
    images[0] = loadImage("hiveMaster.png");
    
    
    images[0].resize(100,100);
  }
  
  public void show() {
    
    image(images[0], this.xC, this.yC);
    
  }
  
  public void transport() {
    
      int streamSize = 10; 
      int start = 0; 
      int bound = 9; 
      int xBound = 60;
      int yBound = 24;
      int xMin = 10; 
      int yMin = 10;
    
      Random r = new Random(); 
    
      r.ints(streamSize, start, bound);
      int spawnX = r.nextInt(xBound+1-xMin) + xMin;
      int spawnY = r.nextInt(yBound+1-yMin) + yMin;
    
      spawnX = spawnX*20; 
      spawnY = spawnY*20; 
      
     
      
     this.xC = spawnX; 
     this.yC = spawnY;
    
    
    
  }
  
  
  //issue: incoming targetX, targetY is in index, not graphics amount
  public void move(int targetX, int targetY) {
      
      //make targetX and targetY into the graphics coordinate not index
      targetX = targetX*20; 
      targetY = targetY*20;
    
      //accidentaly switched them somewhere along the line
      int temp = targetY; 
      targetY = targetX; 
      targetX = temp;
      
      
      int myLocX = (int)this.xC; 
      int myLocY = (int)this.yC;
      
      /* 1
        xxxxxxxxxxx
        xxxMxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxTxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
        if( (targetX > myLocX)&(targetY > myLocY) ) {
        
          //System.out.println("TOOK A STEP FOR REAL 1"); 
          
          int xDifference = (int)(targetX - myLocX)/20;
          int yDifference = (int)(targetY - myLocY)/20;
          
          if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
          int totalDifference = xDifference + yDifference; 
          
          
          if(totalDifference > 15) {
            this.needToShoot = true;
            
          } else {
            
            transport();
            
          }
     
          
     
        /* 2
        xxxxxxxxxxx
        xxxxxxxxxTx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxMxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
        } else if ( (targetX > myLocX)&(targetY<myLocY) ) {
        
          //System.out.println("TOOK A STEP FOR REAL 2"); 
          int xDifference = (int)(targetX - myLocX)/20;
          int yDifference = (int)(targetY - myLocY)/20;
          
          if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
          int totalDifference = xDifference + yDifference; 
          
          
          if(totalDifference > 15) {
            this.needToShoot = true;
            
          } else {
            
            transport();
            
          }
          
         
        
        /* 3
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxTxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxMxx
        xxxxxxxxxxx
        */
        } else if ( (targetX < myLocX)&(targetY < myLocY) ) {
        
          //System.out.println("TOOK A STEP FOR REAL 3"); 
          
          
          int xDifference = (int)(targetX - myLocX)/20;
          int yDifference = (int)(targetY - myLocY)/20;
          
          if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
          int totalDifference = xDifference + yDifference; 
          
          
          if(totalDifference > 15) {
            this.needToShoot = true;
            
          } else {
            
            transport();
            
          }
          
          
        
        /* 4
        xxxxxxxxxxx
        xxxxxxxxMxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxTxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX < myLocX)&(targetY > myLocY) ) {
        
        //System.out.println("TOOK A STEP FOR REAL 4"); 
        
         int xDifference = (int)(targetX - myLocX)/20;
         int yDifference = (int)(targetY - myLocY)/20;
         
         if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
         int totalDifference = xDifference + yDifference; 
         
         
         if(totalDifference > 15) {
            this.needToShoot = true;
            
          } else {
            
            transport();
            
          }
          

        

        /* 5
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxMxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxTxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX == myLocX)&(targetY > myLocY) ) {
        
         int xDifference = (int)(targetX - myLocX)/20;
         int yDifference = (int)(targetY - myLocY)/20;
         
         if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
         int totalDifference = xDifference + yDifference; 
         
         
         
        if(totalDifference > 15) {
            this.needToShoot = true;
            
          } else {
            
            transport();
            
          }
        
        
        /* 6
        xxxxxxxxxxx
        xxxTxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxMxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX == myLocX)&(targetY < myLocY) ) {
        
        int xDifference = (int)(targetX - myLocX)/20;
         int yDifference = (int)(targetY - myLocY)/20;
         
         if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
         int totalDifference = xDifference + yDifference; 
         
         if(totalDifference > 15) {
            this.needToShoot = true;
            
          } else {
            
            transport();
            
          }
         
        
        /* 7
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxMxxxxxTxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX > myLocX)&(targetY == myLocY) ) {
        
        int xDifference = (int)(targetX - myLocX)/20;
         int yDifference = (int)(targetY - myLocY)/20;
         
         if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
         int totalDifference = xDifference + yDifference; 
        
         
         if(totalDifference > 15) {
            this.needToShoot = true;
            
          } else {
            
            transport();
            
          }
          
        
        /* 8
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxTxxxxxMxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX < myLocX)&(targetY == myLocY) ) {
        
         int xDifference = (int)(targetX - myLocX)/20;
         int yDifference = (int)(targetY - myLocY)/20;
         
         if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
         int totalDifference = xDifference + yDifference; 
         
         if(totalDifference > 15) {
            this.needToShoot = true;
            
          } else {
            
            transport();
            
          }
          
       
        
        
      }
      
     
    }
    
}
class Monkey extends Enemy {
  
  PImage[] images = new PImage[3];
  
  //100 health
  //20 attack
  
  
  //for testing spawns an ant (0,0)
  Monkey() {
    super(250, 3, 0, 0, 0, 0, "Monkey", 35);
    images[0] = loadImage("monkey.png");
    
    images[0].resize(20,20);
   
  }
  
  
  //for when the location is specified
  Monkey(float x, float y) {
    super(250, 3, x, y, x/20, y/20, "Monkey", 35);
    images[0] = loadImage("monkey.png");
   
  
    images[0].resize(20,20);
    
  }
  
  
  public void show() {
    
     image(images[0], this.xC, this.yC);
  }
  
  public void move(int targetX, int targetY) {
    
    
     
     Random r = new Random();
   
   int streamSize = 10; 
   int start = 0; 
   int bound = 9; 
   int outcomeMin = 0; 
   int outcomeBound = 1;
   
   r.ints(streamSize, start, bound);
   
   int randomNess = r.nextInt(outcomeBound+1-outcomeMin) + outcomeMin;
   
   
    //make targetX and targetY into the graphics coordinate not index
      targetX = targetX*20; 
      targetY = targetY*20;
    
      //accidentaly switched them somewhere along the line
      int temp = targetY; 
      targetY = targetX; 
      targetX = temp;
      
      
      int myLocX = (int)this.xC; 
        int myLocY = (int)this.yC;
      
        //System.out.println("MyLocX: " + myLocX); 
        //System.out.println("MyLocY: " + myLocY); 
        //System.out.println("TargetX: " + targetX); 
        //System.out.println("TargetY: " + targetY); 
      
      
        if( (targetX > myLocX)&(targetY > myLocY) ) {
        
          //System.out.println("TOOK A STEP FOR REAL 1"); 
        
          this.xC = this.xC+20; 
          this.yC = this.yC+20;
        
          this.indexI = this.indexI+1; 
          this.indexJ = this.indexJ+1; 
          
          if(randomNess == 1) { this.xC = this.xC+20; this.indexI = this.indexI+1; }
        
        } else if ( (targetX > myLocX)&(targetY<myLocY) ) {
        
          //System.out.println("TOOK A STEP FOR REAL 2"); 
        
          this.xC = this.xC+20; 
          this.yC = this.yC-20;
        
          this.indexI = this.indexI+1; 
          this.indexJ = this.indexJ-1; 
          
          if(randomNess == 1) { this.xC = this.xC+20; this.indexI = this.indexI+1; }
        
        } else if ( (targetX < myLocX)&(targetY < myLocY) ) {
        
          //System.out.println("TOOK A STEP FOR REAL 3"); 
        
          this.xC = this.xC-20; 
          this.yC = this.yC-20;
        
          this.indexI = this.indexI-1; 
          this.indexJ = this.indexJ-1; 
          
          if(randomNess == 1) { this.xC = this.xC-20; this.indexI = this.indexI-1; }
        
      } else if ( (targetX < myLocX)&(targetY > myLocY) ) {
        
        //System.out.println("TOOK A STEP FOR REAL 4"); 
        
        this.xC = this.xC-20; 
        this.yC = this.yC+20;
        
        this.indexI = this.indexI-1; 
        this.indexJ = this.indexJ+1; 
        
        if(randomNess == 1) { this.xC = this.xC-20; this.indexI = this.indexI-1; }
        
      } else if ( (targetX == myLocX)&(targetY > myLocY) ) {
        
        //System.out.println("TOOK A STEP FOR REAL 5");
        
        this.yC = this.yC+20; 
        
        this.indexJ = this.indexJ+1; 
        
        this.xC = this.xC+20;
        
        this.indexI = this.indexI+1;
        
        if(randomNess == 1) { this.xC = this.xC+20; this.indexI = this.indexI+1; }
        
      } else if ( (targetX == myLocX)&(targetY < myLocY) ) {
        
        //System.out.println("TOOK A STEP FOR REAL 6");
        
        this.yC = this.yC-20; 
        
        this.indexJ = this.indexJ-1; 
        
        this.xC = this.xC-20;
        
        this.indexI = this.indexI-1;
        
        if(randomNess == 1) { this.xC = this.xC-20; this.indexI = this.indexI-1; }
        
      } else if ( (targetX > myLocX)&(targetY == myLocY) ) {
        
        //System.out.println("TOOK A STEP FOR REAL 7"); 
        
        this.xC = this.xC+20;
        
        this.indexI = this.indexI+1; 
        
        this.xC = this.xC+20;
        
        this.indexI = this.indexI+1;
        
        if(randomNess == 1) { this.xC = this.xC+20; this.indexI = this.indexI+1; }
        
      } else if ( (targetX < myLocX)&(targetY == myLocY) ) {
        
        //System.out.println("TOOK A STEP FOR REAL 8"); 
        
        this.xC = this.xC-20; 
        
        this.indexI = this.indexI-1; 
        
        this.xC = this.xC-20;
        
        this.indexI = this.indexI-1;
        
        if(randomNess == 1) { this.xC = this.xC-20; this.indexI = this.indexI-1; }
        
      }
    
  }
  
  
}
class Phalax extends Enemy {
  
   PImage[] images = new PImage[3];
  
  //100 health
  //20 attack
  
  
  //for testing spawns a Phalax (0,0)
  Phalax() {
    super(2000, 20, 0, 0, 0, 0, "Phalax", 500);
    
    images[0] = loadImage("phalax.png");
    
    
    images[0].resize(100,100);
  }
  
  
  //for when the location is specified
  Phalax(float x, float y) {
    super(2000, 20, x, y, x/20, y/20, "Phalax", 500);
    
    images[0] = loadImage("phalax.png");
    
    
    images[0].resize(100,100);
  }
  
  public void show() {
    
    image(images[0], this.xC, this.yC);
    
  }
  
  
  //issue: incoming targetX, targetY is in index, not graphics amount
  public void move(int targetX, int targetY) {
      
      //make targetX and targetY into the graphics coordinate not index
      targetX = targetX*20; 
      targetY = targetY*20;
    
      //accidentaly switched them somewhere along the line
      int temp = targetY; 
      targetY = targetX; 
      targetX = temp;
      
      
      int myLocX = (int)this.xC; 
      int myLocY = (int)this.yC;
      
      /* 1
        xxxxxxxxxxx
        xxxMxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxTxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
        if( (targetX > myLocX)&(targetY > myLocY) ) {
        
          //System.out.println("TOOK A STEP FOR REAL 1"); 
          
          int xDifference = (int)(targetX - myLocX)/20;
          int yDifference = (int)(targetY - myLocY)/20;
          
          if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
          int totalDifference = xDifference + yDifference; 
          
          //if the target is somewhat far away, move towards them
          if(totalDifference >=  10) {
          
             this.xC = this.xC+40; 
             this.yC = this.yC+40;
        
             this.indexI = this.indexI+2; 
             this.indexJ = this.indexJ+2;
            
          //if the target is close, take shots   
          } else {
            
            this.needToShoot = true;
            
            
          }
          
     
        /* 2
        xxxxxxxxxxx
        xxxxxxxxxTx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxMxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
        } else if ( (targetX > myLocX)&(targetY<myLocY) ) {
        
          //System.out.println("TOOK A STEP FOR REAL 2"); 
          int xDifference = (int)(targetX - myLocX)/20;
          int yDifference = (int)(targetY - myLocY)/20;
          
          if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
          int totalDifference = xDifference + yDifference; 
          
          //if the target is somewhat far away, move towards them
          if(totalDifference >=  10) {
          
            this.xC = this.xC+40; 
            this.yC = this.yC-40;
        
            this.indexI = this.indexI+2; 
            this.indexJ = this.indexJ-2; 
            
          //if the target is close, take shots   
          } else {
            
            this.needToShoot = true;
            
            
          }
          
        
        /* 3
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxTxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxMxx
        xxxxxxxxxxx
        */
        } else if ( (targetX < myLocX)&(targetY < myLocY) ) {
        
          //System.out.println("TOOK A STEP FOR REAL 3"); 
          
          
          int xDifference = (int)(targetX - myLocX)/20;
          int yDifference = (int)(targetY - myLocY)/20;
          
          if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
          int totalDifference = xDifference + yDifference; 
          
          //if the target is somewhat far away, move towards them
          if(totalDifference >=  10) {
          
            this.xC = this.xC-40; 
            this.yC = this.yC-40;
        
            this.indexI = this.indexI-2; 
            this.indexJ = this.indexJ-2; 
         
            
          //if the target is close, take shots   
          } else {
            
            this.needToShoot = true;
            
            
          }
        
        
        /* 4
        xxxxxxxxxxx
        xxxxxxxxMxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxTxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX < myLocX)&(targetY > myLocY) ) {
        
        //System.out.println("TOOK A STEP FOR REAL 4"); 
        
         int xDifference = (int)(targetX - myLocX)/20;
         int yDifference = (int)(targetY - myLocY)/20;
         
         if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
         int totalDifference = xDifference + yDifference; 
          
        
        //if the target is somewhat far away, move towards them
          if(totalDifference >=  10) {
          
             this.xC = this.xC-40; 
             this.yC = this.yC+40;
        
             this.indexI = this.indexI-2; 
             this.indexJ = this.indexJ+2; 
        
         
            
          //if the target is close, take shots   
          } else {
            
            this.needToShoot = true;
            
            
          }
        

        /* 5
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxMxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxTxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX == myLocX)&(targetY > myLocY) ) {
        
         int xDifference = (int)(targetX - myLocX)/20;
         int yDifference = (int)(targetY - myLocY)/20;
         
         if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
         int totalDifference = xDifference + yDifference; 
          
        
        //if the target is somewhat far away, move towards them
          if(totalDifference >=  10) {
          
              
             this.yC = this.yC+40;
             this.indexJ = this.indexJ+2; 
        
         
            
          //if the target is close, take shots   
          } else {
            
            this.needToShoot = true;
            
            
          }
        
        
       
        
        /* 6
        xxxxxxxxxxx
        xxxTxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxMxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX == myLocX)&(targetY < myLocY) ) {
        
        int xDifference = (int)(targetX - myLocX)/20;
         int yDifference = (int)(targetY - myLocY)/20;
         
         if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
         int totalDifference = xDifference + yDifference; 
          
        
        //if the target is somewhat far away, move towards them
          if(totalDifference >=  10) {
          
              
             this.yC = this.yC-40;
             this.indexJ = this.indexJ-2; 
        
         
            
          //if the target is close, take shots   
          } else {
            
            this.needToShoot = true;
            
            
          }
      
       
        
        /* 7
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxMxxxxxTxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX > myLocX)&(targetY == myLocY) ) {
        
        int xDifference = (int)(targetX - myLocX)/20;
         int yDifference = (int)(targetY - myLocY)/20;
         
         if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
         int totalDifference = xDifference + yDifference; 
          
        
        //if the target is somewhat far away, move towards them
          if(totalDifference >=  10) {
          
              
             this.xC = this.xC+40;
             this.indexI = this.indexI+2; 
        
         
            
          //if the target is close, take shots   
          } else {
            
            this.needToShoot = true;
            
            
          }
        
        
       
        
        /* 8
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxTxxxxxMxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX < myLocX)&(targetY == myLocY) ) {
        
         int xDifference = (int)(targetX - myLocX)/20;
         int yDifference = (int)(targetY - myLocY)/20;
         
         if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
         int totalDifference = xDifference + yDifference; 
          
        
        //if the target is somewhat far away, move towards them
          if(totalDifference >=  10) {
          
              
             this.xC = this.xC - 40;
             this.indexI = this.indexI-2; 
        
         
            
          //if the target is close, take shots   
          } else {
            
            this.needToShoot = true;
            
            
          }
        
        
        
      }
      
     
    }
    
}
    
  
  
  
class PhalaxBullet {
  
  float speedX; 
  float speedY;
  
  int speedXMultiple; 
  int speedYMultiple; 
  int size; 
  
  float xCoor; 
  float yCoor; 
  
  int damage; 
  
  boolean status = true;
  
  PhalaxBullet() {
    speedX = 0; 
    speedY = 0;
    speedXMultiple = 5;
    speedYMultiple = 5;
  }
  
  public void setSpeedX(float sx) {
    speedX = sx*speedXMultiple; 
  }
  
  public void setSpeedY(float sy) {
    speedY = sy*speedYMultiple; 
  }
  
  public void setLocX(float lx) {
    xCoor = lx; 
  }
  
  public void setLocY(float ly) {
    yCoor = ly; 
  }
  
  public void setDamage(int d) {
    damage = d;
  }
  
  public void setXC(int xc) {
    xCoor = xc; 
  }
  
  public void setYC(int yc) {
    yCoor = yc; 
  }
  
  public int getDamage() { 
    return damage; 
  }
  
  public int getSpeedX() {
    return (int)speedX;  
  }
  
  public int getSpeedY() {
    return (int)speedY; 
  }
  
  public int getXC() {
    return (int)xCoor; 
  }
  
  public int getYC() {
    return (int)yCoor; 
  }
  
  public int getSize() {
    return size; 
  }
  
  public boolean getStatus() {
    return status; 
  }
 
  //determines if the bullet is on the screen or not
  public void checkStatus() {
    
    if (xCoor < 0) {
      this.status = false; 
    }
    
    if (yCoor < 0) {
      this.status = false; 
    }
    
    if (xCoor > 1400) {
      this.status = false; 
    }
    
    if (yCoor > 800) {
      this.status = false; 
    }
    
    
  }
  
  PhalaxBullet(float spX, float spY, int sze, int x, int y, int d) {
    speedX = spX;
    speedY = spY; 
    size = sze; 
    xCoor = x; 
    yCoor = y; 
    damage = d;
  }
  
}
class PirateShip extends Enemy {
  
  PImage[] images = new PImage[5];
  
  
  //100 health
  //20 attack
  
  boolean shootingSickness = false;
  int shotCounter = 0;
  int rejectedShots = 0; 
  
  //for testing spawns a flower (0,0)
  PirateShip() {
    super(30000, 3, 0, 0, 0, 0, "PirateShip", 2500);
    
    images[0] = loadImage("pirateShip.png");
    images[0].resize(250,100);
    
    images[1] = loadImage("pirateShip25.png");
    images[1].resize(250,100);
    
    images[2] = loadImage("pirateShip50.png");
    images[2].resize(250,100);
    
    images[3] = loadImage("pirateShip70.png");
    images[3].resize(250,100);
    
    images[4] = loadImage("pirateShip90.png");
    images[4].resize(250,100);
  
  }
  
  
  //for when the location is specified
  PirateShip(float x, float y) {
    super(30000, 3, x, y, x/20, y/20, "PirateShip", 2500);
    
    images[0] = loadImage("pirateShip.png");
    images[0].resize(250,100);
    
    images[1] = loadImage("pirateShip25.png");
    images[1].resize(250,100);
    
    images[2] = loadImage("pirateShip50.png");
    images[2].resize(250,100);
    
    images[3] = loadImage("pirateShip70.png");
    images[3].resize(250,100);
    
    images[4] = loadImage("pirateShip90.png");
    images[4].resize(250,100);
  }
  
  
  public void show() {
    
      if(this.health > 24000) {
        image(images[0], this.xC, this.yC);
      } else if ( (this.health <= 24000) & (this.health > 18000)) {
        image(images[1], this.xC, this.yC);  
      } else if(this.health <= 18000 & (this.health > 12000)) {
        image(images[2], this.xC, this.yC);
      } else if(this.health <= 12000 & (this.health > 6000)) {
        image(images[3], this.xC, this.yC);
      } else if(this.health <= 6000 & (this.health > 0)) {
        image(images[4], this.xC, this.yC);
      } else if(this.health <= 0) {
        this.die();
      }
    
  }
  
  
  public void move(int targetX, int targetY) {
    
    if(shotCounter > 8) { shootingSickness = true; shotCounter = 0; rejectedShots = 0;}
    if(rejectedShots > 16) { shootingSickness = false;  rejectedShots = 0; shotCounter = 0;}
    
   // System.out.println("Robot MOVING");
    
     //make targetX and targetY into the graphics coordinate not index
    targetX = targetX*20; 
    targetY = targetY*20;
    
    //accidentaly switched them somewhere along the line
    int temp = targetY; 
    targetY = targetX; 
    targetX = temp;
      
      
      int myLocX = (int)this.xC; 
        int myLocY = (int)this.yC;
        
        //System.out.println("MyLocX: " + myLocX); 
        //System.out.println("MyLocY: " + myLocY); 
        //System.out.println("TargetX: " + targetX); 
        //System.out.println("TargetY: " + targetY);
        
        /* 1
        xxxxxxxxxxx
        xxxMxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxTxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
        if( (targetX > myLocX)&(targetY > myLocY) ) {
        
          //System.out.println("TOOK A STEP FOR REAL 1"); 
          
          int xDifference = (int)(targetX - myLocX)/20;
          int yDifference = (int)(targetY - myLocY)/20;
          
          if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
          int totalDifference = xDifference + yDifference; 
          
          if(!shootingSickness) { this.needToShoot = true; this.shotCounter++; } else { this.rejectedShots++; }
     
        /* 2
        xxxxxxxxxxx
        xxxxxxxxxTx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxMxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
        } else if ( (targetX > myLocX)&(targetY<myLocY) ) {
        
          //System.out.println("TOOK A STEP FOR REAL 2"); 
          int xDifference = (int)(targetX - myLocX)/20;
          int yDifference = (int)(targetY - myLocY)/20;
          
          if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
          int totalDifference = xDifference + yDifference; 
          
          
          if(!shootingSickness) { this.needToShoot = true; this.shotCounter++; }
        
        /* 3
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxTxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxMxx
        xxxxxxxxxxx
        */
        } else if ( (targetX < myLocX)&(targetY < myLocY) ) {
        
          //System.out.println("TOOK A STEP FOR REAL 3"); 
          
          
          int xDifference = (int)(targetX - myLocX)/20;
          int yDifference = (int)(targetY - myLocY)/20;
          
          if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
          int totalDifference = xDifference + yDifference; 
          
          if(!shootingSickness) { this.needToShoot = true; this.shotCounter++; }
        
        /* 4
        xxxxxxxxxxx
        xxxxxxxxMxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxTxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX < myLocX)&(targetY > myLocY) ) {
        
        //System.out.println("TOOK A STEP FOR REAL 4"); 
        
         int xDifference = (int)(targetX - myLocX)/20;
         int yDifference = (int)(targetY - myLocY)/20;
         
         if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
         int totalDifference = xDifference + yDifference; 
          
        
         if(!shootingSickness) { this.needToShoot = true; this.shotCounter++; }

        /* 5
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxMxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxTxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX == myLocX)&(targetY > myLocY) ) {
        
         int xDifference = (int)(targetX - myLocX)/20;
         int yDifference = (int)(targetY - myLocY)/20;
         
         if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
         int totalDifference = xDifference + yDifference; 
          
        
        if(!shootingSickness) { this.needToShoot = true; this.shotCounter++; }
        
       
        
        /* 6
        xxxxxxxxxxx
        xxxTxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxMxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX == myLocX)&(targetY < myLocY) ) {
        
        int xDifference = (int)(targetX - myLocX)/20;
         int yDifference = (int)(targetY - myLocY)/20;
         
         if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
         int totalDifference = xDifference + yDifference; 
          
        
       
       if(!shootingSickness) { this.needToShoot = true; this.shotCounter++; }
        
        /* 7
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxMxxxxxTxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX > myLocX)&(targetY == myLocY) ) {
        
        int xDifference = (int)(targetX - myLocX)/20;
         int yDifference = (int)(targetY - myLocY)/20;
         
         if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
         int totalDifference = xDifference + yDifference; 
          
         if(!shootingSickness) { this.needToShoot = true; this.shotCounter++; }
       
        
        /* 8
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxTxxxxxMxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX < myLocX)&(targetY == myLocY) ) {
        
         int xDifference = (int)(targetX - myLocX)/20;
         int yDifference = (int)(targetY - myLocY)/20;
         
         if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
         int totalDifference = xDifference + yDifference; 
          
        if(!shootingSickness) { this.needToShoot = true; this.shotCounter++; }
       
        
        
      }
    
  }
  
}
class Player {
 
  float xC;
  float yC;
  float xSpeed;
  
  int indexI;
  int indexJ;
  
  int score = 0; 
  
  int goldAmount =1000; 
  int ironAmount =1000; 
  int woodAmount =200;
  int active = 0;
  
  
  int potionUpgradePieces; 
  int superPowerUpgradePieces; 
  
  Tile activeTile;
  Armor activeArmor; 
  
  Weapon activeTommy; 
  Weapon activeShotgun; 
  
  int health = 200;
  int shield = 00;
  
  Player() {
    xC = 10;
    yC = 10;
    xSpeed = 0;
    this.startLoc();
  }
  
  //setters START
  public void setXC(float x_coor) {
    xC = x_coor;
  }
  public void setYC(float y_coor) {
    yC = y_coor;
  }
  public void setXSpeed(float s) {
    xSpeed = s;
  }
  
  public void setScore(int s) {
    score = s; 
  }
  
  public void setHealth(int h) {
    health = h; 
  }
  
  public void setShields(int s) {
    shield = s; 
    
  }
  
  public void addGold(int g) {
    goldAmount = goldAmount + g;
  }
  
  public void addIron(int i) {
    ironAmount = ironAmount + i; 
  }
  
  public void addWood(int w) {
    woodAmount = woodAmount + w; 
  }
  
  public void setTile(Tile t) {
    activeTile = t;
  }
  
  public void setWeapons(Weapon t, Weapon s) {
    activeTommy = t; 
    activeShotgun = s; 
  }
  
  public void setTommy(Weapon t) {
    activeTommy = t; 
  }
  
  public void setShotgun(Weapon s) {
    activeShotgun = s; 
  }
  
  public int getXC() {
    return indexI; 
  }
  
  public int getYC() {
    return indexJ; 
  }
  
  public int getWoodAmount() {
    return woodAmount; 
  }
  
  public int getIronAmount() {
    return ironAmount; 
  } 
  
  public int getGoldAmount() {
    return goldAmount; 
  }
  
  public Weapon getTommy() {
    return activeTommy;
  }
  
  public Weapon getShotty() {
    return activeShotgun; 
  }
  
  
  //setters END
  
  //getters START
  public int getHealth() {
    return health; 
  }
  public int getShield() {
    return shield;
  }
  public Tile getCurrentTile() {
    return activeTile;
  }
  
  
  //getters END
  
  public void reset() {
  
    score = 0; 
  
    goldAmount =1000; 
    ironAmount =1000; 
    woodAmount =200;
    active = 0;
  
    health = 200;
    shield = 0;
    
    this.startLoc();
    
  }
  
  
  public void addPotionPiece(int p) {
    this.potionUpgradePieces = this.potionUpgradePieces + p;
    
    
  }
  
  
  public void addSuperPowerPiece(int p) {
    this.superPowerUpgradePieces = this.superPowerUpgradePieces + p;
    
  }
  
  
  public void startLoc() {
    Random r = new Random();
    int streamSize = 2800; 
    int start = 0; 
    int bound = 2799; 
     
    r.ints(streamSize, start, bound);
    
    int i = r.nextInt(39);
    int j = r.nextInt(69);
    
    indexI = i; 
    indexJ = j;
    
    //println("i =" + i);
    //println("j =" + j);
    
    //*1.1
    xC = j*20+10; 
    yC = i*20+10;
  }
  
  public void display() {
   rectMode(CENTER);
   //fill(255,156,82);
   //rect(xC,yC,20,20);
    
  }
  
  public void improveWeapon(Weapon w) {
    if(w.className.equals("Tommy")) {
      println("Upgrading tommy gun"); 
    } else if (w.className.equals("Shotgun")) {
      println("Upgrading shotgun");
    }
  }
  
  //handles WASD movement
  public void keyHandler(String key) {
    
   // println("indexI before movement: " + indexI); 
  //  println("indexJ before moevement: " + indexJ);
    
    String forward = "w";
    String left = "a";
    String down = "s";
    String right = "d";
    
    String hotkeyOne = "1"; 
    String hotkeyTwo = "2"; 
    String hotkeyThree = "3"; 
    String hotkeyFour = "4"; 
    String hotkeyFive = "5"; 
    
    String woodArmor = "e"; 
    String ironArmor = "r";
    String goldArmor = "t";
    
    String woodTommy = "f"; 
    String ironTommy = "g"; 
    String goldTommy = "h";
    
    String woodShotty = "c"; 
    String ironShotty = "v"; 
    String goldShotty = "b";
    
    
    
    if(forward.equals(key)) {
      //top of the screen boundary
      if(indexI - 1 >= 0) {
        setYC(yC-20);
      }
    } else if (left.equals(key)) {
      //left side screen boundary
      if(indexJ - 1 >= 0) {
        setXC(xC-20);
      }
    } else if (down.equals(key)) {
      //bottom of the screen boundary
      if(indexI + 1 < 39) {
        setYC(yC+20);
      }
    } else if (right.equals(key)) {
      //right side screen boundary
      if(indexJ + 1 < 69) {
        setXC(xC+20);
      }
      
    } else if (hotkeyOne.equals(key)) {
      active = 1;
    } else if (hotkeyTwo.equals(key)) {
      active = 2;
    } else if (hotkeyThree.equals(key)) {
      active = 3;
    } else if (hotkeyFour.equals(key)) {
      //active = 4;
      this.superPower();
    } else if (hotkeyFive.equals(key)) {
      //active = 5;
      this.drinkPotion();
    } else if (woodArmor.equals(key)) {
      //apply wooden armor
      applyArmor(1);
    } else if (ironArmor.equals(key)) {
      //apply iron armor
      applyArmor(2);
    } else if (goldArmor.equals(key)) {
      //apply gold armor
      applyArmor(3);
    } else if (woodTommy.equals(key)) {
      
    } else if (ironTommy.equals(key)) {
      
    } else if (goldTommy.equals(key)) {
      
    } else if (woodShotty.equals(key)) {
      
    } else if (ironShotty.equals(key)) {
      
    } else if (goldShotty.equals(key)) {
      
    }
    
    indexI = (int)yC/20;
    indexJ = (int)xC/20;
    
    //println("indexI after movement: " + indexI); 
   // println("indexJ after movement: " + indexJ);
    
  }
  
  public void superPower() {
    
    System.out.println("PLAYER USING THEIR POWER"); 
    
  }
  
  public void drinkPotion() {
    
    int potionLevel = this.potionUpgradePieces;
    
    if(potionLevel < 10) {
    
      this.health = this.health +75; 
      if(this.health > 200) { this.health = 200; }
      
    } else if ((potionLevel >= 10) & (potionLevel < 20)) {
      
       this.health = this.health + 150; 
      if(this.health > 200) { this.health = 200; }
      
      
    } else {
      
      this.health = 200;
    }
    
    
    
  }
  
  public boolean takeDamage(int i) {
    
    int leftover = 0; 
    
    //if the amount of damage being received is more than the available shields of the player
    if(i > this.shield) {
      
      //calculate leftover and set shields to 0
      leftover = i - this.shield;
      this.shield = 0;
      
      //rest of the damage to the health
      this.health = this.health - leftover; 
      
    //the amount of damage being received will only affect the players shields
    } else if (i <= this.shield) {
      
      //remove the damage
      this.shield = this.shield - i;
      
    }
    
    return checkDeath();
    
  }
  
  public boolean checkDeath() {
    
    if(0 >= this.health) { 
      return true;
    } else {
      return false; 
    }
    
  }
  
  public void applyArmor(int i) {
     println("Applying armor to player");  
     
     //wood can restore a player to a maximum of 100 shield
     //wood restores 50 shield at a time
     if(i == 1 && woodAmount >= 100) {
       println("Applying wood"); 
       if(shield <= 50) { 
         shield += 50; 
         woodAmount = woodAmount - 100;
       } else if (shield > 51 && shield < 100) {
         shield = 100; 
         woodAmount = woodAmount - 100;
       } else {
         println("You cannot heal any further with wood"); 
       }
       
     //iron can restore a player to a maximum of 150 shield
     //iron restores 100 shield at a time
     } else if (i == 2 && ironAmount >= 100) {
       println("Applying iron"); 
       if(shield <= 50) {
         shield += 100;
         ironAmount = ironAmount - 100;
       } else if (shield >51 && shield < 150) {
         shield = 150; 
         ironAmount = ironAmount - 100;
       } else {
         println("You cannot heal any further with iron"); 
       }
       
     //gold can restore a player to a maximum of 200 shield
     //gold restores 200 shield at a time
     } else if (i == 3 && goldAmount >= 100) {
       println("Applying gold"); 
       shield += 200; 
       goldAmount = goldAmount - 100;
       if (shield > 200) {
         shield = 200; 
       }
       
     }
  }
  
  
}

/*

1.1
using the array index, the squares location can be found on screen by multiplying by 20 (for the block size) and adding 10 (a pixel offset)




*/
class Robot extends Enemy {
  
  PImage[] images = new PImage[3];
  
  
  //100 health
  //20 attack
  
  
  //for testing spawns a flower (0,0)
  Robot() {
    super(150, 3, 0, 0, 0, 0, "Robot", 25);
    
    images[0] = loadImage("robot100.PNG"); 
    images[1] = loadImage("robot75.PNG");
    images[2] = loadImage("robot50.PNG");
    
    images[0].resize(20,20);
    images[1].resize(20,20);
    images[2].resize(20,20);
  }
  
  
  //for when the location is specified
  Robot(float x, float y) {
    super(150, 3, x, y, x/20, y/20, "Robot", 25);
    
    images[0] = loadImage("robot100.PNG"); 
    images[1] = loadImage("robot75.PNG");
    images[2] = loadImage("robot50.PNG");
    
    images[0].resize(20,20);
    images[1].resize(20,20);
    images[2].resize(20,20);
  }
  
  
  public void show() {
    
     if(this.health > 75) {
        image(images[0], this.xC, this.yC);
      } else if ( (this.health <= 75) & (this.health > 50)) {
        image(images[1], this.xC, this.yC);  
      } else if(this.health <= 50 & (this.health > 0)) {
        image(images[2], this.xC, this.yC);
      } else if(this.health <= 0) {
        this.die();
      }
    
    
  }
  
  
  public void move(int targetX, int targetY) {
    
   // System.out.println("Robot MOVING");
    
     //make targetX and targetY into the graphics coordinate not index
    targetX = targetX*20; 
    targetY = targetY*20;
    
    //accidentaly switched them somewhere along the line
    int temp = targetY; 
    targetY = targetX; 
    targetX = temp;
      
      
      int myLocX = (int)this.xC; 
        int myLocY = (int)this.yC;
        
        //System.out.println("MyLocX: " + myLocX); 
        //System.out.println("MyLocY: " + myLocY); 
        //System.out.println("TargetX: " + targetX); 
        //System.out.println("TargetY: " + targetY);
        
        /* 1
        xxxxxxxxxxx
        xxxMxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxTxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
        if( (targetX > myLocX)&(targetY > myLocY) ) {
        
          //System.out.println("TOOK A STEP FOR REAL 1"); 
          
          int xDifference = (int)(targetX - myLocX)/20;
          int yDifference = (int)(targetY - myLocY)/20;
          
          if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
          int totalDifference = xDifference + yDifference; 
          
          //if the target is somewhat far away, move towards them
          if(totalDifference >=  10) {
          
             this.xC = this.xC+20; 
             this.yC = this.yC+20;
        
             this.indexI = this.indexI+1; 
             this.indexJ = this.indexJ+1;
            
          //if the target is close, take shots   
          } else {
            
            this.needToShoot = true;
            
            
          }
          
     
        /* 2
        xxxxxxxxxxx
        xxxxxxxxxTx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxMxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
        } else if ( (targetX > myLocX)&(targetY<myLocY) ) {
        
          //System.out.println("TOOK A STEP FOR REAL 2"); 
          int xDifference = (int)(targetX - myLocX)/20;
          int yDifference = (int)(targetY - myLocY)/20;
          
          if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
          int totalDifference = xDifference + yDifference; 
          
          //if the target is somewhat far away, move towards them
          if(totalDifference >=  10) {
          
            this.xC = this.xC+20; 
            this.yC = this.yC-20;
        
            this.indexI = this.indexI+1; 
            this.indexJ = this.indexJ-1; 
            
          //if the target is close, take shots   
          } else {
            
            this.needToShoot = true;
            
            
          }
          
        
        /* 3
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxTxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxMxx
        xxxxxxxxxxx
        */
        } else if ( (targetX < myLocX)&(targetY < myLocY) ) {
        
          //System.out.println("TOOK A STEP FOR REAL 3"); 
          
          
          int xDifference = (int)(targetX - myLocX)/20;
          int yDifference = (int)(targetY - myLocY)/20;
          
          if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
          int totalDifference = xDifference + yDifference; 
          
          //if the target is somewhat far away, move towards them
          if(totalDifference >=  10) {
          
            this.xC = this.xC-20; 
            this.yC = this.yC-20;
        
            this.indexI = this.indexI-1; 
            this.indexJ = this.indexJ-1; 
         
            
          //if the target is close, take shots   
          } else {
            
            this.needToShoot = true;
            
            
          }
        
        
        /* 4
        xxxxxxxxxxx
        xxxxxxxxMxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxTxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX < myLocX)&(targetY > myLocY) ) {
        
        //System.out.println("TOOK A STEP FOR REAL 4"); 
        
         int xDifference = (int)(targetX - myLocX)/20;
         int yDifference = (int)(targetY - myLocY)/20;
         
         if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
         int totalDifference = xDifference + yDifference; 
          
        
        //if the target is somewhat far away, move towards them
          if(totalDifference >=  10) {
          
             this.xC = this.xC-20; 
             this.yC = this.yC+20;
        
             this.indexI = this.indexI-1; 
             this.indexJ = this.indexJ+1; 
        
         
            
          //if the target is close, take shots   
          } else {
            
            this.needToShoot = true;
            
            
          }
        

        /* 5
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxMxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxTxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX == myLocX)&(targetY > myLocY) ) {
        
         int xDifference = (int)(targetX - myLocX)/20;
         int yDifference = (int)(targetY - myLocY)/20;
         
         if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
         int totalDifference = xDifference + yDifference; 
          
        
        //if the target is somewhat far away, move towards them
          if(totalDifference >=  10) {
          
              
             this.yC = this.yC+20;
             this.indexJ = this.indexJ+1; 
        
         
            
          //if the target is close, take shots   
          } else {
            
            this.needToShoot = true;
            
            
          }
        
        
       
        
        /* 6
        xxxxxxxxxxx
        xxxTxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxMxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX == myLocX)&(targetY < myLocY) ) {
        
        int xDifference = (int)(targetX - myLocX)/20;
         int yDifference = (int)(targetY - myLocY)/20;
         
         if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
         int totalDifference = xDifference + yDifference; 
          
        
        //if the target is somewhat far away, move towards them
          if(totalDifference >=  10) {
          
              
             this.yC = this.yC-20;
             this.indexJ = this.indexJ-1; 
        
         
            
          //if the target is close, take shots   
          } else {
            
            this.needToShoot = true;
            
            
          }
      
       
        
        /* 7
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxMxxxxxTxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX > myLocX)&(targetY == myLocY) ) {
        
        int xDifference = (int)(targetX - myLocX)/20;
         int yDifference = (int)(targetY - myLocY)/20;
         
         if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
         int totalDifference = xDifference + yDifference; 
          
        
        //if the target is somewhat far away, move towards them
          if(totalDifference >=  10) {
          
              
             this.xC = this.xC+20;
             this.indexI = this.indexI+1; 
        
         
            
          //if the target is close, take shots   
          } else {
            
            this.needToShoot = true;
            
            
          }
        
        
       
        
        /* 8
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxTxxxxxMxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        xxxxxxxxxxx
        */
      } else if ( (targetX < myLocX)&(targetY == myLocY) ) {
        
         int xDifference = (int)(targetX - myLocX)/20;
         int yDifference = (int)(targetY - myLocY)/20;
         
         if(xDifference < 0) {
            xDifference = xDifference*-1; 
          }
          
          if(yDifference < 0) {
            yDifference = yDifference*-1; 
          }
          
         int totalDifference = xDifference + yDifference; 
          
        
        //if the target is somewhat far away, move towards them
          if(totalDifference >=  10) {
          
              
             this.xC = this.xC - 20;
             this.indexI = this.indexI-1; 
        
         
            
          //if the target is close, take shots   
          } else {
            
            this.needToShoot = true;
            
            
          }
        
        
        
      }
    
  }
  
}
class RobotBullet {
  
  float speedX; 
  float speedY;
  
  int speedXMultiple; 
  int speedYMultiple; 
  int size; 
  
  float xCoor; 
  float yCoor; 
  
  int damage; 
  
  boolean status = true;
  
  RobotBullet() {
    speedX = 0; 
    speedY = 0;
    speedXMultiple = 5;
    speedYMultiple = 5;
  }
  
  public void setSpeedX(float sx) {
    speedX = sx*speedXMultiple; 
  }
  
  public void setSpeedY(float sy) {
    speedY = sy*speedYMultiple; 
  }
  
  public void setLocX(float lx) {
    xCoor = lx; 
  }
  
  public void setLocY(float ly) {
    yCoor = ly; 
  }
  
  public void setDamage(int d) {
    damage = d;
  }
  
  public void setXC(int xc) {
    xCoor = xc; 
  }
  
  public void setYC(int yc) {
    yCoor = yc; 
  }
  
  public int getDamage() { 
    return damage; 
  }
  
  public int getSpeedX() {
    return (int)speedX;  
  }
  
  public int getSpeedY() {
    return (int)speedY; 
  }
  
  public int getXC() {
    return (int)xCoor; 
  }
  
  public int getYC() {
    return (int)yCoor; 
  }
  
  public int getSize() {
    return size; 
  }
  
  public boolean getStatus() {
    return status; 
  }
 
  //determines if the bullet is on the screen or not
  public void checkStatus() {
    
    if (xCoor < 0) {
      this.status = false; 
    }
    
    if (yCoor < 0) {
      this.status = false; 
    }
    
    if (xCoor > 1400) {
      this.status = false; 
    }
    
    if (yCoor > 800) {
      this.status = false; 
    }
    
    
  }
  
  RobotBullet(float spX, float spY, int sze, int x, int y, int d) {
    speedX = spX;
    speedY = spY; 
    size = sze; 
    xCoor = x; 
    yCoor = y; 
    damage = d;
  }
  
}
class Tile {
  
  String type;
  boolean traversable;
  int colour;
  int x_coor;
  int y_coor;
  int health = 100;
  int ironamount = 0; 
  int goldamount = 0;
  int woodamount = 0;
  int superPowerAmount = 0; 
  int potionUpgradeAmount = 0; 
  boolean clickable = true; 
  boolean hasPlayer = false; 
  PImage currentImage; 

  
  //its location in the 2D array
  int indexI; 
  int indexJ;
  
  //constructor \, blocks by default are dirt
  Tile() {
    type = "Dirt";
    traversable = true;
    clickable = false;
    colour = 0xff3AAD55;
  }
  
  Tile(String typeOf, boolean traverse, int c) {
    type = typeOf;
    traversable = traverse;
    colour = c;
  }
  
  public int getColour() {
    return colour;
  }
  
  public String getType() {
    return type;  
  }
  
  public int getHealth() {
    return health; 
  }
  
  public void setColour(int c) {
    colour = c;
  }
  
  public void setXCoor(int x) {
    x_coor = x;
  }
  
  public void setYCoor(int y) {
    y_coor = y; 
  }
  
  public void setIndexI(int i) {
    indexI = i;
  }
  
  public void setIndexJ(int j) {
    indexJ = j; 
  }
  
 
  public void clicked(Player player) {
    
    println("Player location: "); 
    println(player.xC);
    println(player.yC);
    
    
    //allowed to click a tile that is within 4 squares away in any direction
    
    /*
    
     x x x x x x x x x x x
     x x x x x x x x x x x   
     x a a a a a a a a a x
     x a a a a a a a a a x       shown here player 'Y' can mine all blocks labeled 'a'
     x a a a a a a a a a x       and only if the tile itself is actually clickable
     x a a a a Y a a a a x
     x a a a a a a a a a x
     x a a a a a a a a a x
     x a a a a a a a a a x
     x x x x x x x x x x x 
     x x x x x x x x x x x 
    */
    
    if(clickable) {
     
       println("Player X coor: " + player.xC); 
       println("Player Y coor: " + player.yC); 
       
       int playerI = (int)player.xC/20;
       int playerJ = (int)player.yC/20;
       
       //calculates how many columns away the player is from the block they are attempting to click
       int iDifference; 
       iDifference = abs(playerI - indexJ); 
       println("horizontally i am " + iDifference + " blocks away");
       
       //calculates how many rows away the player is from the block they are attempting to click
       int jDifference; 
       jDifference = abs(playerJ - indexI); 
       println("vertically i am " + jDifference + " blocks away");
       
       //if either of the differences amount to more then 2 blocks away, they cannot click that block
       //the player must also have the pickaxe selected
       if(iDifference <=4 && jDifference <=4 && player.active == 3) {
         health = health - 25; 
       
         //tiles that have already been mined are no longer clickable
         if(health == 0) {
           
           player.addGold(goldamount); 
           player.addIron(ironamount);
           player.addWood(woodamount);
           player.addPotionPiece(potionUpgradeAmount);
           player.addSuperPowerPiece(superPowerAmount);
           
           clickable = false;  
         }
       }
     
    }
    
    
  }
  
  
  public void nothing() {
    type = "Nothing";
    traversable = true; 
    clickable = false; 
  }
  
  public void dirt() {
    type = "Dirt";
    traversable = true;
    clickable = false;
    colour = 0xff3AAD55;
  }
  
  public void iron() {
    type = "Iron";
    traversable = true;
    clickable = true; 
    colour = 0xffB2A89C;
    ironamount = 10;
    goldamount = 0; 
    superPowerAmount = 0; 
    potionUpgradeAmount = 0;
  }
  
  public void gold() {
    type = "Gold";
    traversable = true;
    clickable = true;
    colour = 0xffE6ED35;
    goldamount = 10;
    ironamount = 0; 
    superPowerAmount = 0; 
    potionUpgradeAmount = 0;
    
  }
  
  public void water() {
    type = "Water";
    traversable = false;
    clickable = false;
    colour = 0xff2736CB;
  }
  
  public void lava() {
    type = "Lava";
    traversable = true;
    clickable = false;
    colour = 0xffD33A3A;
  }
  
  public void tree() {
    type = "Tree";
    traversable = true;
    clickable = true; 
    colour = 0xff397619;
    woodamount = 10;
    goldamount = 0;
    ironamount = 0;
    superPowerAmount = 0; 
    potionUpgradeAmount = 0;
  }
  
  public void steel() {
    type = "Steel"; 
    traversable = true; 
    clickable = false; 
    
    
  }
  
  public void superPower() {
    type = "SuperPower"; 
    traversable = true; 
    clickable = true; 
    superPowerAmount = 1; 
    woodamount = 0;
    goldamount = 0;
    ironamount = 0;
    
    
  }
  
  public void potionUpgrade() {
    type = "PotionUpgrade";
    traversable = true; 
    clickable = true; 
    potionUpgradeAmount = 1;
    woodamount = 0;
    goldamount = 0;
    ironamount = 0;
  }
  
 public void showYourself() {
    colour = 0xff000000;
 }
 
 
 public void tropical() {
    type = "Tropical";
    traversable = true;
    clickable = false; 
   
   
 }
 
 
 public void sand() {
   type = "Sand"; 
   traversable = true; 
   clickable = false; 
   
   
 }
 
 
 public void tropicalTree() {
   
   
 }
 

  
}
class Weapon {
  
  //need to add reload time, shoot delay for shotgun
  
 String tier = "null"; 
 String name = "null";
 String className = "null";
 int maxDamage = 0; 
 int minDamage = 0; 
 int ammo; 
 int clipSize;
 int colour; 
 int durability; 
 
 boolean buildable; 
 int cost; 
 int range; 
 
 Weapon() {
   
 }
 
 Weapon(String t, String n, int max, int min, boolean build, int c, int r, int a, int clip, int col, String classN) {
  tier = t; 
  name = n; 
  maxDamage = max; 
  minDamage = min; 
  buildable = build; 
  cost = c; 
  range = r; 
  ammo = a;
  clipSize = clip;
  colour = col;
  className = classN;
 }
 
 
 Weapon(String n, int d) {
   name = n; 
   maxDamage = d;
 }
 
 //setters
 public void setTier(String t) {
   tier = t; 
 }
 
 public void setName(String n) {
   name = n;
 }
 
 public void setMaxDamage(int max) {
   maxDamage = max; 
 }
 
 public void setMinDamage(int min) {
   minDamage = min; 
 }
 
 public void setBuildable(boolean b) {
    buildable = b; 
  }
  
  
 public void useAmmo(int a) {
   this.ammo = this.ammo - a;
 }
 
 public void addAmmo(int a) {
   this.ammo = this.ammo + a;
 }
 
 //getters
 public String getTier() {
   return tier; 
 }
 
 public String getName() {
   return name; 
 }
 
 public int getMaxDamage() {
   return maxDamage; 
 }
 
 public int getMinDamage() {
   return minDamage; 
 }
 
 public int getCost() {
   return cost; 
 }
 
 public int getClipSize() {
   return clipSize;
 }
 
 public boolean getBuildable() {
   return buildable; 
 }
 
 
}
  public void settings() {  size(1400,900);  smooth(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--stop-color=#cccccc", "sketch_190710a" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
